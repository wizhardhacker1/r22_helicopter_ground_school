from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')

def test_drive_system_assets_and_route_exist():
    m=t('app/main.py'); h=t('app/templates/drive_system.html')
    assert "@app.get('/drive-system'" in m
    for name in ['r22_drive_damper_reference_v113.jpg','r22_drive_train_figure_reference_v113.jpg','r22_drive_system_schematic_v113.jpg']:
        assert (R/'app/static/training'/name).exists()
    assert 'Drive System Learning Lab' in h

def test_drive_system_uses_verified_r22_facts_and_source_warnings():
    h=t('app/templates/drive_system.html'); j=t('app/static/drive_system_v113.js')
    assert 'Avoid continuous rotor operation at 60–70%' in h
    assert 'lightly-loaded damper bearing' in h
    assert 'R22 POH Section 7' in h
    assert 'current R22 Maintenance Manual' in h
    assert 'non-authoritative' in j
    assert 'Numeric values printed' not in h

def test_drive_system_has_interactive_power_flow_and_image_quiz():
    j=t('app/static/drive_system_v113.js')
    assert 'const flow=[' in j and 'AUTO PLAY' in t('app/templates/drive_system.html')
    assert "$('#driveImageStage').addEventListener('pointerdown'" in j
    assert 'DRIVE SYSTEM QUIZ PASSED' in j
    assert "module:'drive_system'" in j

def test_autorotation_lab_uses_r22_poh_values_not_r44_as_authority():
    h=t('app/templates/autorotation_lab.html'); j=t('app/static/autorotation_lab_v113.js')
    assert "@app.get('/autorotation-lab'" in t('app/main.py')
    assert 'R44 REFERENCE IMAGE — NOT AN R22 PROCEDURE SOURCE' in h
    assert '60–70 KIAS' in h and 'about 40 ft AGL' in h and 'about 8 ft AGL' in h
    assert 'Verify the R22 procedure in the current R22 POH/RFM' in h
    assert "module:'autorotation_lab'" in j
    assert (R/'app/static/training/r44_autorotation_source_check_v113.jpg').exists()

def test_autorotation_practice_sequence_is_complete_and_aircraft_specific():
    j=t('app/static/autorotation_lab_v113.js')
    expected=['ADJUST CARB HEAT IF REQUIRED','LOWER COLLECTIVE TO DOWN STOP / REDUCE THROTTLE SMOOTHLY AS DESIRED','ADJUST COLLECTIVE FOR ROTOR RPM / THROTTLE FOR NEEDLE SEPARATION','MAINTAIN 60–70 KIAS','BEGIN CYCLIC FLARE ABOUT 40 FT AGL','ABOUT 8 FT: LEVEL, RAISE COLLECTIVE, ADD THROTTLE AS REQUIRED']
    for x in expected: assert x in j
    assert 'COPY THE R44 POSTER VALUES' in j

def test_new_labs_are_in_navigation_and_roadmap():
    b=t('app/templates/base.html'); r=t('app/roadmap.py')
    assert 'href=/drive-system' in b and 'href=/autorotation-lab' in b
    assert "('Drive System Lab','/drive-system')" in r
    assert "('R22 Autorotation Lab','/autorotation-lab')" in r

def test_new_training_assets_are_precached_for_offline_use():
    sw=t('app/static/sw.js')
    for x in ['drive_system_v113.js','autorotation_lab_v113.js','r22_drive_damper_reference_v113.jpg','r22_drive_train_figure_reference_v113.jpg','r22_drive_system_schematic_v113.jpg','r44_autorotation_source_check_v113.jpg']:
        assert x in sw

def test_autorotation_quiz_does_not_add_empty_css_class_token():
    j=t('app/static/autorotation_lab_v113.js')
    assert "classList.add(n===q.a?'good-choice':n===i?'bad-choice':'')" not in j
    assert "if(n===q.a)x.classList.add('good-choice')" in j

def test_readability_fixes_cover_known_washout_surfaces():
    c=t('app/static/app.css')
    for x in ['.engine-mini b{color:#f3f6f7!important}', '.planner-result,.oral-feedback{color:#eef7fa!important}', '.load-controls.card label', '.r87-pilot-controls output']:
        assert x in c

def test_source_discipline_keeps_r44_reference_out_of_r22_operational_steps():
    h=t('app/templates/autorotation_lab.html'); j=t('app/static/autorotation_lab_v113.js')
    assert 'R44 REFERENCE IMAGE — NOT AN R22 PROCEDURE SOURCE' in h
    assert 'R44' not in ''.join(x.split("const quiz=[",1)[0] for x in [j]).split('const distract=',1)[0]
