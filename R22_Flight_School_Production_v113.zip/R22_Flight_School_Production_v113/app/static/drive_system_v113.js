(()=>{const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const images={
 damper:{src:'/static/training/r22_drive_damper_reference_v113.jpg?v=113',title:'TAIL ROTOR DRIVE SHAFT / DAMPER',note:'The upper photograph locates the external damper area. The lower diagram is a training reference; current Robinson publications control.'},
 manual:{src:'/static/training/r22_drive_train_figure_reference_v113.jpg?v=113',title:'DRIVE TRAIN FIGURE REFERENCE',note:'This photographed maintenance-manual figure is useful for component orientation. It is an older figure image; use the current Aug 2026 R22 Maintenance Manual for maintenance authority.'},
 schematic:{src:'/static/training/r22_drive_system_schematic_v113.jpg?v=113',title:'SIMPLIFIED POWER-FLOW SCHEMATIC',note:'Use this image for component relationships only. Labels, spelling, and numeric values printed in the image are non-authoritative; the app uses current R22 POH/RFM terminology and verified source data.'}
};
const facts={
 engine:['Engine / lower sheave','The engine output shaft drives the lower vee-belt sheave.','POH Section 7'],
 belts:['V-belts','V-belts transmit power from the engine-driven lower sheave to the upper sheave.','POH Section 7'],
 upper:['Upper sheave / overrunning clutch','The upper sheave contains the overrunning clutch. Its inner shaft transmits power forward to the main rotor and aft to the tail rotor.','POH Section 7'],
 main:['Main rotor drive','Power is transmitted forward through the main-rotor drive system to the main gearbox and main rotor.','POH Section 7'],
 tailshaft:['Tail rotor drive shaft','The long tail-rotor drive shaft carries power aft. Flexible couplings are located at its ends.','POH Section 7'],
 damper:['Tail rotor drive shaft damper','The long tail-rotor drive shaft has no support bearings but has a lightly-loaded damper bearing. SN-36 states the damper controls tail-rotor shaft vibration through the normal RPM range.','POH Section 7 / SN-36'],
 tailgb:['Tail rotor gearbox','The tail gearbox turns the drive through 90 degrees to the tail rotor.','POH Section 7']
};
const flow=[
 ['engine','ENGINE / LOWER SHEAVE','Engine output drives the lower vee-belt sheave.'],
 ['belts','V-BELTS','V-belts carry torque upward to the upper sheave.'],
 ['upper','UPPER SHEAVE / OVERRUNNING CLUTCH','The overrunning clutch permits autorotation by allowing the rotor system to overrun the engine drive.'],
 ['main','MAIN ROTOR DRIVE','The clutch inner shaft transmits power forward to the main-rotor drive and gearbox.'],
 ['tailshaft','TAIL ROTOR DRIVE SHAFT','The same inner shaft transmits power aft through the long tail-rotor drive shaft.'],
 ['damper','DAMPER BEARING','A lightly-loaded damper bearing controls tail-rotor shaft vibration.'],
 ['tailgb','TAIL ROTOR GEARBOX / TAIL ROTOR','The tail gearbox turns the drive 90 degrees and powers the tail rotor.']
];
// Normalized clickable regions are specific to the simplified drive-system image, except damper which uses the external-reference image.
const quiz=[
 {key:'damper',image:'damper',q:'Click the tail rotor drive shaft damper.',r:[.64,.10,.83,.29]},
 {key:'engine',image:'schematic',q:'Click the engine.',r:[.22,.55,.38,.79]},
 {key:'belts',image:'schematic',q:'Click the drive belts.',r:[.28,.41,.38,.58]},
 {key:'upper',image:'schematic',q:'Click the upper sheave / overrunning-clutch area.',r:[.35,.26,.54,.47]},
 {key:'tailshaft',image:'schematic',q:'Click the tail rotor drive shaft.',r:[.58,.30,.86,.47]},
 {key:'tailgb',image:'schematic',q:'Click the tail rotor gearbox.',r:[.83,.30,.96,.48]}
];
let mode='learn',imageKey='damper',flowIndex=0,flowTimer=null,quizOrder=[],quizIndex=0,correct=0,current=null;
function setImage(k){imageKey=k;const x=images[k];$('#driveImage').src=x.src;$('#driveTitle').textContent=x.title;$('#driveImageNote').innerHTML='<b>Training use:</b> '+x.note;$$('[data-drive-image]').forEach(b=>b.classList.toggle('active',b.dataset.driveImage===k));$('#driveMarker').style.display='none'}
function showPart(k){const x=facts[k];$('#drivePartTitle').textContent=x[0];$('#drivePartBody').textContent=x[1]+' Source: '+x[2]+'.';$$('[data-drive-part]').forEach(b=>b.classList.toggle('selected',b.dataset.drivePart===k));if(k==='damper')setImage('damper');else setImage('schematic')}
$$('[data-drive-part]').forEach(b=>b.addEventListener('click',()=>showPart(b.dataset.drivePart)));$$('[data-drive-image]').forEach(b=>b.addEventListener('click',()=>setImage(b.dataset.driveImage)));
function renderFlow(){const box=$('#driveFlowSteps');box.innerHTML='';flow.forEach((x,i)=>{const d=document.createElement('button');d.type='button';d.className='drive113-flow-step '+(i===flowIndex?'active':'')+(i<flowIndex?' done':'');d.innerHTML=`<small>${i+1}</small><b>${x[1]}</b>`;d.addEventListener('click',()=>{flowIndex=i;renderFlow()});box.appendChild(d)});const x=flow[flowIndex];$('#driveFlowExplain').textContent=x[2];showPart(x[0])}
function stopAuto(){clearInterval(flowTimer);flowTimer=null;$('#driveFlowAuto').textContent='AUTO PLAY'}
$('#driveFlowPrev').addEventListener('click',()=>{stopAuto();flowIndex=(flowIndex-1+flow.length)%flow.length;renderFlow()});$('#driveFlowNext').addEventListener('click',()=>{stopAuto();flowIndex=(flowIndex+1)%flow.length;renderFlow()});$('#driveFlowAuto').addEventListener('click',()=>{if(flowTimer){stopAuto();return}$('#driveFlowAuto').textContent='STOP';flowTimer=setInterval(()=>{flowIndex=(flowIndex+1)%flow.length;renderFlow()},1200)});
function shuffle(a){for(let i=a.length-1;i>0;i--){const n=Math.floor(Math.random()*(i+1));[a[i],a[n]]=[a[n],a[i]]}return a}
function beginQuiz(){quizOrder=shuffle(quiz.slice());quizIndex=0;correct=0;nextQuiz()}
function nextQuiz(){if(quizIndex>=quizOrder.length){current=null;$('#driveQuizQuestion').textContent='DRIVE SYSTEM QUIZ PASSED';$('#driveQuizFeedback').textContent=`PASS — ${correct}/${quizOrder.length} components identified correctly.`;$('#driveQuizFeedback').className='quiz-feedback good';$('#driveQuizNext').hidden=false;$('#driveQuizNext').textContent='RESTART QUIZ';$('#driveQuizProgress').textContent=`${correct} / ${quizOrder.length} correct`;saveCompletion();return}current=quizOrder[quizIndex];setImage(current.image);$('#driveQuizQuestion').textContent=`Question ${quizIndex+1} of ${quizOrder.length}: ${current.q}`;$('#driveQuizFeedback').textContent='Click directly on the requested component.';$('#driveQuizFeedback').className='quiz-feedback';$('#driveQuizNext').hidden=true;$('#driveQuizNext').textContent='NEXT COMPONENT';$('#driveQuizProgress').textContent=`${correct} / ${quizOrder.length} correct`}
$('#driveImageStage').addEventListener('pointerdown',e=>{if(mode!=='quiz'||!current)return;const r=$('#driveImage').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)return;const x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height,[x1,y1,x2,y2]=current.r,ok=x>=x1&&x<=x2&&y>=y1&&y<=y2;const m=$('#driveMarker');const sr=$('#driveImageStage').getBoundingClientRect();m.style.left=(e.clientX-sr.left)+'px';m.style.top=(e.clientY-sr.top)+'px';m.style.display='block';m.className='drive113-marker '+(ok?'correct':'wrong');if(ok){correct++;$('#driveQuizFeedback').textContent='CORRECT — '+facts[current.key][0].toUpperCase();$('#driveQuizFeedback').className='quiz-feedback good';$('#driveQuizNext').hidden=false}else{$('#driveQuizFeedback').textContent='INCORRECT — TRY AGAIN';$('#driveQuizFeedback').className='quiz-feedback bad'}});
$('#driveQuizNext').addEventListener('click',()=>{if(quizIndex>=quizOrder.length){beginQuiz();return}quizIndex++;nextQuiz()});
async function saveCompletion(){try{await fetch('/api/training/interactive',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({module:'drive_system',item:'image_quiz',mode:'test',score:100,completed:quizOrder.length,total:quizOrder.length,mistakes:0,seconds:0})})}catch(e){}}
function setMode(m){mode=m;stopAuto();$$('[data-drive-mode]').forEach(b=>b.classList.toggle('active',b.dataset.driveMode===m));$('#driveLearnPanel').hidden=m!=='learn';$('#driveFlowPanel').hidden=m!=='flow';$('#driveQuizPanel').hidden=m!=='quiz';if(m==='learn'){setImage('damper');showPart('damper')}if(m==='flow'){setImage('schematic');flowIndex=0;renderFlow()}if(m==='quiz')beginQuiz()}
$$('[data-drive-mode]').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.driveMode)));setMode('learn');window.addEventListener('pagehide',stopAuto)})();
