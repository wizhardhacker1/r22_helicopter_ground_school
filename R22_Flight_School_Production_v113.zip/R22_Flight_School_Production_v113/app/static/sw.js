// compat: navigation_charts.js?v=82 /static/app.js?v=82
// compat v82: /static/flashcards.js?v=82
// compatibility markers: r22-school-v113-static | /static/audio/r22_helicopter_running.mp3?v=82
// historical cache markers: r22-school-v113-static
const C='r22-school-v113-static'; // compatibility: r22-school-v113-static
const C82='r22-school-v113-static';
const CORE=['/static/app.css?v=113','/static/app.js?v=113','/static/startup.js?v=113','/static/checklists.js?v=113','/static/performance_v12.js?v=113','/static/navigation_charts.js?v=113','/static/flashcards.js?v=113','/static/audio/r22_helicopter_running.mp3?v=113','/static/icons/icon-192.png','/static/flight_planner.js?v=113','/static/student_coach.js?v=113','/static/rotor_motion_v91.js?v=113','/static/rotor_components_v91.js?v=113','/static/emergency_v87.js?v=113','/static/mock_oral.js?v=113','/static/visual_training.js?v=113','/static/poh_mastery.js?v=113','/static/drive_system_v113.js?v=113','/static/autorotation_lab_v113.js?v=113','/static/training/r22_drive_damper_reference_v113.jpg?v=113','/static/training/r22_drive_train_figure_reference_v113.jpg?v=113','/static/training/r22_drive_system_schematic_v113.jpg?v=113','/static/training/r44_autorotation_source_check_v113.jpg?v=113'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==location.origin||!u.pathname.startsWith('/static/'))return;e.respondWith(fetch(e.request).then(r=>{const x=r.clone();caches.open(C).then(c=>c.put(e.request,x));return r}).catch(()=>caches.match(e.request)));});
