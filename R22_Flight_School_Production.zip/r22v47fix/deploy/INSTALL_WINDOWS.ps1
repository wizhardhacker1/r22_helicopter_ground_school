$ErrorActionPreference='Stop'
$Root = Split-Path $PSScriptRoot -Parent
Set-Location $Root
Write-Host 'Installing R22 Flight School for Windows...'
$py=$null
if(Get-Command py -ErrorAction SilentlyContinue){
  foreach($v in @('-3.13','-3.12','-3.11')){ try { & py $v -c "import sys; assert sys.version_info >= (3,11)" 2>$null; if($LASTEXITCODE -eq 0){$py="py $v";break} } catch {} }
}
if(-not $py -and (Get-Command python -ErrorAction SilentlyContinue)){ try { python -c "import sys; assert sys.version_info >= (3,11)"; if($LASTEXITCODE -eq 0){$py='python'} } catch {} }
if(-not $py){
  if(Get-Command winget -ErrorAction SilentlyContinue){ winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements; $py='py -3.12' }
  else { throw 'Python 3.11+ is required. Install Python from python.org, then rerun this installer.' }
}
if(Test-Path .venv){ Remove-Item -Recurse -Force .venv }
if($py -like 'py *'){ $a=$py.Split(' '); & $a[0] $a[1] -m venv .venv } else { & $py -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
Write-Host "Caching current FAA Los Angeles Sectional training chart (optional; requires Internet)..."
& .\.venv\Scripts\python.exe -m app.faa_content
if($LASTEXITCODE -ne 0){ Write-Warning "FAA chart could not be cached now. Install remains usable; Admin -> FAA Content & Updates can retry when connected." }
New-Item -ItemType Directory -Force data,backups | Out-Null
$PersistRoot = Join-Path $env:LOCALAPPDATA 'R22FlightSchool'
$PersistData = Join-Path $PersistRoot 'data'; $PersistBackups = Join-Path $PersistRoot 'backups'
New-Item -ItemType Directory -Force $PersistData,$PersistBackups | Out-Null
$LegacyDb = Join-Path $Root 'data\r22school.db'; $PersistDb = Join-Path $PersistData 'r22school.db'
if((Test-Path $LegacyDb) -and -not (Test-Path $PersistDb)){ Copy-Item $LegacyDb $PersistDb; Write-Host 'Migrated existing R22 user database to persistent storage.' }
if(-not (Test-Path .env)){ Copy-Item .env.example .env
  $secret=-join ((48..57)+(65..90)+(97..122) | Get-Random -Count 48 | ForEach-Object {[char]$_})
  (Get-Content .env) -replace '^SECRET_KEY=.*$', "SECRET_KEY=$secret" | Set-Content .env
}
$escapedData=$PersistData.Replace('\','/')
$envLines=Get-Content .env
if($envLines -match '^R22_DATA_DIR='){ $envLines=$envLines -replace '^R22_DATA_DIR=.*$', "R22_DATA_DIR=$escapedData" } else { $envLines += "R22_DATA_DIR=$escapedData" }
$dbUrl='sqlite:///'+$escapedData+'/r22school.db'
if($envLines -match '^DATABASE_URL=sqlite'){ $envLines=$envLines -replace '^DATABASE_URL=.*$', "DATABASE_URL=$dbUrl" }
$envLines | Set-Content .env
Get-Content .env | ForEach-Object { if($_ -match '^([^#=]+)=(.*)$'){[Environment]::SetEnvironmentVariable($matches[1].Trim(),$matches[2].Trim(),'Process')} }
& .\.venv\Scripts\python.exe -c "from app.main import startup; startup(); print('Database initialized')"
$port=if($env:PORT){$env:PORT}else{'8086'}
try { if(-not (Get-NetFirewallRule -DisplayName 'R22 Flight School' -ErrorAction SilentlyContinue)){ New-NetFirewallRule -DisplayName 'R22 Flight School' -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow | Out-Null } } catch { Write-Warning "Could not add Windows Firewall rule for TCP $port. Run installer as Administrator if LAN clients cannot connect." }
# Desktop and Start Menu shortcuts using native Windows COM; no extra dependency.
$ws=New-Object -ComObject WScript.Shell
$icon=Join-Path $Root 'app\static\icons\r22-flight-school.ico'
$desktop=[Environment]::GetFolderPath('Desktop')
$startMenu=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
foreach($dir in @($desktop,$startMenu)){
  $lnk=$ws.CreateShortcut((Join-Path $dir 'R22 Flight School.lnk')); $lnk.TargetPath='powershell.exe'; $lnk.Arguments="-NoProfile -ExecutionPolicy Bypass -File `"$Root\deploy\START_WINDOWS.ps1`""; $lnk.WorkingDirectory=$Root; $lnk.IconLocation=$icon; $lnk.Description='Start R22 Flight School'; $lnk.Save()
}
# Stop shortcut on desktop for local/server operators.
$lnk=$ws.CreateShortcut((Join-Path $desktop 'Stop R22 Flight School.lnk')); $lnk.TargetPath='powershell.exe'; $lnk.Arguments="-NoProfile -ExecutionPolicy Bypass -File `"$Root\deploy\STOP_WINDOWS.ps1`""; $lnk.WorkingDirectory=$Root; $lnk.IconLocation=$icon; $lnk.Save()
# Cache the official FAA Long Beach sectional training excerpt locally so the chart lab works after installation without Internet.
$ChartAsset = Join-Path $Root 'app\static\faa_sectional_long_beach.jpg'
if(-not (Test-Path $ChartAsset)){
  Write-Host 'Caching official FAA Long Beach sectional training excerpt for offline chart lab...'
  try { Invoke-WebRequest -UseBasicParsing -Uri 'https://www.faa.gov/sites/faa.gov/files/2025-07/lgb-sectional-chart.jpg' -OutFile $ChartAsset -TimeoutSec 45 }
  catch { Write-Warning 'Could not cache the sectional excerpt. The chart lab will retry from its online source when connected.' }
}
Write-Host 'Verifying application...'
& .\.venv\Scripts\python.exe -m pytest -q
if($LASTEXITCODE -ne 0){ throw "Application verification failed (pytest exit code $LASTEXITCODE). Installation was NOT verified." }
Write-Host 'Installation complete. Desktop and Start Menu shortcuts were created.'
Write-Host "Start with the 'R22 Flight School' desktop icon or deploy\START_WINDOWS.ps1. LAN port: $port"
