from sqlalchemy import Column,Integer,String,Float,Boolean,DateTime,ForeignKey,Text,UniqueConstraint
from sqlalchemy.sql import func
from .db import Base
class User(Base):
 __tablename__='users'; id=Column(Integer,primary_key=True); username=Column(String(80),unique=True,index=True,nullable=False); password_hash=Column(String(255),nullable=False); role=Column(String(20),default='student',index=True); full_name=Column(String(120),default=''); active=Column(Boolean,default=True); must_change_password=Column(Boolean,default=True); created_at=Column(DateTime,server_default=func.now())
class Question(Base):
 __tablename__='questions'; id=Column(Integer,primary_key=True); track=Column(String(20),index=True); area=Column(String(80),index=True); prompt=Column(Text); a=Column(Text); b=Column(Text); c=Column(Text); correct=Column(String(1)); explanation=Column(Text); reference=Column(String(200)); difficulty=Column(Integer,default=1); source_kind=Column(String(30),default='authored_training'); active=Column(Boolean,default=True)
class Attempt(Base):
 __tablename__='attempts'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); question_id=Column(Integer,ForeignKey('questions.id')); selected=Column(String(1)); correct=Column(Boolean); mode=Column(String(20),default='study'); seconds=Column(Float,default=0); created_at=Column(DateTime,server_default=func.now())
class Mastery(Base):
 __tablename__='mastery'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE')); area=Column(String(80)); score=Column(Float,default=.25); seen=Column(Integer,default=0); correct=Column(Integer,default=0); __table_args__=(UniqueConstraint('user_id','area'),)
class Assignment(Base):
 __tablename__='assignments'; id=Column(Integer,primary_key=True); instructor_id=Column(Integer,ForeignKey('users.id')); student_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE')); title=Column(String(160)); details=Column(Text); completed=Column(Boolean,default=False); created_at=Column(DateTime,server_default=func.now())
class ATCSession(Base):
 __tablename__='atc_sessions'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE')); scenario=Column(String(80)); transcript=Column(Text,default=''); score=Column(Float,default=0); created_at=Column(DateTime,server_default=func.now())
class OralSession(Base):
 __tablename__='oral_sessions'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE')); transcript=Column(Text,default=''); score=Column(Float,default=0); created_at=Column(DateTime,server_default=func.now())
class Exam(Base):
 __tablename__='exams'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE')); track=Column(String(20)); total=Column(Integer); correct=Column(Integer); score=Column(Float); passed=Column(Boolean); created_at=Column(DateTime,server_default=func.now())
class Audit(Base):
 __tablename__='audit'; id=Column(Integer,primary_key=True); user_id=Column(Integer,nullable=True); action=Column(String(120)); detail=Column(Text); created_at=Column(DateTime,server_default=func.now())
class TrainingRecord(Base):
 __tablename__='training_records'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); module=Column(String(80),index=True); item=Column(String(160)); status=Column(String(20),default='complete'); score=Column(Float,default=0); notes=Column(Text,default=''); created_at=Column(DateTime,server_default=func.now())
class FlightLog(Base):
 __tablename__='flight_logs'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); flight_date=Column(String(20)); aircraft=Column(String(80),default='R22'); tail_number=Column(String(20),default=''); dual_hours=Column(Float,default=0); solo_hours=Column(Float,default=0); night_hours=Column(Float,default=0); instrument_hours=Column(Float,default=0); landings=Column(Integer,default=0); maneuvers=Column(Text,default=''); instructor_notes=Column(Text,default=''); created_at=Column(DateTime,server_default=func.now())
class AircraftProfile(Base):
 __tablename__='aircraft_profiles'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); name=Column(String(80)); model=Column(String(30),default='Beta II'); tail_number=Column(String(20),default=''); empty_weight=Column(Float); empty_arm=Column(Float); notes=Column(Text,default=''); created_at=Column(DateTime,server_default=func.now())
class FlightTrack(Base):
 __tablename__='flight_tracks'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); title=Column(String(120)); points=Column(Text,default='[]'); duration_seconds=Column(Integer,default=0); distance_nm=Column(Float,default=0); created_at=Column(DateTime,server_default=func.now())
class Bookmark(Base):
 __tablename__='bookmarks'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); question_id=Column(Integer,ForeignKey('questions.id',ondelete='CASCADE'),index=True); created_at=Column(DateTime,server_default=func.now()); __table_args__=(UniqueConstraint('user_id','question_id'),)
class LessonProgress(Base):
 __tablename__='lesson_progress'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); lesson_key=Column(String(80),index=True); completed=Column(Boolean,default=False); notes=Column(Text,default=''); updated_at=Column(DateTime,server_default=func.now(),onupdate=func.now()); __table_args__=(UniqueConstraint('user_id','lesson_key'),)
class ExamItem(Base):
 __tablename__='exam_items'; id=Column(Integer,primary_key=True); exam_id=Column(Integer,ForeignKey('exams.id',ondelete='CASCADE'),index=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); question_id=Column(Integer,ForeignKey('questions.id',ondelete='CASCADE'),index=True); selected=Column(String(1)); correct=Column(Boolean); created_at=Column(DateTime,server_default=func.now())

class Certificate(Base):
 __tablename__='certificates'; id=Column(Integer,primary_key=True); user_id=Column(Integer,ForeignKey('users.id',ondelete='CASCADE'),index=True); exam_id=Column(Integer,ForeignKey('exams.id',ondelete='CASCADE'),unique=True,index=True); track=Column(String(30)); score=Column(Float); certificate_code=Column(String(40),unique=True,index=True,nullable=False); issued_at=Column(DateTime,server_default=func.now())
