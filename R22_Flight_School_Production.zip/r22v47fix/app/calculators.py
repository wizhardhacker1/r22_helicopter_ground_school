import math
ARMS={'right':78.0,'left':78.0,'main':108.6,'aux':103.8,'door':77.5,'controls':66.3,'accessory':53.0}
LATERAL_ARMS={'right':10.7,'left':-9.3,'main':-11.0,'aux':11.2,'right_door':21.0,'left_door':-21.0,'controls':-12.9}
def _interp(points,x):
 points=sorted(points)
 if x<=points[0][0]: return points[0][1]
 if x>=points[-1][0]: return points[-1][1]
 for (x1,y1),(x2,y2) in zip(points,points[1:]):
  if x1<=x<=x2: return y1+(y2-y1)*(x-x1)/(x2-x1)
def cg_limits(model,weight):
 # POH Section 2, pages 2-4 and 2-5. Longitudinal envelope digitized from the published breakpoints.
 if model in ('Standard','HP'):
  fwd=_interp([(920,95.5),(1225,95.5),(1300,96.5)],weight)
  aft=_interp([(920,101.5),(1130,101.5),(1300,99.5)],weight)
 else:
  fwd=_interp([(920,95.5),(1275,95.5),(1370,96.5)],weight)
  aft=_interp([(920,102.0),(1175,102.0),(1370,100.0)],weight)
 return round(fwd,2),round(aft,2)
def cg_limits_beta(weight):
 return cg_limits('Beta II',weight)
def _state(empty_weight,empty_arm,pilot,passenger,left_bag,right_bag,main_fuel,aux_fuel,model,left_door_removed=False,right_door_removed=False,empty_lateral_arm=0.0,left_controls_removed=False,accessory_weight=0.0,accessory_lateral_arm=0.0):
 # POH §6: basic empty weight/arms must come from the aircraft's current W&B record.
 items=[(empty_weight,empty_arm,empty_lateral_arm),(pilot+right_bag,ARMS['right'],LATERAL_ARMS['right']),(passenger+left_bag,ARMS['left'],LATERAL_ARMS['left']),(main_fuel*6,ARMS['main'],LATERAL_ARMS['main']),(aux_fuel*6,ARMS['aux'],LATERAL_ARMS['aux'])]
 if left_door_removed: items.append((-5.2,ARMS['door'],LATERAL_ARMS['left_door']))
 if right_door_removed: items.append((-5.2,ARMS['door'],LATERAL_ARMS['right_door']))
 if left_controls_removed: items.append((-2.6,ARMS['controls'],LATERAL_ARMS['controls']))
 if accessory_weight: items.append((accessory_weight,ARMS['accessory'],accessory_lateral_arm))
 w=sum(x for x,_,_ in items); lm=sum(x*a for x,a,_ in items); latm=sum(x*a for x,_,a in items)
 cg=lm/w if w else 0; latcg=latm/w if w else 0; gross=1300 if model in ('Standard','HP') else 1370
 fwd,aft=cg_limits(model,w)
 return {'weight':round(w,1),'moment':round(lm,1),'lateral_moment':round(latm,1),'cg':round(cg,2),'lateral_cg':round(latcg,2),'max_gross':gross,'over_gross':w>gross,'under_minimum':w<920,'cg_forward_limit':fwd,'cg_aft_limit':aft,'cg_in_limits':(fwd<=cg<=aft) if 920<=w<=gross else False,'cg_status':'calculated_against_poh_section_2_envelope'}

def wb(empty_weight,empty_arm,pilot,passenger,left_bag,right_bag,main_fuel,aux_fuel,model='Beta II',fuel_burn_gal=0,left_door_removed=False,right_door_removed=False,empty_lateral_arm=0.0,left_controls_removed=False,accessory_weight=0.0,accessory_lateral_arm=0.0):
 vals=[empty_weight,pilot,passenger,left_bag,right_bag,main_fuel,aux_fuel,fuel_burn_gal,accessory_weight]
 if any(v<0 for v in vals): raise ValueError('Weights, fuel and planned burn cannot be negative')
 if main_fuel>16.9 or aux_fuel>9.4: raise ValueError('Fuel exceeds POH §2 bladder-tank usable capacity (16.9 main / 9.4 aux)')
 if fuel_burn_gal>main_fuel+aux_fuel: raise ValueError('Planned fuel burn exceeds usable fuel entered')
 if accessory_lateral_arm < -12 or accessory_lateral_arm > 12: raise ValueError('POH §6 accessory-mount lateral arm must be within ±12.0 in')
 args=(empty_weight,empty_arm,pilot,passenger,left_bag,right_bag)
 kw=dict(model=model,left_door_removed=left_door_removed,right_door_removed=right_door_removed,empty_lateral_arm=empty_lateral_arm,left_controls_removed=left_controls_removed,accessory_weight=accessory_weight,accessory_lateral_arm=accessory_lateral_arm)
 takeoff=_state(*args,main_fuel,aux_fuel,**kw)
 # Training planning sequence only: auxiliary fuel is reduced first. Operational fuel management follows the POH/checklist.
 rem_aux=max(0,aux_fuel-fuel_burn_gal); burn_left=max(0,fuel_burn_gal-aux_fuel); rem_main=max(0,main_fuel-burn_left)
 landing=_state(*args,rem_main,rem_aux,**kw)
 zero=_state(*args,0,0,**kw)
 alerts=[]
 if left_door_removed: alerts.append('POH §4 CAUTION: left door removed — avoid when practical to protect the tail rotor from loose objects; secure occupants and loose articles.')
 if pilot+right_bag>240: alerts.append('POH §2 LIMIT: right seat plus baggage exceeds 240 lb')
 if passenger+left_bag>240: alerts.append('POH §2 LIMIT: left seat plus baggage exceeds 240 lb')
 if left_bag>50 or right_bag>50: alerts.append('POH §2 LIMIT: a baggage compartment exceeds 50 lb')
 for name,state in [('Takeoff',takeoff),('Landing',landing),('Zero fuel',zero)]:
  if state['over_gross']: alerts.append(f'POH §2 LIMIT: {name} weight exceeds {state["max_gross"]} lb maximum for {model}')
  if state['under_minimum']: alerts.append(f'POH §2 LIMIT: {name} weight is below 920 lb minimum gross weight')
  if state['cg_in_limits'] is False: alerts.append(f'POH §2 LIMIT: {name} longitudinal CG is outside the {model} envelope')
 return {'model':model,'takeoff':takeoff,'landing':landing,'zero_fuel':zero,'fuel_burn_gal':round(fuel_burn_gal,1),'right_seat_plus_bag_over':pilot+right_bag>240,'left_seat_plus_bag_over':passenger+left_bag>240,'bag_over':left_bag>50 or right_bag>50,'alerts':alerts,'poh_basis':{'cg_source':'POH §2 pp. 2-4/2-5; loading arms POH §6 p. 6-4','seat_arms':{'right_long':78.0,'right_lat':10.7,'left_long':78.0,'left_lat':-9.3},'fuel_arms':{'main_long':108.6,'main_lat':-11.0,'aux_long':103.8,'aux_lat':11.2},'main_fuel_arm_in':108.6,'aux_fuel_arm_in':103.8,'usable_fuel_gal':{'main':16.9,'aux':9.4,'combined':26.3},'min_gross_lb':920,'max_gross_lb':takeoff['max_gross'],'max_seat_plus_bag_lb':240,'max_bag_lb':50,'door':{'weight_each':5.2,'long':77.5,'right_lat':21.0,'left_lat':-21.0},'door_weight_each_lb':5.2,'door_long_arm_in':77.5,'removable_controls':{'weight':2.6,'long':66.3,'lat':-12.9},'accessory_mount':{'long':53.0,'lat_range':'±12.0'}},'all_checked_states_in_limits':all(x['cg_in_limits'] is True and not x['over_gross'] and not x['under_minimum'] for x in (takeoff,landing,zero))}

def pressure_altitude(elev,altimeter): return elev+(29.92-altimeter)*1000
def density_altitude(elev,altimeter,oat_c):
 pa=pressure_altitude(elev,altimeter); isa=15-1.98*(pa/1000); return round(pa+120*(oat_c-isa))
def wind_triangle(course,tas,wind_from,wind_speed,distance):
 if tas<=0 or distance<0 or wind_speed<0: raise ValueError('Invalid speed/distance')
 cr=math.radians(course%360); wr=math.radians(wind_from%360); rel=wr-cr; x=(wind_speed/tas)*math.sin(rel)
 if abs(x)>1: return {'possible':False,'reason':'Crosswind component exceeds TAS'}
 wca=math.degrees(math.asin(x)); heading=(course+wca)%360; gs=tas*math.cos(math.radians(wca))-wind_speed*math.cos(rel); mins=(distance/gs*60) if gs>0 else None
 return {'possible':gs>0,'heading':round(heading,1),'wca':round(wca,1),'ground_speed':round(gs,1),'minutes':round(mins,1) if mins is not None else None}
def fuel_plan(main_gal,aux_gal,fuel_flow_gph,planned_minutes,reserve_minutes=20):
 vals=[main_gal,aux_gal,fuel_flow_gph,planned_minutes,reserve_minutes]
 if any(v<0 for v in vals) or fuel_flow_gph<=0: raise ValueError('Invalid fuel-plan value')
 if main_gal>16.9 or aux_gal>9.4: raise ValueError('Fuel exceeds POH bladder-tank usable capacity')
 total=main_gal+aux_gal; endurance=total/fuel_flow_gph*60; remaining=endurance-planned_minutes
 return {'usable_fuel_gal':round(total,1),'endurance_minutes':round(endurance,1),'planned_minutes':round(planned_minutes,1),'reserve_minutes_remaining':round(remaining,1),'meets_selected_reserve':remaining>=reserve_minutes,'selected_reserve_minutes':reserve_minutes}
def e6b(cas,pressure_altitude_ft,oat_c,true_course,wind_from,wind_speed,distance_nm,variation_deg=0,deviation_deg=0):
 if cas<=0 or distance_nm<0: raise ValueError('Invalid E6B input')
 # Standard-atmosphere density approximation; appropriate as a training flight-computer calculation, not approved aircraft performance data.
 h=pressure_altitude_ft*0.3048; t0=288.15; lapse=0.0065; g=9.80665; R=287.05287
 t_std=max(180,t0-lapse*h); p=101325*(t_std/t0)**(g/(R*lapse)); t=273.15+oat_c; rho=p/(R*t); rho0=1.225
 tas=cas*(rho0/rho)**0.5
 w=wind_triangle(true_course,tas,wind_from,wind_speed,distance_nm)
 if not w['possible']: return {'possible':False,'cas':cas,'tas':round(tas,1),**w}
 true_heading=w['heading']; magnetic_heading=(true_heading-variation_deg)%360; compass_heading=(magnetic_heading-deviation_deg)%360
 return {'possible':True,'cas':round(cas,1),'tas':round(tas,1),'true_course':round(true_course%360,1),'wca':w['wca'],'true_heading':round(true_heading,1),'magnetic_heading':round(magnetic_heading,1),'compass_heading':round(compass_heading,1),'ground_speed':w['ground_speed'],'minutes':w['minutes']}
