ACS_AREAS = [
('I','Preflight Preparation',[('A','Pilot Qualifications'),('B','Airworthiness Requirements'),('C','Weather Information'),('D','Cross-Country Flight Planning'),('E','National Airspace System'),('F','Performance and Limitations'),('G','Operation of Systems'),('H','Human Factors')]),
('II','Preflight Procedures',[('A','Preflight Assessment'),('B','Flight Deck Management'),('C','Powerplant Starting and Rotor Engagement'),('D','Before Takeoff Check')]),
('III','Airport and Heliport Operations',[('A','Runway/Taxiway/Heliport/Helipad Signs, Markings, and Lighting'),('B','Communications, Light Signals, and Runway Lighting Systems'),('C','Traffic Patterns')]),
('IV','Hovering Maneuvers',[('A','Vertical Takeoff and Landing'),('B','Hover Taxi'),('C','Air Taxi'),('D','Taxiing with Wheel-Type Landing Gear'),('E','Slope Operations')]),
('V','Takeoffs, Landings, and Go-Arounds',[('A','Normal Takeoff and Climb'),('B','Normal and Crosswind Approach'),('C','Maximum Performance Takeoff and Climb'),('D','Steep Approach'),('E','Go-Around'),('F','Confined Area Operations'),('G','Pinnacle Operations'),('H','Shallow Approach and Running/Roll-On Landing'),('I','Rolling Takeoff (Wheel-Type Landing Gear)')]),
('VI','Performance Maneuvers',[('A','Rapid Deceleration/Quick Stop'),('B','Straight-In Autorotation in a Single-Engine Helicopter'),('C','Autorotation with Turns in a Single-Engine Helicopter')]),
('VII','Navigation',[('A','Pilotage and Dead Reckoning'),('B','Navigation Systems and Radar Services'),('C','Diversion'),('D','Lost Procedures')]),
('VIII','Emergency Operations',[('A','Powerplant Failure in a Hover in a Single-Engine Helicopter'),('B','Powerplant Failure at Altitude in a Single-Engine Helicopter'),('C','Approach and Landing with One Engine Inoperative (Multiengine Only — N/A R22)'),('D','Systems and Equipment Malfunctions'),('E','Vortex Ring State (VRS)'),('F','Low Rotor RPM Recognition and Recovery'),('G','Antitorque System Failure'),('H','Dynamic Rollover'),('I','Ground Resonance'),('J','Low-G Recognition and Recovery'),('K','Emergency Equipment and Survival Gear')]),
('IX','Night Operations',[('A','Night Operations')]),
('X','Postflight Procedures',[('A','After Landing, Parking, and Securing')])]

# Offline study mapping. This is deliberately a coverage map, not a claim of flight proficiency.
RESOURCE_MAP = {
'I':['Training Roadmap','Navigation & FAA Charts','PPL Helicopter Question Bank','POH Mastery','Performance Pad','POH Charts','Oral Checkride'],
'II':['Interactive Preflight','Interactive Startup','Cockpit Flow & Checklists','POH Mastery','Oral Checkride'],
'III':['ATC Radio','PPL Helicopter Question Bank','Training Roadmap','Oral Checkride'],
'IV':['Training Roadmap','PPL Helicopter Question Bank','Oral Checkride','R22 POH Safety Review'],
'V':['Training Roadmap','Performance Pad','POH Charts','PPL Helicopter Question Bank','Oral Checkride'],
'VI':['Emergencies','Training Roadmap','POH Mastery','Oral Checkride'],
'VII':['Navigation & FAA Charts','Training Roadmap','Performance Pad / E6B','ATC Radio','PPL Helicopter Question Bank','Oral Checkride'],
'VIII':['Emergencies','POH Mastery','PPL Helicopter Question Bank','Oral Checkride'],
'IX':['Training Roadmap','PPL Helicopter Question Bank','Oral Checkride'],
'X':['Cockpit Flow & Checklists','POH Mastery','Oral Checkride']}

def coverage_rows():
 out=[]
 for roman,area,tasks in ACS_AREAS:
  for code,name in tasks:
   na='N/A R22' in name
   out.append({'area_code':roman,'area':area,'task_code':code,'task':name,'resources':RESOURCE_MAP[roman], 'ground_covered':True, 'flight_required':not na and roman in {'II','III','IV','V','VI','VII','VIII','IX','X'}, 'na':na})
 return out
