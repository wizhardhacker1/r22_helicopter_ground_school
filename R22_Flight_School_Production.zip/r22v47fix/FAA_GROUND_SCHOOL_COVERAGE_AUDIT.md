# R22 Flight School — 100% FAA-S-ACS-15 Curriculum Coverage Audit (v32)

Audit date: 2026-09-27

## Release gate

The application indexes all 49 tasks in all 10 Areas of Operation of FAA-S-ACS-15 (Private Pilot for Rotorcraft Category — Helicopter Rating, effective May 31, 2024). Every applicable task is mapped to offline learning/practice resources. The curriculum addresses the ACS dimensions of knowledge, risk management, and skill/procedure academics. Multiengine-only Task VIII.C is explicitly N/A to the single-engine R22 rather than falsely counted as an R22 maneuver.

The curriculum also includes R22-specific POH/RFM study, limitations, systems, performance, weight and balance, normal/emergency procedures, SFAR 73 awareness, oral/checkride scenarios, ATC, chart/navigation training, and maneuver academics.

## 18 required ground-school/checkride domains

1. Pilot qualifications / privileges / limitations / endorsements / SFAR 73
2. Airworthiness / inspections / maintenance records / ADs / inoperative equipment
3. Weather theory, products, hazards, briefing and decisions
4. Cross-country planning, charts, NOTAMs/TFRs, pilotage/dead reckoning
5. NAS / airspace / VFR minimums / airport and heliport operations
6. R22 performance and limitations / DA / IGE / OGE / H-V / MAP / Vne
7. R22 weight and balance / actual aircraft records / fuel / doors / CG
8. Helicopter aerodynamics and hazards
9. R22 systems and indications
10. R22 normal procedures
11. R22 emergency procedures and memory/immediate actions
12. ADM / risk management / personal minimums
13. Aeromedical and human factors
14. Night operations
15. ATC / radio / CTAF / tower / readbacks / helicopter requests
16. ACS oral/checkride scenario preparation
17. Practical-maneuver academic preparation
18. FAA knowledge-test preparation with explanations/references

## Completion semantics

A page visit is never completion. Learn/Practice/Test activities record attempted vs completed status. Qualifying assessments, procedural trainers, oral/radio work and the roadmap feed readiness separately. The app may show 100% curriculum coverage because all ACS tasks are mapped, but it does not claim to certify actual flight proficiency. Flight proficiency, aeronautical experience, endorsements and practical-test performance remain CFI/DPE/FAA functions.

## Source control

FAA testing standard: FAA-S-ACS-15, April 2024, effective May 31, 2024.
FAA chart-training reference checked for this release: Aeronautical Chart Users' Guide, effective July 9, 2026.
FAA helicopter reference: Helicopter Flying Handbook FAA-H-8083-21B.
R22 aircraft source: bundled FAA-approved Robinson R22 POH/RFM supplied for the course, with applicable supplements/aircraft records controlling for the individual helicopter.
