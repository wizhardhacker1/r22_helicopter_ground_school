# R22 POH coverage audit — v7

The supplied 212-page R22 POH/RFM was text-extracted and audited across Sections 1–10, the included supplements, Safety Tips, and Safety Notices.

## Section coverage
- §1 General: handbook purpose, descriptive/performance/W&B terminology.
- §2 Limitations: airspeed, rotor RPM, powerplant, weight/CG, maneuvers, kinds of operation, fuel, markings/placards, AD 95-26-04 information.
- §3 Emergency Procedures: separate training scenarios for the power-failure altitude regimes, max glide, restart, water landing, tail-rotor-thrust loss, audio failure, fires, tach/governor issues, warning/caution/audio alerts, and AD wind/turbulence awareness.
- §4 Normal Procedures: preflight, before start, start/run-up, takeoff, cruise, doors-off, autorotation awareness, carb heat, descent/approach/landing, shutdown, noise abatement.
- §5 Performance: cautions, demonstrated temperature, airspeed/density-altitude charts, IGE/OGE charts by model, height-velocity chart, noise.
- §6 Weight & Balance: aircraft-specific records, station arms, fuel, seat/baggage limits, takeoff/planned-landing/zero-fuel states. Beta-family CG envelope is calculated; Standard/HP requires direct chart verification rather than an invented envelope.
- §7 Systems: rotor/drive/powerplant, controls, governor, trim/friction, engine controls, clutch, fuel/electrical/lighting, panel/avionics/audio, pitot-static/tach, warnings, EMU, heat/ventilation, seats/baggage, gear, brake, primer, CO detector, ADS-B, ELT, accessory mounts, camera.
- §8 Handling/Maintenance: documents, inspections, preventive maintenance awareness, alterations, ground handling, parking, doors, oils, fuel bladders, extinguisher, battery, cleaning, storage.
- §9 Supplements: explicit aircraft/equipment applicability awareness.
- §10 Safety: proficiency topics and Safety Notice index, with high-risk R22 subjects integrated into lessons/oral/emergency training.

## Screenshot feature audit
Implemented from the supplied references: gamified roadmap/progress, adaptive study, weak/missed/bookmarked review, practice tests, explanations/references, oral practice, ATC voice/text practice, instructor analytics, offline static PWA shell, daily streak/points, four-part Performance Pad, takeoff/landing/zero-fuel W&B, fuel/endurance/reserve, pressure/density altitude, POH performance charts, E6B-style CAS/TAS/course/WCA/heading/groundspeed/time, saved helicopter profiles, and opt-in flight tracking.

The app never substitutes an invented approximation where the POH requires direct use of a model-specific chart.


## v14 verification
Closed-loop training content is local. Startup trainer uses POH Section 4 pages 4-6/4-7. W&B longitudinal envelopes use Section 2 pages 2-4/2-5 for Standard/HP and Alpha/Beta/Beta II. Chart viewer uses bundled Section 5 images.

## v16 source-grounded visual coverage
- Section 2: model gross-weight/minimum-weight/seat/baggage limits and model-family CG envelopes drive W&B alerts.
- Section 4: interactive visual preflight, before-start, start/run-up, takeoff, doors-off caution, and shutdown study flows.
- Section 5: local full-resolution POH performance chart library; calculated atmosphere values do not pretend to replace chart-derived aircraft performance.
- Section 6: seat/fuel station arms plus door removal (5.2 lb each, 77.5 in longitudinal arm) drive loading calculations.
- Aircraft-specific configuration remains dependent on the helicopter's current approved records, supplements, placards, and installed equipment.
