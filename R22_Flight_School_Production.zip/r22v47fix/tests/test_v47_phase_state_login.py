from pathlib import Path

def t(p): return Path(p).read_text(encoding="utf-8")

def test_login_has_interactive_logo_and_controls():
    h=t("app/templates/login.html"); css=t("app/static/app.css")
    assert "login-heli-logo" in h and "login-rotor" in h and "loginBrand" in h
    assert "togglePassword" in h and "OFFLINE TRAINING READY" in h
    assert "@keyframes loginRotor" in css

def test_flow_has_phase_driven_aircraft_state():
    js=t("app/static/checklists.js")
    assert "function applyPhaseSystemState()" in js
    for phase in ["key==='preflight'", "key==='start'", "key==='takeoff'", "key==='shutdown'"]:
        assert phase in js
    assert "setRpm(103,103)" in js and "setRpm(0,46)" in js and "light('clutch',true)" in js
    assert "applyPhaseSystemState();$('flowActionPanel')" in js

def test_visible_ui_does_not_call_out_user_provenance():
    visible=t("app/templates/checklists.html")+t("app/static/checklists.js")+t("app/static/app.css")
    for phrase in ["YOUR SUPPLIED", "you supplied", "user-supplied", "supplied by you"]:
        assert phrase.lower() not in visible.lower()

def test_v47_cache_bust():
    base=t("app/templates/base.html"); sw=t("app/static/sw.js"); checks=t("app/templates/checklists.html")
    assert "app.css?v=49" in base and "app.js?v=49" in base and "sw.js?v=49" in base
    assert "r22-school-v49-static" in sw and "checklists.js?v=49" in checks
