from pathlib import Path

def txt(p): return Path(p).read_text(encoding='utf-8')

def test_v40_startup_has_no_generic_observation_completion():
    tpl=txt('app/templates/startup.html'); js=txt('app/static/startup.js')
    assert 'id="observeBtn"' not in tpl
    for token in ['sweep-cyclic','throttle-open','prime-open','clear-left','rpm-slider','mag-left','sprag','audio-test']:
        assert token in js
    assert "setRpm(103);light('lowrpm',false);horn(false)" in js

def test_v40_flow_uses_r22_image_and_full_phase_progression():
    tpl=txt('app/templates/checklists.html'); js=txt('app/static/checklists.js')
    assert 'R22 THREE-VIEW' in tpl
    assert 'YOUR SUPPLIED' not in tpl
    version=(Path(__file__).resolve().parents[1]/'VERSION').read_text(encoding='utf-8').strip()
    assert f'/static/r22_preflight_three_view.jpg?v={version}' in tpl
    assert 'flowPhaseSummary' in tpl and 'flowNextPhase' in tpl
    assert 'flowObserve' not in tpl
    for phrase in ['FULL TRAVEL FREE','50–60%','70–75%','≤ 7% / 2 SEC','NEEDLES SPLIT','102–104%']:
        assert phrase in js

def test_v40_r22_image_is_bundled():
    p=Path('app/static/r22_preflight_three_view.jpg')
    assert p.exists() and p.stat().st_size > 200_000
