from pathlib import Path

def test_flow_checklist_is_right_side_sticky_workspace():
    html=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    css=Path("app/static/app.css").read_text(encoding="utf-8")
    assert 'flow-guide flow-guide-right' in html
    assert 'flow-state-summary' in html
    for label in ['CYCLIC','COLLECTIVE','PEDALS','FRICTIONS','SEAT BELTS']:
        assert label in html
    assert '.flow-guide-right{position:sticky!important' in css
    assert 'grid-template-columns:1fr 1fr' in css

def test_v45_cache_bust():
    base=Path("app/templates/base.html").read_text(encoding="utf-8")
    sw=Path("app/static/sw.js").read_text(encoding="utf-8")
    checks=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    assert 'app.css?v=49' in base and 'app.js?v=49' in base and 'sw.js?v=49' in base
    assert 'r22-school-v49-static' in sw
    assert 'checklists.js?v=49' in checks
