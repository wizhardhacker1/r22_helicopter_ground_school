from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def txt(p): return (ROOT/p).read_text(encoding="utf-8")
def test_complete_phase_checklist_is_inside_right_guide_top():
    h=txt("app/templates/checklists.html")
    aside=h.index('<aside class="flow-guide flow-guide-right">')
    ref=h.index('Complete phase checklist')
    state=h.index('flow-state-summary')
    assert aside < ref < state
    assert 'reference-strip' not in h
def test_shutdown_is_expanded_and_interactive():
    j=txt("app/static/checklists.js")
    for token in ["FULL DOWN","WAIT 30 SEC","shutdownThrottle","IDLE CUT-OFF","Battery','OFF LAST","START 30-SECOND PROCEDURAL WAIT"]:
        assert token in j
    assert "setInterval(()=>{remain--" in j
    assert "setRpm(0,46)" in j and "setRpm(0,30)" in j and "setRpm(0,12)" in j
def test_v49_cache_consistent():
    v=txt("VERSION").strip(); assert v=="49"
    assert f"checklists.js?v={v}" in txt("app/templates/checklists.html")
    assert f"r22-school-v{v}-static" in txt("app/static/sw.js")
