$ErrorActionPreference='Stop'
$Root=Split-Path $PSScriptRoot -Parent; Set-Location $Root
$files=Get-ChildItem "$Root\backups\r22school_*.db" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
if(-not $files){throw 'No SQLite backups found in backups folder.'}
Write-Host 'Available backups:'; for($i=0;$i -lt $files.Count;$i++){Write-Host "[$i] $($files[$i].Name) $($files[$i].LastWriteTime)"}
$n=Read-Host 'Enter backup number to restore'; $src=$files[[int]$n]
& "$Root\deploy\STOP_WINDOWS.ps1" -ErrorAction SilentlyContinue
if(Test-Path "$Root\data\r22school.db"){Copy-Item "$Root\data\r22school.db" "$Root\backups\pre-restore-$(Get-Date -Format yyyyMMdd-HHmmss).db"}
Copy-Item $src.FullName "$Root\data\r22school.db" -Force
Write-Host "Restored $($src.Name). Start R22 Flight School normally."
