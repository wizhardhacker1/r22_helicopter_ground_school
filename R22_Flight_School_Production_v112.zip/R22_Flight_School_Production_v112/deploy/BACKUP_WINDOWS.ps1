$ErrorActionPreference='Stop'; $Root=Split-Path $PSScriptRoot -Parent; Set-Location $Root
Get-Content .env | ForEach-Object { if($_ -match '^([^#=]+)=(.*)$'){[Environment]::SetEnvironmentVariable($matches[1].Trim(),$matches[2].Trim(),'Process')} }
$Data=if($env:R22_DATA_DIR){$env:R22_DATA_DIR}else{Join-Path $Root 'data'}; $Backups=Join-Path (Split-Path $Data -Parent) 'backups'; New-Item -ItemType Directory -Force $Backups|Out-Null
$stamp=Get-Date -Format yyyyMMdd_HHmmss; $src=Join-Path $Data 'r22school.db'; $dst=Join-Path $Backups "r22school_$stamp.db"
& .\.venv\Scripts\python.exe -c "import sqlite3; a=sqlite3.connect(r'$src'); b=sqlite3.connect(r'$dst'); a.backup(b); b.close(); a.close()"
Write-Host "SQLite online backup: $dst"; Get-ChildItem $Backups -File|Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-7)}|Remove-Item -Force
