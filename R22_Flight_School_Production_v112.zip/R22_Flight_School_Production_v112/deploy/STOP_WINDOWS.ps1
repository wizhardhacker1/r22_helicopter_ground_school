$Root = Split-Path $PSScriptRoot -Parent; Set-Location $Root
$port='8086'; if(Test-Path .env){ Get-Content .env | ForEach-Object { if($_ -match '^PORT=(.*)$'){$port=$matches[1].Trim()} } }
Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
Write-Host 'R22 Flight School stopped.'
