$ErrorActionPreference='Stop'
$Root = Split-Path $PSScriptRoot -Parent
Set-Location $Root
if(-not (Test-Path '.venv\Scripts\python.exe')){ throw 'R22 Flight School is not installed.' }
$ca=& .\.venv\Scripts\python.exe -c "from app.tls_support import paths; print(paths()['ca_cert'])"
if(-not (Test-Path $ca)){ throw "CA certificate not found: $ca" }
& certutil.exe -user -addstore -f Root $ca
if($LASTEXITCODE -ne 0){ throw "certutil failed with exit code $LASTEXITCODE" }
Write-Host 'Trusted R22 Flight School Local CA for the current Windows user. Restart the browser.'
