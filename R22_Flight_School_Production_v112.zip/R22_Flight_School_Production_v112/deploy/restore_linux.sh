#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
mapfile -t F < <(ls -1t backups/r22school_*.db 2>/dev/null || true)
[ ${#F[@]} -gt 0 ] || { echo 'No SQLite backups found.'; exit 1; }
for i in "${!F[@]}"; do echo "[$i] ${F[$i]}"; done
read -r -p 'Enter backup number to restore: ' N
bash deploy/stop_linux.sh || true
[ -f data/r22school.db ] && cp data/r22school.db "backups/pre-restore-$(date +%Y%m%d-%H%M%S).db"
cp "${F[$N]}" data/r22school.db
echo "Restored ${F[$N]}. Start R22 Flight School normally."
