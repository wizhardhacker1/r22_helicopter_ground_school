#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"; set -a; . ./.env; set +a
DATA="${R22_DATA_DIR:-$ROOT/data}"; BACKUPS="$(dirname "$DATA")/backups"; mkdir -p "$BACKUPS"; stamp=$(date +%Y%m%d_%H%M%S)
PYBIN=.venv/bin/python; [ -x "$PYBIN" ] || PYBIN=python3
"$PYBIN" - "$DATA/r22school.db" "$BACKUPS/r22school_${stamp}.db" <<'PY'
import sqlite3,sys,os
src,dst=sys.argv[1:];
if not os.path.exists(src): raise SystemExit('Database does not exist yet')
a=sqlite3.connect(src); b=sqlite3.connect(dst); a.backup(b); b.close(); a.close(); print('SQLite online backup:',dst)
PY
find "$BACKUPS" -type f -mtime +7 -delete
echo "Backup complete: $stamp"
