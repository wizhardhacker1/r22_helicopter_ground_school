#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
if [ "${EUID}" -eq 0 ]; then echo "Run this as your normal desktop user; it will request sudo only to install the CA."; exit 1; fi
[ -x .venv/bin/python ] || { echo "R22 Flight School is not installed."; exit 1; }
CA="$(.venv/bin/python - <<'PY'
from app.tls_support import paths
print(paths()['ca_cert'])
PY
)"
[ -f "$CA" ] || { echo "CA certificate not found: $CA"; exit 1; }
if command -v update-ca-certificates >/dev/null; then
  sudo cp "$CA" /usr/local/share/ca-certificates/r22-flight-school-local-ca.crt
  sudo update-ca-certificates
  echo "Trusted R22 Flight School Local CA on this Linux computer. Restart the browser."
else
  echo "This system does not provide update-ca-certificates. Install the CA manually: $CA"
  exit 1
fi
