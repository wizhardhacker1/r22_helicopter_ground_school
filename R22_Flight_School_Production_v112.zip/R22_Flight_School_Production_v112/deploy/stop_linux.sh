#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
if [ -f data/server.pid ] && kill -0 "$(cat data/server.pid)" 2>/dev/null; then kill "$(cat data/server.pid)"; rm -f data/server.pid; echo 'R22 Flight School stopped.'; exit 0; fi
set -a; [ -f .env ] && . ./.env; set +a; PORT="${PORT:-8086}"
if command -v fuser >/dev/null; then fuser -k "${PORT}/tcp" >/dev/null 2>&1 || true; fi
echo 'R22 Flight School stopped.'
