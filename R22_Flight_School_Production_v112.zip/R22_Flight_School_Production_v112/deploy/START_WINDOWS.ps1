$ErrorActionPreference='Stop'
$Root = Split-Path $PSScriptRoot -Parent
Set-Location $Root
if (-not (Test-Path '.venv\Scripts\python.exe')) { throw 'R22 Flight School is not installed. Run deploy\INSTALL_WINDOWS.ps1 first.' }
$port = & .\.venv\Scripts\python.exe -c "from dotenv import dotenv_values; print(dotenv_values('.env').get('PORT','8086'))"
$listen = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if (-not $listen) {
  $log = Join-Path $Root 'data\server.log'
  $err = Join-Path $Root 'data\server-error.log'
  Start-Process -FilePath (Join-Path $Root '.venv\Scripts\python.exe') -ArgumentList 'run.py' -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardOutput $log -RedirectStandardError $err
  $ok=$false
  1..30 | ForEach-Object { if(-not $ok){ Start-Sleep -Seconds 1; try { & .\.venv\Scripts\python.exe -c "import ssl,urllib.request; c=ssl._create_unverified_context(); urllib.request.urlopen('https://127.0.0.1:$port/health',context=c,timeout=2).read()" 2>$null; if($LASTEXITCODE -eq 0){$ok=$true} } catch {} } }
  if(-not $ok){ throw "Server did not become ready. Check $err" }
}
Start-Process "https://127.0.0.1:$port/login"
try {
  $ip=(Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.IPAddress -notlike '127.*' -and $_.PrefixOrigin -ne 'WellKnown'} | Select-Object -First 1 -ExpandProperty IPAddress)
  if($ip){ Write-Host "R22 Flight School is also reachable on your LAN at https://${ip}:$port" }
} catch {}
Write-Host "Install the R22 Local CA on each client from Settings & Profile > Network & HTTPS."
