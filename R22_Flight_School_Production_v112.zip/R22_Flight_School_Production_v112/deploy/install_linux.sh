#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
if [ "${EUID}" -eq 0 ]; then
  echo 'ERROR: Do not run the entire R22 installer with sudo.'
  echo 'Run: ./deploy/install_linux.sh'
  echo 'The installer will request sudo only for system packages, CA trust, or firewall-related operations.'
  exit 1
fi
echo 'Installing R22 Flight School for Linux...'
install_apt(){ sudo apt-get update; sudo apt-get install -y python3 python3-venv python3-pip curl ca-certificates; }
install_dnf(){ sudo dnf install -y python3 python3-pip python3-devel curl ca-certificates; }
if ! command -v python3 >/dev/null; then
  if command -v apt-get >/dev/null; then install_apt; elif command -v dnf >/dev/null; then install_dnf; else echo 'Install Python 3.11+ and rerun.'; exit 1; fi
fi
python3 - <<'PY' || { echo 'Python 3.11+ is required.'; exit 1; }
import sys; assert sys.version_info >= (3,11), sys.version
PY
# Repair a virtual environment accidentally created by an earlier sudo install.
if [ -d .venv ] && [ ! -w .venv ]; then
  echo 'Repairing ownership of the existing .venv created by a previous sudo install...'
  sudo chown -R "$(id -un):$(id -gn)" .venv
fi
if ! python3 -m venv .venv 2>/dev/null; then
  if command -v apt-get >/dev/null; then install_apt; python3 -m venv .venv; else echo 'python3 venv support is required.'; exit 1; fi
fi
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
mkdir -p data backups "$HOME/.local/share/applications"
PERSIST_ROOT="$HOME/.local/share/r22-flight-school"; PERSIST_DATA="$PERSIST_ROOT/data"; PERSIST_BACKUPS="$PERSIST_ROOT/backups"; TLS_DIR="$PERSIST_ROOT/tls"
mkdir -p "$PERSIST_DATA" "$PERSIST_BACKUPS" "$TLS_DIR"
if [ -f "$ROOT/data/r22school.db" ] && [ ! -f "$PERSIST_DATA/r22school.db" ]; then cp "$ROOT/data/r22school.db" "$PERSIST_DATA/r22school.db"; echo 'Migrated existing R22 user database to persistent storage.'; fi
if [ ! -f .env ]; then cp .env.example .env; fi
SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
python3 - "$PERSIST_DATA" "$TLS_DIR" "$SECRET" <<'PY'
from pathlib import Path
import sys
path=Path('.env'); data,tls,secret=sys.argv[1:]
vals={
 'APP_NAME':'"R22 Flight School"','ENVIRONMENT':'production','SECRET_KEY':secret,
 'DATABASE_URL':f'sqlite:///{data}/r22school.db','HOST':'0.0.0.0','PORT':'8086',
 'COOKIE_SECURE':'true','SESSION_HOURS':'12','R22_DATA_DIR':data,
 'HTTPS_ENABLED':'true','TLS_DIR':tls,
}
lines=path.read_text(encoding='utf-8').splitlines() if path.exists() else []
out=[]; seen=set()
for line in lines:
    if '=' in line and not line.lstrip().startswith('#'):
        k=line.split('=',1)[0].strip()
        if k in vals:
            # Preserve an existing real secret on upgrades.
            if k=='SECRET_KEY' and line.split('=',1)[1].strip() and not line.split('=',1)[1].startswith('CHANGE-ME'):
                out.append(line); seen.add(k); continue
            out.append(f'{k}={vals[k]}'); seen.add(k); continue
    out.append(line)
for k,v in vals.items():
    if k not in seen: out.append(f'{k}={v}')
path.write_text('\n'.join(out).rstrip()+'\n',encoding='utf-8')
PY
export R22_DATA_DIR="$PERSIST_DATA" DATABASE_URL="sqlite:///$PERSIST_DATA/r22school.db" HTTPS_ENABLED=true TLS_DIR="$TLS_DIR" COOKIE_SECURE=true ENVIRONMENT=production
# Load the generated secret without shell-sourcing the .env file.
export SECRET_KEY="$(python3 - <<'PY'
from dotenv import dotenv_values
print(dotenv_values('.env').get('SECRET_KEY',''))
PY
)"
echo 'Creating/preserving the private R22 Flight School Local CA and HTTPS server certificate...'
python deploy/setup_https.py
# Trust this installation on the server itself. Client devices install only the public CA certificate.
if command -v update-ca-certificates >/dev/null; then
  CA_FILE="$(python - <<'PY'
from app.tls_support import paths
print(paths()['ca_cert'])
PY
)"
  sudo cp "$CA_FILE" /usr/local/share/ca-certificates/r22-flight-school-local-ca.crt
  sudo update-ca-certificates >/dev/null
  echo 'R22 Flight School Local CA trusted on this Linux computer.'
else
  echo 'WARNING: update-ca-certificates is unavailable; install the Local CA manually on this server.'
fi
echo 'Installing required FAA Los Angeles Sectional, TAC, and Helicopter Route charts...'
python deploy/install_faa_charts.py 2>&1 | tee FAA_CHART_INSTALL.log || { echo 'ERROR: required FAA chart installation failed. Installation cannot complete without the offline chart lab. See FAA_CHART_INSTALL.log.'; exit 1; }
echo 'FAA offline chart payload verified.'
python -c 'from app.main import startup; startup(); print("Database initialized")'
ICON="$ROOT/app/static/icons/icon-512.png"
DESKTOP_FILE="$HOME/.local/share/applications/r22-flight-school.desktop"
cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=R22 Flight School
Comment=Start R22 Flight School
Exec="$ROOT/deploy/start_linux.sh"
Icon=$ICON
Terminal=false
Categories=Education;Utility;
StartupNotify=true
EOF
chmod +x "$DESKTOP_FILE"
if [ -d "$HOME/Desktop" ]; then cp "$DESKTOP_FILE" "$HOME/Desktop/R22 Flight School.desktop"; chmod +x "$HOME/Desktop/R22 Flight School.desktop"; fi
if command -v systemctl >/dev/null; then
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/r22-flight-school.service" <<EOF
[Unit]
Description=R22 Flight School HTTPS Server
After=network.target
[Service]
Type=simple
WorkingDirectory=$ROOT
EnvironmentFile=$ROOT/.env
ExecStart=$ROOT/.venv/bin/python $ROOT/run.py
Restart=on-failure
RestartSec=3
[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload >/dev/null 2>&1 || true
fi
chmod +x deploy/*.sh
R22_TESTING=true python -m pytest -q
PORT=8086
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo 'Installation complete. Application-menu launcher created.'
[ -d "$HOME/Desktop" ] && echo "Desktop launcher created: $HOME/Desktop/R22 Flight School.desktop"
echo "Start with the R22 Flight School icon or: $ROOT/deploy/start_linux.sh"
echo "Local HTTPS: https://127.0.0.1:${PORT}"
[ -n "$IP" ] && echo "LAN HTTPS: https://${IP}:${PORT}"
echo 'For another LAN device: open Settings & Profile > Network & HTTPS, download the Local CA, and trust it on that device.'
