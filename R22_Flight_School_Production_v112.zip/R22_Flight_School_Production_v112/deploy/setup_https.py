from pathlib import Path
import os, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.tls_support import ensure_tls, paths
s=ensure_tls()
p=paths()
print('R22 Flight School HTTPS certificate ready.')
print('Local CA certificate:',p['ca_cert'])
print('Server certificate:',p['server_cert'])
print('DNS SANs:',', '.join(s.get('dns_names',[])))
print('IP SANs:',', '.join(s.get('ip_addresses',[])))
print('CA SHA-256:',s.get('ca_sha256',''))
