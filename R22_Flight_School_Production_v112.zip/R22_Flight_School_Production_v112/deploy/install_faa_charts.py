from pathlib import Path
import os
import sys
import traceback

# This file is launched directly by the Windows/Linux installers.  When Python
# executes deploy/install_faa_charts.py, sys.path[0] is the deploy directory,
# not the application root.  Bootstrap the real project root before importing
# app so a clean extracted installer behaves the same way as the installed app.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
project_root_text = str(PROJECT_ROOT)
if project_root_text not in sys.path:
    sys.path.insert(0, project_root_text)
os.chdir(PROJECT_ROOT)

from app.main import _faa_chart_dir, _build_faa_tiles, _verify_chart_tiles, FAA_CHARTS

if '--bootstrap-check' in sys.argv:
    print(f'FAA_INSTALLER_BOOTSTRAP_OK root={PROJECT_ROOT}', flush=True)
    raise SystemExit(0)

def main():
    d = _faa_chart_dir()
    print(f'FAA chart destination: {d}', flush=True)
    for kind, meta in FAA_CHARTS.items():
        print(f'\n[{kind.upper()}] Downloading and building {meta["name"]}', flush=True)
        print(f'Source: {meta["zip"]}', flush=True)
        try:
            result = _build_faa_tiles(kind, d)
            print(f'[{kind.upper()}] build complete: {result}', flush=True)
            check = _verify_chart_tiles(d, kind)
            if not check.get('ok'):
                raise RuntimeError(f'post-build verification failed: {check}')
            print(f'[{kind.upper()}] verified: {check}', flush=True)
        except Exception as exc:
            print(f'\nFAA CHART INSTALL ERROR [{kind}]: {type(exc).__name__}: {exc}', file=sys.stderr, flush=True)
            traceback.print_exc()
            return 20
    print('\nAll required FAA charts installed and verified for offline use.', flush=True)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
