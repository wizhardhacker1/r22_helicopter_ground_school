# R22 Flight School - Production v7

Multi-user R22 student-pilot training platform with Student, Instructor, and Admin roles; R22 POH study; structured lessons; adaptive/weak/missed/bookmarked study; practice exams; oral training; emergency recall; ATC voice/text practice; R22 W&B/performance/flight-computer tools; aircraft profiles; logbook; flight tracking; instructor review; audit log; backup/restore; PWA assets; and Windows/Linux desktop launchers.

## Windows
Extract the ZIP, then double-click `INSTALL_WINDOWS.bat`.

The installer detects/installs a compatible Python when possible, creates `.venv`, installs dependencies, creates a random application secret, initializes the database, runs the automated test suite, attempts to open TCP 8086 in Windows Firewall, and creates branded Desktop and Start Menu shortcuts.

Start later with the **R22 Flight School** desktop icon or `START_R22_FLIGHT_SCHOOL.bat`.

## Linux
From the extracted directory:

```bash
bash deploy/install_linux.sh
```

The installer supports apt- and dnf-based distributions, creates the virtual environment/database, runs tests, creates application-menu/Desktop launchers when available, and writes a user-level systemd service definition.

Start with the **R22 Flight School** icon or:

```bash
bash deploy/start_linux.sh
```

## Initial account
`admin` / `ChangeMe123!`

The bootstrap administrator is forced to change this password at first login. New installs generate a random 48-character session secret.

## Network
Default bind: `0.0.0.0:8086`. The launcher opens the local browser and reports the LAN URL.

For Internet deployment, use PostgreSQL and trusted HTTPS, set `ENVIRONMENT=production` and `COOKIE_SECURE=true`. Trusted HTTPS is also needed for reliable browser secure-context features such as geolocation/PWA behavior on remote devices.

## R22 training coverage
The app indexes all ten POH sections and includes focused lessons for documents/airworthiness, aerodynamics, systems/controls, preflight/start/run-up/shutdown, hover/ground risk, takeoff/landing, flight maneuvers, emergencies, performance/W&B, weather/ADM, navigation/airspace, ATC, night, written readiness, and oral/practical-test readiness.

The emergency trainer now covers the distinct POH Section 3 subjects instead of treating all emergencies as one generic exercise. The oral trainer contains a larger rotating R22 bank and stores sessions for instructor review.

## Performance Pad
The four-part workflow follows the supplied reference screenshots:

1. Weight & Balance - takeoff, planned-landing, and zero-fuel states; baggage/seat limits; usable fuel; Beta-family longitudinal envelope checks.
2. Performance - pressure altitude, density altitude, and direct access to model-specific POH IGE/OGE, airspeed, and height-velocity charts.
3. Flight Time / E6B - CAS-to-TAS training estimate, true course, WCA, true/magnetic/compass heading, groundspeed, flight time, fuel endurance and reserve.
4. Helicopter - saved aircraft-specific empty weight/arm, tail number, model and configuration notes.

For Standard/HP CG, the calculator intentionally reports `verify_standard_hp_poh_chart` rather than falsely applying the later Alpha/Beta/Beta II envelope.

## Study engine
Study modes: Adaptive, Weak Areas, Missed Questions, and Bookmarks. Explanations and references are shown after answers. Admins can import authored/licensed question banks by CSV with columns:

`track,area,prompt,a,b,c,correct,explanation,reference,difficulty,source_kind`

The bundled large synthetic PPL/IFR records are explicitly marked `synthetic_training`; they are not represented as FAA live test questions. FAA's published PRH sample material and the current FAA-S-ACS-15 remain the authoritative basis for current test structure/standards.

## ATC
Towered and non-towered scenarios include initial calls, taxi/hold-short, pattern, departure, arrival, flight following, frequency changes, heading/altitude assignments and emergencies. Students can type or use browser speech recognition. Controller prompts and responses can be spoken with browser text-to-speech. Each attempt is scored and stored.

## Instructor/Admin
Instructors see assigned students and can review mastery, exams, ATC, oral work, assignments and flight logs. Admins manage users, enable/disable/delete accounts, reset passwords, assign students to instructors, import question banks, and review recent audit events.

## Backup / restore
SQLite backup uses the SQLite online backup API so WAL-mode databases are copied consistently while the app is running.

Linux: `deploy/backup_linux.sh` and `deploy/restore_linux.sh`  
Windows: `deploy\BACKUP_WINDOWS.ps1` and `deploy\RESTORE_WINDOWS.ps1`

Backups rotate after seven days. PostgreSQL backup uses `pg_dump` when available.

## Verification
Run:

```bash
python -m pytest -q
```

v7's automated suite covers calculators, three-state W&B, Standard/HP chart-verification behavior, authentication flow, security headers, authenticated UI routes, POH/manifest serving, performance/fuel/E6B/ATC APIs, and application startup.

The application is a training aid. The supplied R22 POH itself states that it is not a substitute for competent flight instruction and must be current for operational use.

## v8 completeness audit additions
- Backup/Restore is now available inside the Admin UI, not only as command-line scripts. Admins can create, list, download, integrity-check, and restore SQLite backups. A pre-restore safety backup is created automatically.
- Practice Exam Center now provides PPL, R22, and IFR exam entry points, exam history, countdown timing, automatic question rotation, full post-exam answer/explanation/reference review, and a direct missed-question study path.
- Automatic exam rotation prioritizes questions the student has never seen on a prior practice exam, then the least-recently used exam questions. It therefore avoids immediate repeats while still returning older material for retention.
- Exam selections and results are stored per student in `exam_items`, so rotation survives application restarts.

## Built-in question bank (v10)
The application now ships with an authored study bank and does not require a CSV import before use. The old numbered synthetic load-test pool is automatically deactivated on startup. PPL questions are mapped to helicopter ACS/study topics; R22 questions are grounded in the supplied POH. The Question Bank Library shows installed counts and coverage and links to the official FAA PRH sample questions, FAA-S-ACS-15, and testing supplements. CSV import remains available only for instructor-authored or properly licensed additions.

## v11 - Visual Learning / Flight-Deck UI
- Rebuilt Performance Pad as a four-tab visual workspace instead of text-heavy forms.
- Live TO/LD/ZF W&B readouts and interactive CG plot with R22 loading diagram.
- Model-aware embedded POH OGE charts, atmospheric digital readouts, chart marker, and manifold-pressure training gauge.
- Visual main/aux fuel gauges, endurance/reserve status, compass/heading visualization, and E6B readouts.
- Rebuilt dashboard with readiness ring, metric strip, large training action tiles, and mastery progress bars.
- Modernized global UI: sticky navigation, responsive panels, stronger hierarchy, mobile layouts, and visual status feedback.
- Existing calculations, warnings, POH references, authentication, backups, exams, certificates, instructor/admin features remain intact.

## v13 visual training and upgrade-safe storage
- Professional desktop left navigation rail; mobile navigation drawer.
- Interactive R22 startup trainer based on supplied POH Section 4 Before Starting Engine and Starting Engine/Run-Up sequence.
- Printable startup reference card inside the trainer.
- POH chart library opens charts in a large zoomable viewer with purpose, reading steps, applicability notes, and training cautions.
- Weight-and-balance alerts are generated from POH model gross-weight, minimum-weight, seat+baggage, baggage, fuel-capacity, station-arm and CG checks.
- User database is stored outside the replaceable application payload after installation. Windows uses `%LOCALAPPDATA%\\R22FlightSchool\\data`; Linux uses `~/.local/share/r22-flight-school/data`. Existing local databases are migrated on first v13 installation when persistent storage is empty.
- Backups live beside persistent data, not inside the application payload.

## v14 closed-loop training release
- Training and exam workflows are self-contained: the active question bank, explanations, R22 POH, Section 5 chart images, startup trainer/reference card, oral preparation, emergencies and calculators do not require Internet access.
- Replaced the startup hotspot demo with a control-driven cockpit trainer. Students operate the applicable switch/lever/control or complete an observation; out-of-sequence actions are rejected.
- Startup trainer/reference card follows the bundled R22 POH Section 4 Before Starting Engine (4-6) and Starting Engine & Run-Up (4-7) sequence.
- W&B now evaluates both Standard/HP and Alpha/Beta/Beta II longitudinal CG envelopes using the published Section 2 chart breakpoints, in addition to model gross-weight, minimum-weight, seat+baggage and baggage-compartment limits.
- POH chart cards are keyboard/click accessible and open a full-size zoom viewer with a local reading guide.
- Removed Internet-only FAA links from the Question Bank UI. The bundled R22 POH and local chart library are the offline references used by the app.
- Added automated closed-loop asset tests that fail if templates/static UI require external HTTP/HTTPS resources.
- Persistent user data remains outside the replaceable application payload so upgrades do not overwrite the live database.
- v14 runtime persistence: even when launched directly during development (without the installer), the app treats the old `./data` database as a legacy migration source and uses the OS user-data location for the live SQLite database. This prevents extracting a new application version from silently starting with a fresh user database.

## v16 POH-grounded visual training update
- Performance Pad W&B now supports left/right door removal as an actual loading configuration. Each removed door subtracts 5.2 lb at 77.5 in per POH Section 6; left-door removal displays the Section 4 loose-object/tail-rotor caution.
- R22 Checklist & Cockpit Flow Study is now an interactive visual trainer with POH-guided preflight walk-around, before-start, start/run-up, takeoff, and shutdown phases.
- Navigation and all major visual workspaces are constrained to the browser viewport with independently scrollable sidebar navigation and responsive reflow.
- Training templates/static assets contain no external HTTP/CDN runtime dependency; the bundled POH and local chart library remain available offline.
- R22-specific data is labeled to its POH section. Aircraft-specific empty weight/arm must come from the actual helicopter's current weight-and-balance record.


## v21 - Teaching/Test modes and FAA ACS coverage audit
- Interactive Startup and Checklist/Cockpit Flow trainers now have Learn, Practice, and Test modes.
- Correct completed controls/checklist items change to a completed state; incorrect/out-of-sequence actions are scored as corrections.
- Test mode removes control highlighting and hides unrevealed checklist answers.
- Interactive session score, corrections, elapsed time, and completion are saved to the user training record.
- Added an offline FAA-S-ACS-15 task-level coverage audit covering Areas of Operation I-X and all 49 listed tasks, including explicit N/A treatment for the multiengine-only OEI task on an R22.
- Coverage distinguishes offline ground/oral preparation from actual flight proficiency, which requires authorized instruction/evaluation.
- FAA source checked for this release: FAA-S-ACS-15 (Private Pilot Rotorcraft Category Helicopter Rating), current FAA ACS listing checked September 2026.

## v22 Navigation & FAA Charts Ground School
Adds a fully local Learn -> Practice -> Test chart-reading course covering Sectional fundamentals, airports/heliports, airspace, terrain/MEF/obstacles, NAVAIDs, VFR route planning, helicopter route charts, Chart Supplement/NOTAM use, diversion/lost procedures, and cross-country workflow. Official FAA links are supplemental for current operational products; locally drawn chart examples are training-only and not for navigation.


## v30 verification focus
- Flight Computer uses a self-contained page handler with visible pending/error/result states.
- Static service worker is network-first for versioned JS/CSS to prevent stale calculator code.
- FAA_GROUND_SCHOOL_COVERAGE_AUDIT.md defines the release-gate coverage matrix for FAA private-helicopter/R22 ground-school preparation.

## v31 update
The interactive preflight walk-around now uses the bundled user-supplied real R22 three-view photograph (left profile, right profile, top view) as the offline clickable inspection surface. Learn highlights the current region; correct selections complete green, wrong selections show red, and valid out-of-sequence selections show amber.

## v52 - Full R22 Academy

v52 adds a complete beginner-focused R22 Academy with 18 source-mapped courses and required interactive practicums: Radio Academy, integrated preflight briefing/dispatch, stabilized hover checks, R22 systems, carburetor ice, rotor energy, height-velocity, wind/unanticipated yaw, wire hazards, dynamic rollover, vortex ring state, low-G/mast-bumping, IIMC/night risk, passenger/ramp safety, annunciators, scenario oral, personal minimums/ADM, and FAA/Robinson publication currency. The sidebar is reorganized into nested Ground School, R22 Aircraft, Radio & Navigation, Safety & Flight Labs, Checkride, Records, and School groups.

Live ATC listening is an optional connected resource; the Radio Academy and all required course material remain functional offline. Course completion requires all lesson acknowledgements and a passing practicum and does not represent an FAA endorsement or flight-proficiency determination.
