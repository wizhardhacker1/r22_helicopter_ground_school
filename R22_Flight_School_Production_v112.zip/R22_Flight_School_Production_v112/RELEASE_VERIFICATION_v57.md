# R22 Flight School Production v57 - Chart Lab

- Replaced the 1,800-pixel single-image FAA chart renderer with a local 512px multi-resolution tile pyramid generated from the official FAA GeoTIFF at source detail.
- Added offline tile manifest and tile-serving endpoints for Sectional and Helicopter Route Chart.
- Added GeoTIFF-derived training-feature coordinates; overlays are calculated against the real FAA raster.
- Learn mode exposes teaching hotspots; Practice/Test require chart-location interaction without answer markers.
- Refresh builds the same high-resolution offline tile format and leaves existing charts intact on refresh failure.
- Bundled chart seeding now expects a complete `app/static/faa_charts/<kind>/manifest.json` + tile tree and never overwrites newer persistent media.
- Removed the connected-install prerequisite wording. Refresh is maintenance/update behavior.

Validation: 111 pytest tests passed; Python compilation passed; JavaScript syntax validation passed; 34 Jinja templates parsed.

Packaging note: this environment could not retrieve the FAA GeoTIFF ZIP binaries from aeronav.faa.gov, so the archive contains the bundling/seeding architecture but not the FAA tile payload itself. A chart refreshed on a connected installation will use the new high-resolution tile pipeline.
