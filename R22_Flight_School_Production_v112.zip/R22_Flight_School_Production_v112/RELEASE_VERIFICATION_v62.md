# Release Verification v62

- Windows BAT remains the supported double-click installer entry point.
- Removed native Python stderr pipeline through Tee-Object that could trigger Windows PowerShell NativeCommandError under ErrorActionPreference=Stop.
- FAA chart installer now runs via Start-Process with separate redirected stdout/stderr files.
- Complete Python output is combined into FAA_CHART_INSTALL.log and printed before fail-closed handling.
- BAT pauses on nonzero PowerShell exit so diagnostics remain visible.
