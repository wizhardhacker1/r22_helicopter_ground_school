# R22 Flight School v61 verification

- Fixed clean-install FAA chart dependency packaging: Pillow, NumPy, certifi are explicit requirements.
- FAA downloads use httpx streaming with redirects and explicit HTTP failure reporting.
- Dedicated deploy/install_faa_charts.py installs Sectional, TAC, Helicopter sequentially and verifies each generated tile set.
- Windows installer preserves full chart-install output in FAA_CHART_INSTALL.log and surfaces the real exception on failure.
- Linux installer uses the same chart driver and log.
- Existing chart render integrity checks remain fail-closed.
- 127 pytest tests passed.
- Python compileall passed.
- JavaScript syntax checks passed.
- 34 Jinja templates parsed.
