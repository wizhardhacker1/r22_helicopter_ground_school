# R22 Flight School v112 — HTTPS / Local CA + Installer Audit

## HTTPS
- Generates a unique R22 Flight School Local CA per installation.
- CA private key remains only in persistent server TLS storage and is never bundled or downloadable.
- Server certificate is signed by that CA.
- Certificate SANs include localhost, r22school.local, server hostname, hostname.local, loopback, and detected LAN IPv4 addresses.
- Server certificate refreshes when hostname/LAN IP changes while preserving the trusted Local CA.
- Uvicorn serves HTTPS on port 8086.
- Secure cookies are enabled for runtime HTTPS.
- Settings & Profile includes Network & HTTPS status, CA fingerprint, SANs, expiry, public CA download, client trust instructions, and admin server-certificate regeneration.

## Windows
- Installer generates/preserves TLS material under persistent LocalAppData storage.
- Public CA is installed into the current-user Windows Root trust store with certutil.
- TRUST_R22_CERTIFICATE_WINDOWS.bat is included for manual/repeat trust installation.
- Launcher and readiness checks use HTTPS.

## Linux
- Installer refuses whole-script sudo execution.
- Repairs a .venv left root-owned by an earlier sudo install.
- APP_NAME is safely quoted; installer no longer shell-sources .env.
- Public CA is installed through update-ca-certificates.
- INSTALL_LINUX.sh and TRUST_R22_CERTIFICATE_LINUX.sh root helpers are included.
- Launcher and readiness checks use HTTPS.

## Verification
- 311 pytest regression tests pass.
- Test suite also passes under production-style HTTPS/secure-cookie installer environment with R22_TESTING isolation.
- Python compileall passes.
- All JavaScript syntax checks pass.
- All shell installer/helper scripts pass bash -n.
- 49 Jinja templates parse.
- No duplicate literal DOM IDs found.
- No baked-in HTML entity / invalid Unicode artifacts found.
- 19/19 Emergency Procedures scenario routes load.
- 42/42 Student Pilot Roadmap links load.
- HTTPS server was launched and /health returned successfully over TLS.
- Certificate generation verified SANs, CA key mode 0600, and CA-preserving server-certificate regeneration.
- CA download and Network & HTTPS profile UI verified.
