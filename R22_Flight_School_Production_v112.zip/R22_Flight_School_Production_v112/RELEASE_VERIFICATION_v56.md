# R22 Flight School v56 verification

## Changes
- Added bundled FAA chart seeding architecture: validated production chart PNGs under `app/static/faa_charts/` are copied into persistent `data/faa_charts` on first use while preserving later refreshed/current copies.
- Chart Lab messaging no longer instructs students that a connected first-run download is the normal production path; simulated charts remain prohibited.
- Existing FAA GeoTIFF refresh/update path remains available for connected updates.
- Improved offline ATC system-voice selection by preferring higher-quality local English voices, remembering separate controller/pilot choices, adding more natural radio-style pacing, distinct pitch, and a longer exchange pause. No crude bundled WAVs were restored.
- Asset/service-worker version bumped to v56 without changing the existing cockpit/startup/flow modules.

## Validation actually run
- Python compilation: PASS
- Pytest regression suite: 108 passed
- JavaScript syntax: PASS for navigation_charts.js, atc_offline.js, startup.js, checklists.js, app.js
- Jinja parse: PASS, 34 templates
- Fake FAA-style chart string/content check: PASS

## Packaging blocker in this execution environment
The authoritative FAA web source was verified as Sep 03 2026 current / Oct 29 2026 next for both Los Angeles Sectional and Los Angeles Helicopter Route Chart, but the execution container cannot resolve/download external hosts. Therefore the official GeoTIFF-derived PNG files could not be physically added to `app/static/faa_charts/` in this run. The code is prepared to bundle them, but this archive must not be represented as satisfying the closed-loop chart-asset requirement until those official assets are inserted and validated.
