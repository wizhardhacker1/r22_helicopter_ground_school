"""FAA chart package updater. Network is used only during an explicit update/install; training remains offline afterward."""
from pathlib import Path
import os, re, shutil, tempfile, urllib.request, zipfile
from urllib.parse import urljoin

FAA_VFR_PAGE='https://www.faa.gov/air_traffic/flight_info/aeronav/digital_products/vfr/'
FAA_LA_ZIP='https://aeronav.faa.gov/visual/09-03-2026/sectional-files/Los_Angeles.zip'  # verified fallback for current cycle
CURRENT_EDITION='Sep 03 2026'
NEXT_EDITION='Oct 29 2026'
# Training crop around KLGB; source remains the official georeferenced Los Angeles Sectional.

def discover_current_los_angeles():
    """Discover the current official Los Angeles Sectional link from FAA; fall back to the verified current-cycle URL if the page layout changes."""
    try:
        req=urllib.request.Request(FAA_VFR_PAGE,headers={'User-Agent':'R22FlightSchool/34 FAA-content-updater'})
        html=urllib.request.urlopen(req,timeout=30).read().decode('utf-8','ignore')
        # FAA links contain /visual/MM-DD-YYYY/sectional-files/Los_Angeles.zip
        m=re.search(r'https?://aeronav\.faa\.gov/visual/(\d{2}-\d{2}-\d{4})/sectional-files/Los_Angeles\.zip',html,re.I)
        if not m:
            m=re.search(r'href=["\']([^"\']*/visual/(\d{2}-\d{2}-\d{4})/sectional-files/Los_Angeles\.zip)["\']',html,re.I)
            if m: return urljoin(FAA_VFR_PAGE,m.group(1)),m.group(2)
        if m: return m.group(0),m.group(1)
    except Exception:
        pass
    return FAA_LA_ZIP,'09-03-2026'

KLGB_BOUNDS=(-118.38,33.62,-117.90,34.03)  # west,south,east,north; broad enough for context, not an operational route definition

def install_long_beach_chart(dest='app/static/faa_sectional_long_beach.png', package_dest='data/FAA_Los_Angeles_Sectional_2026-09-03.zip'):
    import rasterio
    from rasterio.windows import from_bounds
    from rasterio.warp import transform_bounds
    dest=Path(dest); package_dest=Path(package_dest); dest.parent.mkdir(parents=True,exist_ok=True); package_dest.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='r22faa_') as td:
        tmp=Path(td)/'Los_Angeles.zip'
        source_url,cycle=discover_current_los_angeles()
        req=urllib.request.Request(source_url,headers={'User-Agent':'R22FlightSchool/34 FAA-content-updater'})
        with urllib.request.urlopen(req,timeout=120) as r, tmp.open('wb') as out:
            shutil.copyfileobj(r,out,1024*1024)
        if tmp.stat().st_size < 1_000_000 or not zipfile.is_zipfile(tmp):
            raise ValueError('Official FAA Los Angeles chart download failed ZIP validation')
        shutil.copy2(tmp,package_dest)
        with zipfile.ZipFile(tmp) as z:
            tif_names=[n for n in z.namelist() if n.lower().endswith(('.tif','.tiff')) and 'los' in n.lower()]
            if not tif_names: tif_names=[n for n in z.namelist() if n.lower().endswith(('.tif','.tiff'))]
            if not tif_names: raise ValueError('No GeoTIFF found in official FAA package')
            z.extract(tif_names[0],td); tif=Path(td)/tif_names[0]
        with rasterio.open(tif) as src:
            if not src.crs: raise ValueError('FAA GeoTIFF has no CRS')
            left,bottom,right,top=transform_bounds('EPSG:4326',src.crs,*KLGB_BOUNDS,densify_pts=21)
            win=from_bounds(left,bottom,right,top,src.transform).round_offsets().round_lengths()
            win=win.intersection(rasterio.windows.Window(0,0,src.width,src.height))
            out_h=1200; out_w=max(900,round(out_h*(win.width/win.height)))
            data=src.read(window=win,out_shape=(src.count,out_h,out_w),resampling=rasterio.enums.Resampling.bilinear)
            profile={'driver':'PNG','height':out_h,'width':out_w,'count':src.count,'dtype':data.dtype}
            tmp_png=dest.with_suffix('.tmp.png')
            with rasterio.open(tmp_png,'w',**profile) as dst: dst.write(data)
            os.replace(tmp_png,dest)
    return {'chart':str(dest),'package':str(package_dest),'edition':cycle,'source':source_url}

if __name__=='__main__':
    print(install_long_beach_chart())
