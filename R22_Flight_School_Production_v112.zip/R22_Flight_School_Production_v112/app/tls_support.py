from __future__ import annotations
import datetime as dt
import hashlib
import ipaddress
import json
import os
import socket
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID

CA_NAME = "R22 Flight School Local CA"
SERVER_NAME = "R22 Flight School LAN Server"


def _tls_dir() -> Path:
    raw = os.getenv("TLS_DIR", "").strip()
    if raw:
        return Path(raw).expanduser().resolve()
    data = Path(os.getenv("R22_DATA_DIR", "data")).expanduser().resolve()
    return data.parent / "tls"


def paths() -> dict[str, Path]:
    d = _tls_dir()
    return {
        "dir": d,
        "ca_key": d / "r22-local-ca.key",
        "ca_cert": d / "R22_Flight_School_Local_CA.crt",
        "server_key": d / "r22-server.key",
        "server_cert": d / "r22-server.crt",
        "meta": d / "tls-metadata.json",
    }


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _local_names_ips() -> tuple[list[str], list[str]]:
    host = socket.gethostname().strip() or "r22-flight-school"
    names = {"localhost", "r22school.local", host}
    if "." not in host:
        names.add(f"{host}.local")
    ips = {"127.0.0.1"}
    try:
        for item in socket.getaddrinfo(host, None, socket.AF_INET, socket.SOCK_STREAM):
            addr = item[4][0]
            if addr and not addr.startswith("127."):
                ips.add(addr)
    except OSError:
        pass
    # Discover the preferred LAN source address without sending data.
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.0.2.1", 9))
            addr = s.getsockname()[0]
            if addr and not addr.startswith("127."):
                ips.add(addr)
        finally:
            s.close()
    except OSError:
        pass
    return sorted(names), sorted(ips, key=lambda x: tuple(int(n) for n in x.split('.')))


def _write_private_key(path: Path, key) -> None:
    path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _write_cert(path: Path, cert: x509.Certificate) -> None:
    path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
    try:
        os.chmod(path, 0o644)
    except OSError:
        pass


def _new_ca(p: dict[str, Path]) -> tuple[object, x509.Certificate]:
    key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    subject = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "R22 Flight School"),
        x509.NameAttribute(NameOID.COMMON_NAME, CA_NAME),
    ])
    now = _now()
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(days=1))
        .not_valid_after(now + dt.timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False, key_encipherment=False, data_encipherment=False, key_agreement=False, key_cert_sign=True, crl_sign=True, encipher_only=False, decipher_only=False), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
        .sign(key, hashes.SHA256())
    )
    _write_private_key(p["ca_key"], key)
    _write_cert(p["ca_cert"], cert)
    return key, cert


def _load_ca(p: dict[str, Path]):
    key = serialization.load_pem_private_key(p["ca_key"].read_bytes(), password=None)
    cert = x509.load_pem_x509_certificate(p["ca_cert"].read_bytes())
    return key, cert


def _server_cert_needs_refresh(path: Path, names: list[str], ips: list[str]) -> bool:
    if not path.exists():
        return True
    try:
        cert = x509.load_pem_x509_certificate(path.read_bytes())
        if cert.not_valid_after_utc < _now() + dt.timedelta(days=45):
            return True
        san = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        dns = set(san.get_values_for_type(x509.DNSName))
        ipvals = {str(x) for x in san.get_values_for_type(x509.IPAddress)}
        return not set(names).issubset(dns) or not set(ips).issubset(ipvals)
    except Exception:
        return True


def _new_server(p: dict[str, Path], ca_key, ca_cert, names: list[str], ips: list[str]) -> x509.Certificate:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    subject = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "R22 Flight School"),
        x509.NameAttribute(NameOID.COMMON_NAME, SERVER_NAME),
    ])
    san_items = [x509.DNSName(n) for n in names] + [x509.IPAddress(ipaddress.ip_address(v)) for v in ips]
    now = _now()
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(ca_cert.subject)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - dt.timedelta(days=1))
        .not_valid_after(now + dt.timedelta(days=825))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.SubjectAlternativeName(san_items), critical=False)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
        .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False, key_encipherment=True, data_encipherment=False, key_agreement=False, key_cert_sign=False, crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
        .sign(ca_key, hashes.SHA256())
    )
    _write_private_key(p["server_key"], key)
    _write_cert(p["server_cert"], cert)
    return cert


def ensure_tls(force_server: bool = False, force_ca: bool = False) -> dict:
    p = paths()
    p["dir"].mkdir(parents=True, exist_ok=True)
    names, ips = _local_names_ips()
    if force_ca:
        for k in ("ca_key", "ca_cert", "server_key", "server_cert"):
            try:
                p[k].unlink()
            except FileNotFoundError:
                pass
    if not p["ca_key"].exists() or not p["ca_cert"].exists():
        ca_key, ca_cert = _new_ca(p)
    else:
        ca_key, ca_cert = _load_ca(p)
    if force_server or not p["server_key"].exists() or _server_cert_needs_refresh(p["server_cert"], names, ips):
        cert = _new_server(p, ca_key, ca_cert, names, ips)
    else:
        cert = x509.load_pem_x509_certificate(p["server_cert"].read_bytes())
    meta = {
        "ca_name": CA_NAME,
        "server_name": SERVER_NAME,
        "dns_names": names,
        "ip_addresses": ips,
        "server_not_after": cert.not_valid_after_utc.isoformat(),
        "ca_not_after": ca_cert.not_valid_after_utc.isoformat(),
        "ca_sha256": ca_cert.fingerprint(hashes.SHA256()).hex().upper(),
    }
    p["meta"].write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return status()


def status() -> dict:
    p = paths()
    result = {
        "enabled": os.getenv("HTTPS_ENABLED", "false").lower() == "true",
        "tls_dir": str(p["dir"]),
        "ca_cert": str(p["ca_cert"]),
        "server_cert": str(p["server_cert"]),
        "ready": p["ca_cert"].exists() and p["server_cert"].exists() and p["server_key"].exists(),
        "dns_names": [], "ip_addresses": [], "ca_sha256": "", "server_not_after": "", "ca_not_after": "",
    }
    if p["meta"].exists():
        try:
            result.update(json.loads(p["meta"].read_text(encoding="utf-8")))
        except Exception:
            pass
    if p["server_cert"].exists():
        try:
            cert = x509.load_pem_x509_certificate(p["server_cert"].read_bytes())
            result["server_not_after"] = cert.not_valid_after_utc.isoformat()
        except Exception:
            pass
    return result
