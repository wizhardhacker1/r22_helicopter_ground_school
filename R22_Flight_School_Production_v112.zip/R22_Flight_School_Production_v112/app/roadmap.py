ROADMAP_LINKS={
'orientation':[('Learn','/academy/currency'),('ACS task training','/acs-coverage'),('POH mastery','/poh'),('Checkride prep','/checkride-center')],
'aero':[('Learn aerodynamics','/academy/rotorenergy'),('Rotor & flight controls','/rotor-controls'),('VRS visual lab','/academy/vrs'),('Low-G visual lab','/academy/lowg'),('Dynamic rollover','/academy/rollover'),('Practice questions','/study?track=R22')],
'controls':[('R22 systems course','/academy/systems'),('Rotor & flight controls','/rotor-controls'),('Interactive Startup','/startup'),('Cockpit Flow','/checklists'),('Annunciator lab','/academy/annunciators'),('POH mastery','/poh')],
'preflight':[('Preflight / Checklist trainer','/checklists'),('Interactive Startup','/startup'),('Cockpit Flow','/checklists'),('Ground safety lab','/academy/ground'),('Printable cockpit reference','/checklist-reference')],
'hover':[('Hover-check course','/academy/hovercheck'),('Wind/LTE lab','/academy/wind'),('Dynamic rollover','/academy/rollover'),('ACS hover tasks','/acs-coverage#area-IV')],
'takeoff':[('H/V visual lab','/academy/hv'),('Wind/LTE lab','/academy/wind'),('Performance planning','/performance'),('POH performance charts','/performance#perfpanel'),('ACS takeoff/landing tasks','/acs-coverage#area-V')],
'maneuvers':[('Rotor-energy lab','/academy/rotorenergy'),('H/V lab','/academy/hv'),('ACS performance maneuvers','/acs-coverage#area-VI'),('Scenario oral','/oral')],
'emergency':[('Emergency trainer','/emergency'),('VRS lab','/academy/vrs'),('Low-G lab','/academy/lowg'),('Rotor-energy lab','/academy/rotorenergy'),('Robinson safety','/robinson-safety'),('Scenario oral','/oral')],
'performance':[('Performance & W&B','/performance'),('H/V visual lab','/academy/hv'),('POH performance charts','/performance#perfpanel'),('Flight planner','/flight-planner'),('Practice questions','/study?track=R22')],
'weather':[('2026 Weather course','/academy/weather2026'),('Dispatch scenario','/academy/weatherbrief'),('Personal minimums','/academy/minimums'),('Flight planner','/flight-planner'),('Practice questions','/study?track=PPL&mode=weak')],
'nav':[('2026 Chart course','/academy/charts2026'),('FAA Chart Lab','/navigation-charts'),('Interactive Flight Plan','/flight-planner'),('Flight computer','/performance#helipanel'),('ATC practice','/atc')],
'atc':[('Radio Academy','/academy/radio'),('ATC Listening Lab','/atc'),('Chart/Airspace Lab','/navigation-charts'),('Scenario oral','/oral')],
'night':[('IIMC/night risk','/academy/iimc'),('Weather course','/academy/weather2026'),('ATC practice','/atc'),('ACS Night task','/acs-task/IX/A')],
'written':[('Adaptive questions','/study?track=PPL&mode=weak'),('Flashcards','/flashcards'),('Practice exams','/exams'),('ACS coverage','/acs-coverage'),('Readiness','/readiness')],
'oral':[('Mock oral','/oral'),('Checkride Center','/checkride-center'),('ACS task training','/acs-coverage'),('POH mastery','/poh'),('Readiness','/readiness')]
}
