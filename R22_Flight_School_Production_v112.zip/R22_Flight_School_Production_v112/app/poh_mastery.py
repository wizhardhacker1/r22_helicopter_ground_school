POH_MASTERY_SECTIONS=[
{
 "key":"1","title":"General","ref":"R22 POH Section 1, pp. 1-1 through 1-8",
 "lessons":[
  {"id":"purpose","title":"Use the handbook correctly","body":"The POH is the operating guide for the pilot. It is not a substitute for competent flight instruction, current airworthiness directives, regulations, or advisory material. Operational use requires a current handbook.","apply":"Before a flight, verify the handbook/supplements are current and use instruction plus current regulatory and aircraft records rather than treating the POH as a standalone training substitute."},
  {"id":"responsibility","title":"Pilot and owner responsibilities","body":"The owner is responsible for keeping the helicopter airworthy. The pilot in command is responsible for determining the helicopter is safe for flight and for remaining within limitations, placards, and handbook requirements.","apply":"When something conflicts with memory, stop and verify the controlling aircraft limitation or procedure."},
  {"id":"warnings","title":"Cautions, notes, and organization","body":"A CAUTION identifies a procedure or instruction whose violation can result in equipment damage, injury, or death. A NOTE emphasizes or supplements information. Limitations and emergency procedures are intentionally placed ahead of normal procedures and performance.","apply":"Treat caution language as operationally significant, not optional commentary."}
 ],
 "questions":[
  {"q":"What does the POH explicitly say it is NOT a substitute for?","o":["Competent flight instruction and current regulatory/airworthiness information","Aircraft registration","A current weight-and-balance record","A maintenance logbook"],"a":0,"e":"Section 1 says the POH is not a substitute for adequate competent flight instruction or knowledge of current ADs, regulations, and advisory circulars."},
  {"q":"Who is responsible for determining that the helicopter is safe for flight?","o":["Only the mechanic","The pilot in command","Only the owner","The airport operator"],"a":1,"e":"Section 1 assigns the pilot in command responsibility for determining the helicopter is safe for flight."},
  {"q":"What does a POH CAUTION signify?","o":["Optional technique","Supplementary background only","Equipment damage, injury, or death can result if the instruction is not followed","A maintenance-only item"],"a":2,"e":"That is the POH definition of CAUTION."},
  {"q":"What does a POH NOTE do?","o":["Changes an operating limitation","Provides emphasis or supplementary information","Authorizes deviation from a procedure","Replaces an FAA-approved limitation"],"a":1,"e":"Section 1 defines a NOTE as emphasis or supplementary information."},
  {"q":"Why are Limitations and Emergency Procedures placed early in the handbook?","o":["To shorten the handbook","For easier access to critical information","Because normal procedures are optional","Because Section 1 is not operational"],"a":1,"e":"The handbook says these sections are placed ahead of normal procedures and performance for easier access."}
 ]},
{
 "key":"2","title":"Limitations","ref":"R22 POH Section 2",
 "lessons":[
  {"id":"speed","title":"Airspeed and rotor-speed limits","body":"Up to 3000 feet density altitude, VNE is 102 KIAS. Power-on rotor RPM is normally 101-104%; power-off rotor RPM is 90-110%. The POH notes an O-320/tachometer exception permitting 97% as the lower green-arc value on applicable aircraft.","apply":"Always use the placard/POH applicable to the specific helicopter, altitude, and installed tachometer."},
  {"id":"engine","title":"Powerplant operating limits","body":"Section 2 lists engine speed, temperature, oil-pressure, oil-quantity, and manifold-pressure limitations. Oil pressure minimum during flight is 55 psi; the POH directs the pilot to applicable placards for manifold-pressure limits.","apply":"Do not infer a limit from a generic gauge color alone when the POH or placard controls."},
  {"id":"loading","title":"Weight, CG, operation, and placards","body":"The R22 must be operated within approved weight, center-of-gravity, maneuver, kinds-of-operation, fuel, instrument-marking, and placard limitations. The current aircraft configuration and model matter.","apply":"A correct performance calculation is not enough if weight, CG, or a placard limitation is exceeded."}
 ],
 "questions":[
  {"q":"What is VNE up to 3000 feet density altitude?","o":["83 KIAS","90 KIAS","102 KIAS","110 KIAS"],"a":2,"e":"Section 2 specifies 102 KIAS up to 3000 feet density altitude."},
  {"q":"What is the normal power-on rotor RPM range?","o":["90-110%","101-104%","97-110%","80-104%"],"a":1,"e":"Section 2 lists 101-104% power on, with a stated lower-green-arc exception on applicable O-320/tachometer installations."},
  {"q":"What is the power-off rotor RPM range?","o":["90-110%","101-104%","97-104%","80-110%"],"a":0,"e":"Section 2 lists 90-110% power off."},
  {"q":"What is the minimum oil pressure during flight?","o":["25 psi","40 psi","55 psi","95 psi"],"a":2,"e":"Section 2 lists 55 psi minimum during flight."},
  {"q":"Which source controls model/altitude-specific manifold-pressure limits?","o":["A generic training chart","The applicable POH placards","A previous student's notes","The tachometer green arc"],"a":1,"e":"Section 2 directs the pilot to the applicable manifold-pressure placards."}
 ]},
{
 "key":"3","title":"Emergency Procedures","ref":"R22 POH Section 3",
 "lessons":[
  {"id":"urgency","title":"Know the landing urgency terms","body":"Land Immediately means use the nearest clear area where a safe normal landing can be performed and be prepared to enter autorotation. Land as soon as practical leaves the landing site to pilot discretion based on the problem and available areas, but flight beyond the nearest airport is not recommended.","apply":"The wording describes different urgency. Do not treat the two phrases as interchangeable."},
  {"id":"power","title":"Power failure priority","body":"A power failure may be engine or drive-system related. The immediate action is to lower collective to enter autorotation. At high airspeed, aft cyclic is required when collective is lowered.","apply":"The first priority is rotor energy/aircraft control, not troubleshooting."},
  {"id":"systems","title":"System-failure procedures","body":"Section 3 contains the complete procedures for power-loss height regimes, tail-rotor thrust loss, fires, tachometer/governor failures, warning lights, audio alerts, and related abnormal conditions.","apply":"Use the Emergency Procedures Trainer to rehearse sequences, then return to the POH reference to verify exact wording."}
 ],
 "questions":[
  {"q":"What is the immediate action for a power failure?","o":["Raise collective","Lower collective to enter autorotation","Switch the governor off first","Attempt an air restart first"],"a":1,"e":"Section 3 directs immediate lowering of collective to enter autorotation."},
  {"q":"What does 'Land Immediately' mean?","o":["Continue to the destination","Use the nearest clear area where a safe normal landing can be performed","Land only at an airport","Land whenever convenient"],"a":1,"e":"That is the Section 3 definition."},
  {"q":"What does 'Land as soon as practical' allow?","o":["Unlimited continuation","Pilot discretion based on the problem and available sites; flight beyond the nearest airport is not recommended","Only an off-airport landing","Ignoring the condition until maintenance"],"a":1,"e":"That matches the POH definition."},
  {"q":"What additional control input may be required when lowering collective at high airspeed after power failure?","o":["Forward cyclic","Aft cyclic","Full left pedal","Full right cyclic"],"a":1,"e":"Section 3 cautions that aft cyclic is required when collective is lowered at high airspeed."},
  {"q":"Where should exact emergency action sequences be verified?","o":["Only in memory aids","The current R22 POH Section 3 and applicable supplements","An internet forum","A generic airplane checklist"],"a":1,"e":"The current aircraft POH/RFM and applicable supplements are controlling."}
 ]},
{
 "key":"4","title":"Normal Procedures","ref":"R22 POH Section 4",
 "lessons":[
  {"id":"speeds","title":"Recommended airspeeds","body":"Section 4 lists: takeoff/climb 60 KIAS, VY 53 KIAS, maximum range 83 KIAS, significant turbulence 60-70 KIAS, landing approach 60 KIAS, and autorotation 60-70 KIAS. Some conditions require lower airspeed; VNE placards still control.","apply":"Use the recommended speed as part of a procedure, not as permission to exceed a limitation."},
  {"id":"preflight","title":"Preflight discipline","body":"Remove ground-handling wheels, covers, and tiedowns. Remove even small frost, ice, or snow accumulations, especially from rotor blades. Check maintenance records and inspect for damage, leakage, abnormal wear, fretting, and temperature/torque-stripe indications.","apply":"A checklist is a verification tool; it does not replace actually looking at the helicopter and records."},
  {"id":"operations","title":"Start through shutdown","body":"Section 4 contains before-start, starting/run-up, takeoff, cruise, doors-off, practice autorotation, carburetor heat, descent/approach/landing, shutdown, noise-abatement, and applicable AD guidance.","apply":"Practice cockpit flows in the trainers, then verify sequence against Section 4 before operational use."}
 ],
 "questions":[
  {"q":"What recommended takeoff and climb airspeed is listed?","o":["53 KIAS","60 KIAS","70 KIAS","83 KIAS"],"a":1,"e":"Section 4 lists 60 KIAS for takeoff and climb."},
  {"q":"What is the listed maximum-rate-of-climb speed (VY)?","o":["53 KIAS","60 KIAS","70 KIAS","83 KIAS"],"a":0,"e":"Section 4 lists VY as 53 KIAS."},
  {"q":"What airspeed range is listed for significant turbulence?","o":["30-40 KIAS","45-55 KIAS","60-70 KIAS","83-102 KIAS"],"a":2,"e":"Section 4 lists 60-70 KIAS, with conditions potentially requiring lower airspeed."},
  {"q":"What should be done with even small frost, ice, or snow accumulation before flight?","o":["Ignore it if only on rotor blades","Remove it, especially from rotor blades","Only document it","Warm the engine and let it clear itself"],"a":1,"e":"The preflight procedure directs removal of even small accumulations, especially on rotor blades."},
  {"q":"What is the listed landing-approach airspeed?","o":["53 KIAS","60 KIAS","70 KIAS","83 KIAS"],"a":1,"e":"Section 4 lists 60 KIAS for landing approach."}
 ]},
{
 "key":"5","title":"Performance","ref":"R22 POH Section 5",
 "lessons":[
  {"id":"conditions","title":"Performance charts are not guarantees","body":"The POH cautions that Section 5 performance data was obtained under ideal conditions and that performance under other conditions may be substantially less.","apply":"Build margin for wind, technique, aircraft condition, temperature, and other real-world factors instead of treating a chart line as guaranteed capability."},
  {"id":"hover","title":"Hover performance","body":"IGE hover controllability was substantiated in a 17-knot wind from any direction up to 9800 feet density altitude. The POH directs use of the model-specific hover performance charts for allowable gross weight.","apply":"Use the chart for the correct model and actual conditions."},
  {"id":"carb","title":"Carburetor heat performance effect","body":"Section 5 notes hover data is with carburetor heat off. Full carburetor heat can reduce hover ceilings by up to 2000 feet.","apply":"A performance check that ignores required carburetor heat can overstate available hover capability."}
 ],
 "questions":[
  {"q":"How does the POH characterize the conditions under which Section 5 performance data was obtained?","o":["Worst-case conditions","Ideal conditions","Only high-wind conditions","Only maximum-gross conditions"],"a":1,"e":"Section 5 explicitly says the data was obtained under ideal conditions."},
  {"q":"How much can full carburetor heat reduce hover ceilings?","o":["Up to 200 ft","Up to 500 ft","Up to 1000 ft","Up to 2000 ft"],"a":3,"e":"The Section 5 note states up to 2000 feet."},
  {"q":"What wind was IGE hover controllability substantiated in, from any direction, up to 9800 ft density altitude?","o":["10 kt","17 kt","25 kt","30 kt"],"a":1,"e":"Section 5 states 17 knots."},
  {"q":"Which chart should be used for allowable hover gross weight?","o":["Any R22 model chart","The chart for the applicable R22 model and condition","A generic helicopter chart","Only the H/V diagram"],"a":1,"e":"Section 5 separates hover-performance charts by model."},
  {"q":"What does the Height-Velocity diagram belong to?","o":["Section 2 Limitations only","Section 5 Performance","Section 8 Maintenance","Section 1 General"],"a":1,"e":"The Height-Velocity diagram is in Section 5."}
 ]},
{
 "key":"6","title":"Weight & Balance","ref":"R22 POH Section 6",
 "lessons":[
  {"id":"limits","title":"Stay inside both weight and CG limits","body":"The helicopter must be flown only within the weight and balance limits of Section 2. Loading outside those limits can result in insufficient control travel for safe operation.","apply":"A gross-weight-only check is incomplete; CG must also be within limits."},
  {"id":"fuel","title":"Check the fuel-burn CG shift","body":"The POH cautions that fuel burn causes CG to move forward. Safe loading must be checked with takeoff fuel and empty fuel, not just at one point in the flight.","apply":"A loading that is legal at takeoff can become unacceptable as fuel is burned."},
  {"id":"math","title":"Use aircraft-specific moments","body":"Loaded CG is found by dividing total moment by total weight. The POH loading worksheet includes aircraft empty weight, doors/controls, occupants/baggage, accessory mounts, and fuel locations.","apply":"Use the actual aircraft's current weight-and-balance record rather than a generic empty weight."}
 ],
 "questions":[
  {"q":"Why must both takeoff and empty-fuel loading be checked?","o":["Fuel burn moves CG forward","Fuel burn always moves CG aft","Only landing weight matters","The POH does not require both"],"a":0,"e":"Section 6 cautions that fuel burn moves CG forward and directs checking empty-fuel as well as takeoff loading."},
  {"q":"How is loaded CG arm determined?","o":["Total weight divided by total moment","Total moment divided by total weight","Fuel weight divided by empty weight","Pilot weight divided by gross weight"],"a":1,"e":"Section 6 states CG arm is total moment divided by total weight."},
  {"q":"What can loading outside approved CG limits cause?","o":["More available control travel","Insufficient control travel for safe operation","Lower fuel flow only","No operational consequence"],"a":1,"e":"Section 6 specifically warns of insufficient control travel."},
  {"q":"Which empty-weight information should be used?","o":["A generic Beta II example","The actual helicopter's current weight-and-balance record","The highest value in the fleet","Any previous aircraft of the same model"],"a":1,"e":"The POH loading method depends on aircraft-specific empty weight and arm."},
  {"q":"What must be compared with the calculated loading?","o":["Only fuel capacity","The CG limits given in Section 2","Only the H/V diagram","The alternator rating"],"a":1,"e":"Section 6 directs comparison of calculated weight and balance with Section 2 limits."}
 ]},
{
 "key":"7","title":"Systems Description","ref":"R22 POH Section 7",
 "lessons":[
  {"id":"controls","title":"Flight-control path and throttle correlation","body":"Primary flight controls are actuated through push-pull tubes and bellcranks. Collective movement is mechanically correlated with throttle: raising collective opens throttle; lowering collective closes it. Above 4000 feet this correlation and governor action are less effective, so power changes should be slow and smooth.","apply":"Understand what the governor assists with and what the pilot must still monitor and control."},
  {"id":"governor","title":"RPM governor","body":"The governor senses RPM changes and applies corrective throttle input through a friction clutch the pilot can override. It is active only above 80% engine RPM and is intended to assist under normal conditions, not prevent every over/underspeed from aggressive maneuvering.","apply":"Do not assume the governor removes the pilot's RPM-management responsibility."},
  {"id":"fuel_electrical","title":"Fuel and electrical systems","body":"The fuel system is gravity flow with no fuel pumps. Fuel should be sampled from all three locations before the first flight of the day and after refueling. The electrical system is 14-volt DC; inflight circuit-breaker reset is not recommended. For an ALT light/discharge, reduce nonessential load and perform the POH alternator reset; if the condition remains, land as soon as practical.","apply":"System knowledge should directly support abnormal-condition recognition and procedure selection."}
 ],
 "questions":[
  {"q":"How are the primary flight controls actuated?","o":["Hydraulic boost","Push-pull tubes and bellcranks","Fly-by-wire servos","Cable-only system"],"a":1,"e":"Section 7 describes push-pull tubes and bellcranks."},
  {"q":"At what engine RPM does the governor become active?","o":["Above 50%","Above 70%","Above 80%","Only at 104%"],"a":2,"e":"Section 7 says the governor is active only above 80% engine RPM."},
  {"q":"What happens mechanically when collective is raised?","o":["Throttle closes","Throttle opens","Governor switches off","Fuel valve closes"],"a":1,"e":"The throttle is mechanically correlated to collective; raising collective opens throttle."},
  {"q":"How is fuel delivered to the engine?","o":["Electric boost pump","Engine-driven pump","Gravity flow; no fuel pumps","Hydraulic pressure"],"a":2,"e":"Section 7 describes a gravity-flow fuel system with no fuel pumps."},
  {"q":"What does the POH say about inflight circuit-breaker reset?","o":["Reset every tripped breaker once","Reset only avionics breakers","It is not recommended","It is mandatory after alternator failure"],"a":2,"e":"Section 7 states inflight reset of circuit breakers is not recommended."}
 ]},
{
 "key":"8","title":"Handling & Maintenance","ref":"R22 POH Section 8",
 "lessons":[
  {"id":"responsibility","title":"Owner/operator maintenance responsibility","body":"Federal regulations place responsibility for helicopter maintenance on the owner/operator. Maintenance must be performed by qualified mechanics in accordance with the R22 Maintenance Manual, Service Bulletins/Letters, and FAA Airworthiness Directives.","apply":"A training app cannot establish airworthiness; verify the actual aircraft records and current maintenance status."},
  {"id":"documents","title":"Required aircraft documents","body":"The Airworthiness Certificate must be displayed in the aircraft. Registration Certificate, POH, and current Weight and Balance must be carried in the aircraft. Aircraft and engine logbooks should not be carried in the aircraft but must be available for servicing/inspection use.","apply":"Separate documents that must be carried from maintenance records that must remain available."},
  {"id":"service","title":"Handling and servicing scope","body":"Section 8 covers inspections, preventive maintenance, alterations, ground handling, parking, doors, engine/gearbox oil, fuel, bladders, extinguisher, battery, cleaning, and storage.","apply":"Use Section 8 and current maintenance publications when handling or servicing the aircraft."}
 ],
 "questions":[
  {"q":"Which certificate must be displayed in the aircraft at all times?","o":["Registration Certificate","Airworthiness Certificate","Medical certificate","Engine logbook"],"a":1,"e":"Section 8 requires the Airworthiness Certificate to be displayed."},
  {"q":"Which set must be carried in the aircraft?","o":["Registration, POH, current Weight and Balance","Aircraft logbook, engine logbook, maintenance manual","Only registration","Only the POH"],"a":0,"e":"Section 8 lists Registration Certificate, POH, and current Weight and Balance."},
  {"q":"Where should aircraft and engine logbooks normally be kept?","o":["Carried in the helicopter","Not carried in the aircraft, but available for use","With the passenger","Inside the baggage compartment"],"a":1,"e":"Section 8 says they should not be carried in the aircraft but must be available."},
  {"q":"Who bears regulatory responsibility for maintenance?","o":["Only the pilot renting the aircraft","The owner/operator","Only the airport","The manufacturer"],"a":1,"e":"Section 8 states federal regulations place maintenance responsibility on the owner/operator."},
  {"q":"Which publication is part of the required maintenance basis?","o":["R22 Maintenance Manual/ICA plus applicable service information and ADs","A generic helicopter textbook only","The student's notebook","An outdated checklist"],"a":0,"e":"Section 8 directs maintenance in accordance with the R22 Maintenance Manual, Robinson service publications, and FAA ADs."}
 ]},
{
 "key":"9","title":"Supplements","ref":"R22 POH Section 9 - supplements applicable to installed equipment",
 "lessons":[
  {"id":"applicable","title":"Only applicable supplements control","body":"Section 9 is reserved for supplements associated with installed equipment or configurations. A supplement can add or change limitations, procedures, and information for that installation.","apply":"Before flight, determine which supplements apply to the actual aircraft rather than studying every supplement as if installed."},
  {"id":"integrate","title":"Integrate supplement changes","body":"When a supplement changes a limitation or procedure, the aircraft-specific supplement must be used together with the base POH.","apply":"Do not memorize a base-POH procedure and ignore a supplement that changes it."},
  {"id":"currency","title":"Keep the aircraft reference current","body":"The handbook and applicable supplements must be current for operational use. Aircraft configuration, records, and installed equipment determine what applies.","apply":"Make supplement verification part of aircraft familiarization and checkride-document review."}
 ],
 "questions":[
  {"q":"What determines whether a Section 9 supplement applies?","o":["Student preference","Installed aircraft equipment/configuration","The airport elevation","The instructor's favorite procedure"],"a":1,"e":"Supplements are tied to applicable installed equipment or configuration."},
  {"q":"Can an applicable supplement change a base-POH limitation or procedure?","o":["No","Yes","Only after an oral exam","Only for maintenance"],"a":1,"e":"Applicable supplements can add or modify limitations, procedures, and information."},
  {"q":"How should the pilot use an applicable supplement?","o":["Ignore the base POH entirely","Use it together with the base POH for the configured aircraft","Treat it as optional study material","Use it only after a malfunction"],"a":1,"e":"The supplement and base POH together form the applicable aircraft reference."},
  {"q":"What must be verified before relying on a supplement?","o":["That it applies to the actual aircraft/configuration","That another student used it","That it is the longest supplement","That it changes VNE"],"a":0,"e":"Applicability depends on the actual aircraft and installation."},
  {"q":"What is the safest rule for conflicting memory versus an applicable current supplement?","o":["Use memory","Use the current applicable aircraft documentation","Average the two values","Use the older value"],"a":1,"e":"The current applicable aircraft documentation controls."}
 ]},
{
 "key":"10","title":"Safety Tips & Notices","ref":"R22 POH Section 10 and Safety Notices",
 "lessons":[
  {"id":"lowg","title":"Low-G avoidance and recovery knowledge","body":"Section 10 warns never to push cyclic forward to descend or terminate a pull-up. SN-11 explains that in low-G the rotor must be reloaded before lateral cyclic can stop a roll: immediately apply gentle aft cyclic and avoid large control inputs.","apply":"This is recognition/recovery knowledge, not a maneuver to experiment with."},
  {"id":"rpm","title":"Protect rotor RPM","body":"The safety material repeatedly emphasizes that dangerously low rotor RPM can lead to rotor stall. The pilot response must prioritize RPM recovery and rotor energy rather than pulling collective to stop a sink.","apply":"Train the reflex through approved instruction and the emergency trainer; never intentionally practice unsafe low-RPM conditions outside proper instruction."},
  {"id":"vrs","title":"Vortex ring state avoidance","body":"SN-22 says reduce rate of descent before reducing airspeed. A rule given in the notice is not to let airspeed fall below 30 knots until rate of descent is below 300 fpm. Recognition signs include increased vibration, mushy controls, and rapid sink-rate increase.","apply":"Plan approaches and OGE-hover descents to avoid entering the rotor's recirculating downwash."}
 ],
 "questions":[
  {"q":"What cyclic input does SN-11 call for first to reload the rotor in low-G?","o":["Large lateral cyclic","Gentle aft cyclic","Full forward cyclic","Rapid alternating cyclic"],"a":1,"e":"SN-11 says immediately apply gentle aft cyclic to reload the rotor before lateral correction."},
  {"q":"What does Section 10 say about using forward cyclic to initiate a descent?","o":["It is the preferred method","Never do it; use collective to initiate descent","Use it only above 3000 ft","Use it only with governor off"],"a":1,"e":"Safety Tip 1 warns against pushing cyclic forward to descend and says to use collective."},
  {"q":"What is the SN-22 rule relating airspeed and rate of descent for VRS avoidance?","o":["Below 30 kt only after rate of descent is below 300 fpm","Below 30 kt only above 1000 fpm descent","Always maintain exactly 60 kt","Use zero airspeed before reducing descent"],"a":0,"e":"SN-22 gives the rule: do not let airspeed be less than 30 knots until rate of descent is less than 300 fpm."},
  {"q":"Which is a developing-VRS cue listed in SN-22?","o":["Increased vibration and mushy controls","Higher oil pressure only","ALT light only","Lower cabin temperature"],"a":0,"e":"SN-22 lists increased vibration, decreased/mushy control authority, and rapid sink-rate increase."},
  {"q":"When should the strobe be on according to the Safety Tips?","o":["Only at night","Before starting the engine until rotors stop turning","Only in cruise","Only during autorotation"],"a":1,"e":"Section 10 says turn the strobe on before starting the engine and leave it on until the rotors stop."}
 ]}
]
POH_MASTERY_MAP={x["key"]:x for x in POH_MASTERY_SECTIONS}
POH_FINAL_QUESTIONS=[
 {"q":"During preflight planning you discover the installed POH is not current. What is the correct response?","o":["Use it if the numbers look familiar","Do not rely on it for operational use until the current handbook/applicable material is available","Use an internet summary instead","Fly only locally"],"a":1,"e":"Section 1 says the handbook should not be used operationally unless kept current."},
 {"q":"At 2500 ft density altitude, which listed VNE applies before considering any more restrictive placard/configuration limit?","o":["83 KIAS","90 KIAS","102 KIAS","110 KIAS"],"a":2,"e":"Section 2 lists 102 KIAS up to 3000 ft density altitude."},
 {"q":"A power failure occurs and the pilot begins troubleshooting before changing collective. What priority was missed?","o":["Immediately lower collective to enter autorotation","Turn off the battery first","Raise collective to stop descent","Select a radio frequency first"],"a":0,"e":"Section 3 makes lowering collective to enter autorotation the immediate action."},
 {"q":"Which Section 4 speed is specifically recommended for significant turbulence?","o":["53 KIAS","60-70 KIAS","83 KIAS","102 KIAS"],"a":1,"e":"Section 4 lists 60-70 KIAS for significant turbulence, with some conditions requiring lower speed."},
 {"q":"A hover calculation was made with carburetor heat off, but full carburetor heat will be needed. What POH performance effect must be considered?","o":["Hover ceiling may be reduced by up to 2000 ft","VNE increases by 20 kt","Gross-weight limit increases","No performance change"],"a":0,"e":"Section 5 notes full carburetor heat can reduce hover ceilings by up to 2000 ft."},
 {"q":"Why is a zero/empty-fuel CG check required in addition to takeoff CG?","o":["Fuel burn moves CG forward","Fuel burn always moves CG aft","Only lateral CG changes","The POH does not require it"],"a":0,"e":"Section 6 cautions that fuel burn moves CG forward."},
 {"q":"Which statement best describes the R22 governor?","o":["It is a hydraulic flight-control system","It assists RPM control above 80% engine RPM and can be overridden by the pilot","It replaces the throttle linkage","It prevents every overspeed regardless of maneuver"],"a":1,"e":"Section 7 describes governor assistance above 80% engine RPM through an overridable friction clutch."},
 {"q":"Which item belongs in the aircraft rather than being kept separately as a maintenance record?","o":["Engine logbook","Aircraft logbook","Current Weight and Balance","Maintenance shop work order"],"a":2,"e":"Section 8 requires current Weight and Balance to be carried; aircraft and engine logbooks should not be carried in the helicopter."},
 {"q":"An installed-equipment supplement changes a base-POH procedure. Which procedure should the pilot use?","o":["The memorized base procedure only","The current applicable supplement together with the base POH","Whichever is shorter","The older procedure"],"a":1,"e":"Applicable supplements become part of the aircraft-specific operating reference."},
 {"q":"A low-G roll tendency develops. What must occur before lateral cyclic correction?","o":["Unload the rotor farther","Reload the rotor with gentle aft cyclic","Raise collective sharply","Apply full lateral cyclic immediately"],"a":1,"e":"SN-11 directs gentle aft cyclic to reload the rotor before lateral cyclic correction."}
]
