import os,datetime,jwt,secrets,hashlib,hmac,base64
from fastapi import Request,HTTPException
def secret():
 s=os.getenv('SECRET_KEY','')
 if len(s)<32 or s.startswith('CHANGE-ME'):
  if os.getenv('ENVIRONMENT','development').lower()=='production': raise RuntimeError('Production SECRET_KEY must be at least 32 characters')
  return 'development-only-change-me-please-32chars'
 return s
def hash_password(p):
 if len(p)<10: raise ValueError('Password must be at least 10 characters')
 salt=secrets.token_bytes(16); rounds=310000; dk=hashlib.pbkdf2_hmac('sha256',p.encode(),salt,rounds)
 return f'pbkdf2_sha256${rounds}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(dk).decode()}'
def verify(p,stored):
 try:
  alg,r,s,d=stored.split('$'); salt=base64.urlsafe_b64decode(s); expected=base64.urlsafe_b64decode(d); got=hashlib.pbkdf2_hmac('sha256',p.encode(),salt,int(r)); return hmac.compare_digest(got,expected)
 except Exception: return False
def token(uid,role): return jwt.encode({'sub':str(uid),'role':role,'exp':datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(hours=int(os.getenv('SESSION_HOURS','12')))},secret(),algorithm='HS256')
def current(request:Request):
 t=request.cookies.get('session')
 if not t: raise HTTPException(401,'Login required')
 try: return jwt.decode(t,secret(),algorithms=['HS256'])
 except Exception: raise HTTPException(401,'Session expired')
def csrf_token(request:Request): return request.cookies.get('csrf') or secrets.token_urlsafe(32)
def check_csrf(request:Request,value:str):
 if not value or not secrets.compare_digest(value,request.cookies.get('csrf','')): raise HTTPException(403,'Invalid CSRF token')
