import os, shutil
from pathlib import Path
from sqlalchemy import create_engine,event
from sqlalchemy.orm import declarative_base, sessionmaker

def _default_data_dir():
    if os.name=='nt':
        root=Path(os.getenv('LOCALAPPDATA') or Path.home()/'AppData'/'Local')
        return root/'R22FlightSchool'/'data'
    root=Path(os.getenv('XDG_DATA_HOME') or Path.home()/'.local'/'share')
    return root/'r22-flight-school'/'data'

raw=os.getenv('R22_DATA_DIR','').strip()
# ./data was the legacy in-package location. Treat it as migration input, not the long-term store.
if not raw or raw in ('.','./data','.\\data','data'):
    _data_dir=_default_data_dir().expanduser().resolve()
    legacy=(Path.cwd()/'data'/'r22school.db').resolve()
else:
    _data_dir=Path(raw).expanduser().resolve(); legacy=None
_data_dir.mkdir(parents=True,exist_ok=True)
if legacy and legacy.exists() and not (_data_dir/'r22school.db').exists():
    shutil.copy2(legacy,_data_dir/'r22school.db')
os.environ['R22_DATA_DIR']=str(_data_dir)
DB=os.getenv('DATABASE_URL','').strip()
if not DB or DB in ('sqlite:///./data/r22school.db','sqlite:///data/r22school.db'):
    DB=f'sqlite:///{(_data_dir / "r22school.db").as_posix()}'
    os.environ['DATABASE_URL']=DB
kwargs={'check_same_thread':False,'timeout':30} if DB.startswith('sqlite') else {}
engine=create_engine(DB,pool_pre_ping=True,connect_args=kwargs)
if DB.startswith('sqlite'):
 @event.listens_for(engine,'connect')
 def sqlite_pragmas(conn,_):
  cur=conn.cursor(); cur.execute('PRAGMA journal_mode=WAL'); cur.execute('PRAGMA foreign_keys=ON'); cur.execute('PRAGMA busy_timeout=30000'); cur.close()
SessionLocal=sessionmaker(bind=engine,autoflush=False,autocommit=False,expire_on_commit=False)
Base=declarative_base()
def get_db():
 db=SessionLocal()
 try: yield db
 finally: db.close()
