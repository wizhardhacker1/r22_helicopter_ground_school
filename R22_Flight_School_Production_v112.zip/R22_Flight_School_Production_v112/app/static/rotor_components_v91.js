(()=>{const $=s=>document.querySelector(s);
const data={
 blade:{name:'Main rotor blades',body:'Blade pitch changes as collective and cyclic commands reach the rotating rotor system.',fact:'The two-bladed main rotor provides lift and control response.'},
 link:{name:'Pitch link',body:'Transfers swashplate motion to the blade pitch-control hardware.',fact:'Collective moves the pitch links together; cyclic creates differential motion.'},
 swash:{name:'Swashplate',body:'Transfers non-rotating pilot-control input to the rotating rotor-control system.',fact:'Collective moves it axially; cyclic tilts it.'},
 mast:{name:'Mast',body:'Central rotating shaft supporting and driving the main rotor system.',fact:'The mast is directly beneath the rotor hub.'},
 controls:{name:'Control rods',body:'Carry pilot control commands toward the swashplate.',fact:'Their motion ultimately positions the swashplate.'}
};
// normalized hit regions on the clean 865x485 rotor-head image.
const hit={
 blade:{x1:.03,y1:.03,x2:.39,y2:.29},
 link:{x1:.385,y1:.255,x2:.455,y2:.64},
 swash:{x1:.405,y1:.385,x2:.615,y2:.585},
 mast:{x1:.455,y1:.11,x2:.555,y2:.47},
 controls:{x1:.565,y1:.255,x2:.625,y2:.66}
};
let mode='identify',quizKey='mast',quizOrder=[],quizIndex=0,quizCorrect=0,demo=null,t=0;
const img=$('#rotorReferenceImage'),rig=$('#rotorMotionRig'),layer=$('#quizClickLayer'),marker=$('#quizClickMarker'),reveal=$('#quizTargetReveal');
function pickerButtons(){return [...document.querySelectorAll('.component-picker [data-part]')]}
function showPart(k){pickerButtons().forEach(b=>b.classList.toggle('selected',b.dataset.part===k));$('#partTitle').textContent=data[k].name;$('#partBody').textContent=data[k].body;$('#partFacts').textContent=data[k].fact}
pickerButtons().forEach(b=>b.addEventListener('click',()=>showPart(b.dataset.part)));
function stopDemo(){clearInterval(demo);demo=null}
const lc=$('#labCollective'),cy=$('#labCyclic'),ped=$('#labPedals');
function labMove(){const c=Number(lc.value),y=Number(cy.value),p=Number(ped.value);
 $('#labCollectiveRead').textContent=c+'%';$('#labCyclicRead').textContent=Math.abs(y)<8?'CENTER':y>0?'FORWARD':'AFT';$('#labPedalRead').textContent=Math.abs(p)<8?'CENTER':p<0?'LEFT':'RIGHT';
 $('#labSwashState').textContent=`${c<35?'LOW':c>65?'HIGH':'MID'} / ${Math.abs(y)<8?'LEVEL':y>0?'FORWARD TILT':'AFT TILT'}`;$('#labLinkState').textContent=Math.abs(y)<8?'EVEN':'DIFFERENTIAL';
 const px=Math.max(-24,Math.min(24,p*.24));$('#labPedalVisual').style.setProperty('--lab-pedal-left',`${px}px`);$('#labPedalVisual').style.setProperty('--lab-pedal-right',`${-px}px`);$('#labTailRotor').style.setProperty('--tail-feather',`${p*.18}deg`);$('#labTailState').textContent=Math.abs(p)<8?'NEUTRAL TAIL-ROTOR PITCH':p<0?'LEFT PEDAL COMMAND':'RIGHT PEDAL COMMAND';
 rig.style.setProperty('--swash-y',`${(50-c)*.70}px`);rig.style.setProperty('--swash-tilt',`${y*.22}deg`);rig.style.setProperty('--link-left',`${(50-c)*.36+y*.16}px`);rig.style.setProperty('--link-right',`${(50-c)*.36-y*.16}px`);
 const collectivePitch=-9+(c*.18),cyclicDiff=y*.10,discTilt=y*.045,bladeLift=(c-50)*-.05;
 rig.style.setProperty('--pitch-left',`${collectivePitch+cyclicDiff}deg`);
 rig.style.setProperty('--pitch-right',`${collectivePitch-cyclicDiff}deg`);
 rig.style.setProperty('--disc-tilt',`${discTilt}deg`);
 rig.style.setProperty('--blade-heave',`${bladeLift}px`);
 document.body.classList.add('component-manual-motion');
}
[lc,cy,ped].forEach(x=>x.addEventListener('input',()=>{stopDemo();labMove()}));
function startDemo(){stopDemo();t=0;demo=setInterval(()=>{t+=.075;lc.value=Math.round(50+38*Math.sin(t*.62));cy.value=Math.round(82*Math.sin(t));ped.value=Math.round(88*Math.sin(t*.74));labMove()},55)}
function shuffle(a){for(let i=a.length-1;i>0;i--){const n=Math.floor(Math.random()*(i+1));[a[i],a[n]]=[a[n],a[i]]}return a}
function beginQuiz(){quizOrder=shuffle(Object.keys(data).slice());quizIndex=0;quizCorrect=0;nextQuizQuestion()}
function nextQuizQuestion(){
 if(quizIndex>=quizOrder.length){quizKey='';$('#quizQuestion').textContent='COMPONENT QUIZ PASSED';$('#quizFeedback').textContent=`PASS — ${quizCorrect}/${quizOrder.length} components identified correctly.`;$('#quizFeedback').className='quiz-feedback good';$('#quizNext').hidden=false;$('#quizNext').textContent='RESTART QUIZ';marker.style.display='none';reveal.style.display='none';return}
 quizKey=quizOrder[quizIndex];$('#quizQuestion').textContent=`Question ${quizIndex+1} of ${quizOrder.length}: Where is the ${data[quizKey].name.toLowerCase()}?`;$('#quizFeedback').textContent='Click directly on that component in the helicopter image.';$('#quizFeedback').className='quiz-feedback';$('#quizNext').hidden=true;$('#quizNext').textContent='NEXT COMPONENT';marker.className='quiz-click-marker';marker.style.display='none';reveal.style.display='none'
}
function setTargetReveal(k){const r=hit[k];reveal.style.left=(r.x1*100)+'%';reveal.style.top=(r.y1*100)+'%';reveal.style.width=((r.x2-r.x1)*100)+'%';reveal.style.height=((r.y2-r.y1)*100)+'%';reveal.style.display='block'}
layer.addEventListener('pointerdown',e=>{if(mode!=='quiz')return;const r=layer.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height,tg=hit[quizKey],ok=x>=tg.x1&&x<=tg.x2&&y>=tg.y1&&y<=tg.y2;
 marker.style.left=(x*100)+'%';marker.style.top=(y*100)+'%';marker.style.display='block';marker.className='quiz-click-marker '+(ok?'correct':'wrong');
 if(ok){setTargetReveal(quizKey);quizCorrect++;$('#quizFeedback').textContent=`CORRECT — ${data[quizKey].name.toUpperCase()} (${quizCorrect}/${quizOrder.length})`;$('#quizFeedback').className='quiz-feedback good';$('#quizNext').hidden=false}
 else{$('#quizFeedback').textContent='INCORRECT — TRY AGAIN';$('#quizFeedback').className='quiz-feedback bad'}
});
$('#quizNext').addEventListener('click',()=>{if(quizIndex>=quizOrder.length){beginQuiz();return}quizIndex++;nextQuizQuestion()});
function setMode(m){mode=m;stopDemo();document.body.dataset.componentMode=m;document.body.classList.remove('component-manual-motion');document.querySelectorAll('[data-cmode]').forEach(b=>b.classList.toggle('active',b.dataset.cmode===m));
 const quiz=m==='quiz';$('#identifyPanel').hidden=quiz;$('#quizPanel').hidden=!quiz;$('#motionControls').hidden=quiz;layer.hidden=!quiz;marker.style.display='none';reveal.style.display='none';
 if(quiz){img.src='/static/rotor_quiz_clean_v105.png?v=112';$('#componentPhotoTitle').textContent='R22 ROTOR HEAD * QUIZ';$('#componentModeHint').textContent='Identify every component correctly to pass.';rig.style.display='none';beginQuiz()}
 else{img.src='/static/rotor_trainer_v82.png?v=112';rig.style.display='block';$('#componentPhotoTitle').textContent=m==='motion'?'R22 ROTOR HEAD * LIVE CONTROL MOTION':'R22 ROTOR HEAD * LABELED REFERENCE';$('#componentModeHint').textContent=m==='motion'?'Automatic demonstration is running. Move a slider to take manual control.':'Move the controls at right to see their mechanical relationship.';if(m==='motion')startDemo();else labMove()}
}
let lesson=-1;$('#labGuided').addEventListener('click',()=>{lesson=(lesson+1)%4;const steps=['Raise and lower Collective. The swashplate and both pitch links move together.','Move Cyclic fore and aft. The swashplate tilts and the pitch links move differentially.','Move the pedals. Tail-rotor command changes without moving the main-rotor swashplate.','Guided lesson complete. Use Quiz and identify components directly on the clean image.'];$('#labLesson').textContent=steps[lesson]});
document.querySelectorAll('[data-cmode]').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.cmode)));
showPart('swash');setMode('identify');window.addEventListener('pagehide',stopDemo)})();