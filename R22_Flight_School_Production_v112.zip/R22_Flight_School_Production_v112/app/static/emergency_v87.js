(()=> {
const $=s=>document.querySelector(s), scenario=window.EMERGENCY_SCENARIO;
let mode='learn',progress=0,history=[],mistakes=0,score=100,elapsed=0,timer;
let audioEnabled=true,audioCtx=null,hornOsc=null,warbleTimer=null;
const heliAudio=new Audio('/static/audio/r22_helicopter_running.mp3');heliAudio.loop=true;heliAudio.volume=.42;

const A={
 collective:'LOWER COLLECTIVE', 'collective-up':'RAISE COLLECTIVE',
 aft:'GENTLE AFT CYCLIC', forward:'FORWARD CYCLIC / LEVEL SHIP', lateral:'LATERAL CYCLIC',
 airspeed65:'ESTABLISH 65 KIAS', airspeed70:'MAINTAIN AT LEAST 70 KIAS', airspeed75:'ESTABLISH 75 KIAS',
 rpm97110:'ROTOR RPM 97–110%', rpm90:'ROTOR RPM APPROX 90%',
 landing:'SELECT LANDING AREA', flare40:'BEGIN FLARE ABOUT 40 FT AGL', 'flare-ground':'FLARE AS GROUND IS APPROACHED', cushion8:'LEVEL / CUSHION ABOUT 8 FT AGL',
 'right-pedal':'RIGHT PEDAL AS REQUIRED', settle:'ALLOW AIRCRAFT TO SETTLE',
 autorotation:'ENTER AUTOROTATION', 'safe-auto':'ESTABLISH SAFE AUTOROTATION',
 'mixture-rich':'MIXTURE FULL RICH', 'mixture-off':'MIXTURE OFF',
 'primer-lock':'PRIMER DOWN & LOCKED', 'throttle-crack':'THROTTLE CLOSED, THEN CRACK SLIGHTLY',
 starter:'ACTUATE STARTER', 'throttle-off':'THROTTLE OFF INTO OVERTRAVEL SPRING', 'throttle-on':'ROLL THROTTLE ON',
 'manual-throttle':'GRIP / CONTROL THROTTLE MANUALLY', 'governor-off':'GOVERNOR OFF',
 'fuel-off':'FUEL VALVE OFF', battery:'BATTERY OFF', alternator:'ALTERNATOR OFF',
 'nonessential-off':'UNNECESSARY / NONESSENTIAL ELECTRICAL OFF', 'alt-reset':'ALT OFF 1 SECOND, THEN ON',
 'doors-unlatch':'UNLATCH DOORS', 'passenger-exit':'PASSENGER EXIT', 'fly-clear':'FLY CLEAR OF PASSENGER',
 'hover-water':'DESCEND TO HOVER ABOVE WATER', 'water-contact':'CONTACT WATER LEVEL',
 'lateral-stop':'APPLY LATERAL CYCLIC TO STOP ROTORS', 'seatbelt-exit':'RELEASE SEAT BELT / EXIT',
 'normal-landing':'PERFORM NORMAL LANDING', 'auto-landing':'COMPLETE AUTOROTATION LANDING',
 'cabin-heat-off':'CABIN HEAT OFF', 'vents-open':'OPEN CABIN VENTS', 'rotor-brake':'ROTOR BRAKE IF TIME PERMITS',
 exit:'EXIT HELICOPTER', 'continue-crank':'CONTINUE CRANKING / ATTEMPT START', 'rpm50-60':'RUN 50–60% RPM BRIEFLY',
 'monitor-tach':'USE REMAINING TACH TO MONITOR RPM', 'governor-control':'ALLOW GOVERNOR TO CONTROL RPM',
 'land-practical':'LAND AS SOON AS PRACTICAL', 'land-immediate':'LAND IMMEDIATELY',
 'check-engine-tach':'CHECK ENGINE TACH', 'check-oil':'CHECK OIL PRESSURE',
 'clutch-breaker':'PULL CLUTCH CIRCUIT BREAKER', 'heater-off':'HEATER OFF',
 'brake-release':'RELEASE ROTOR BRAKE', 'reduce-collective':'LOWER COLLECTIVE AS REQUIRED',
 'reduce-turb':'REDUCE POWER / 60–70 KIAS', 'smooth-controls':'SMOOTH, GENTLE CONTROL INPUTS',
 'depart-turb':'DEPART TURBULENCE AREA', 'no-flight':'DO NOT CONTINUE / DO NOT DEPART',
 'raise-collective':'RAISE COLLECTIVE TO CONTROL HIGH RPM',
 'positive-g':'RESTORE POSITIVE G BEFORE LATERAL CYCLIC',
 'switches-fuel-off':'UNNECESSARY SWITCHES & FUEL VALVE OFF'
};

const base=(asi=70,alt=900,map=20)=>({er:104,rr:104,asi,alt,map});
const configs={
 power_high:{cue:'POWER LOSS / LOW ROTOR RPM — NO RESTART ATTEMPT',base:base(70,900,20),fault:{er:58,rr:94,asi:70,alt:900,map:10,lowrpm:true},
   seq:['collective','airspeed65','rpm97110','landing','switches-fuel-off','flare40','cushion8'],
   choices:['collective','airspeed65','rpm97110','landing','switches-fuel-off','flare40','cushion8','airspeed75','throttle-on']},
 power_mid:{cue:'POWER LOSS — 8 TO 500 FT AGL',base:base(55,300,21),fault:{er:55,rr:95,asi:55,alt:300,map:9,lowrpm:true},
   seq:['collective','rpm97110','flare-ground','cushion8'],choices:['collective','rpm97110','flare-ground','cushion8','airspeed65','landing']},
 power_low:{cue:'POWER LOSS — BELOW 8 FT AGL',base:base(15,6,22),fault:{er:50,rr:98,asi:15,alt:6,map:8},
   seq:['right-pedal','settle','collective-up'],choices:['right-pedal','settle','collective-up','collective','aft']},
 max_glide:{cue:'MAXIMUM GLIDE DISTANCE CONFIGURATION',base:base(65,1500,10),fault:{er:55,rr:98,asi:65,alt:1500,map:8},
   seq:['airspeed75','rpm90'],choices:['airspeed75','rpm90','airspeed65','rpm97110','collective-up']},
 air_restart:{cue:'AIR RESTART — SAFE AUTOROTATION ESTABLISHED',base:base(65,1800,8),fault:{er:0,rr:102,asi:65,alt:1800,map:0},
   seq:['safe-auto','mixture-rich','primer-lock','throttle-crack','starter'],choices:['safe-auto','mixture-rich','primer-lock','throttle-crack','starter','governor-off','battery']},
 water_off:{cue:'POWER-OFF WATER LANDING',base:base(65,300,8),fault:{er:0,rr:102,asi:65,alt:300,map:0},
   seq:['collective','airspeed65','rpm97110','doors-unlatch','water-contact','lateral-stop','seatbelt-exit'],choices:['collective','airspeed65','rpm97110','doors-unlatch','water-contact','lateral-stop','seatbelt-exit','collective-up','battery']},
 water_on:{cue:'POWER-ON WATER LANDING',base:base(40,150,19),fault:base(40,150,19),
   seq:['hover-water','doors-unlatch','passenger-exit','fly-clear','battery','alternator','throttle-off','water-contact','collective-up','lateral-stop','seatbelt-exit'],
   choices:['hover-water','doors-unlatch','passenger-exit','fly-clear','battery','alternator','throttle-off','water-contact','collective-up','lateral-stop','seatbelt-exit','autorotation']},
 tail_forward:{cue:'LOSS OF TAIL ROTOR THRUST / RIGHT YAW',base:base(75,800,20),fault:{er:104,rr:104,asi:75,alt:800,map:20,yaw:'RIGHT'},
   seq:['autorotation','airspeed70','landing','throttle-off','auto-landing'],choices:['autorotation','airspeed70','landing','throttle-off','auto-landing','right-pedal','collective-up']},
 tail_hover:{cue:'LOSS OF TAIL ROTOR THRUST IN HOVER',base:base(0,5,20),fault:{er:104,rr:104,asi:0,alt:5,map:20,yaw:'RIGHT'},
   seq:['throttle-off','settle','collective-up'],choices:['throttle-off','settle','collective-up','right-pedal','autorotation']},
 audio:{cue:'HEADSET AUDIO FAILURE',base:base(70,900,20),fault:base(70,900,20),
   seq:['land-practical'],choices:['land-practical','land-immediate','continue-crank','governor-off']},
 fire_start:{cue:'ENGINE FIRE DURING START — GROUND',base:{er:15,rr:0,asi:0,alt:0,map:5},fault:{er:15,rr:0,asi:0,alt:0,map:5},
   seq:['continue-crank','rpm50-60','mixture-off','fuel-off','battery','rotor-brake','exit'],
   choices:['continue-crank','rpm50-60','mixture-off','fuel-off','battery','rotor-brake','exit','alternator','autorotation']},
 engine_fire:{cue:'ENGINE FIRE IN FLIGHT — ENGINE STILL RUNNING',base:base(70,1000,20),fault:{er:82,rr:101,asi:70,alt:1000,map:13,oil:true},
   seq:['autorotation','cabin-heat-off','vents-open','normal-landing','mixture-off','fuel-off','battery','rotor-brake','exit'],
   choices:['autorotation','cabin-heat-off','vents-open','normal-landing','mixture-off','fuel-off','battery','rotor-brake','exit','alternator','land-practical']},
 electrical_fire:{cue:'ELECTRICAL FIRE / SMOKE IN FLIGHT',base:base(70,1000,20),fault:{er:104,rr:104,asi:70,alt:1000,map:20,altlight:true},
   seq:['battery','alternator','vents-open','land-immediate','mixture-off','fuel-off','rotor-brake','exit'],
   choices:['battery','alternator','vents-open','land-immediate','mixture-off','fuel-off','rotor-brake','exit','alt-reset','land-practical']},
 tach:{cue:'TACHOMETER FAILURE — FAILED SOURCE NOT CLEAR',base:base(70,900,20),fault:base(70,900,20),
   seq:['governor-control','land-practical'],choices:['governor-control','land-practical','governor-off','land-immediate','rpm97110']},
 governor:{cue:'RPM GOVERNOR MALFUNCTION',base:base(70,900,20),fault:{er:108,rr:108,asi:70,alt:900,map:22,govoff:false},
   seq:['manual-throttle','governor-off'],choices:['manual-throttle','governor-off','collective','battery','land-immediate']},
 low_g:{cue:'LOW-G / RIGHT-ROLL TENDENCY',base:base(80,900,19),fault:base(80,900,19),
   seq:['aft','positive-g','lateral'],choices:['aft','positive-g','lateral','collective','landing']},
 ad_wind:{cue:'MODERATE TURBULENCE ENCOUNTERED',base:base(80,1200,19),fault:base(80,1200,19),
   seq:['reduce-turb','smooth-controls','depart-turb'],choices:['reduce-turb','smooth-controls','depart-turb','land-practical','airspeed75','lateral']},
};

const warningCases=[
 {cue:'LOW RPM LIGHT / HORN — FORWARD FLIGHT',light:'lowrpm',horn:true,seq:['collective','throttle-on','aft'],choices:['collective','throttle-on','aft','collective-up','governor-off']},
 {cue:'ALT LIGHT REMAINS ON',light:'alt',seq:['nonessential-off','alt-reset','land-practical'],choices:['nonessential-off','alt-reset','land-practical','battery','land-immediate']},
 {cue:'CLUTCH LIGHT ON >10 SEC — NO OTHER DRIVE FAILURE INDICATION',light:'clutch',seq:['clutch-breaker','land-practical'],choices:['clutch-breaker','land-practical','autorotation','battery']},
 {cue:'OIL LIGHT / OIL PRESSURE LOSS CONFIRMED',light:'oil',seq:['check-engine-tach','check-oil','land-immediate'],choices:['check-engine-tach','check-oil','land-immediate','land-practical','alt-reset']},
 {cue:'STARTER-ON LIGHT STAYS ON',light:'starter',seq:['mixture-off','battery'],choices:['mixture-off','battery','alternator','continue-crank']},
 {cue:'CARBON MONOXIDE LIGHT WITH SYMPTOMS',light:null,seq:['heater-off','vents-open','land-immediate'],choices:['heater-off','vents-open','land-immediate','land-practical','battery']},
 {cue:'ROTOR BRAKE LIGHT IN FLIGHT',light:null,seq:['brake-release'],choices:['brake-release','rotor-brake','collective']},
 {cue:'FULL THROTTLE LIGHT',light:null,seq:['reduce-collective'],choices:['reduce-collective','collective-up','governor-off']},
 {cue:'MR CHIP LIGHT WITH VIBRATION',light:'mrchip',seq:['land-immediate'],choices:['land-immediate','land-practical','continue-crank']}
];
const audioCases=[
 {cue:'LOW RPM HORN / LOW RPM LIGHT',light:'lowrpm',horn:true,seq:['collective','throttle-on','aft'],choices:['collective','throttle-on','aft','collective-up','governor-off']},
 {cue:'HIGH RPM WARBLE — ROTOR RPM APPROACHING 110%',warble:true,seq:['raise-collective'],choices:['raise-collective','collective','governor-off','throttle-off']}
];

let cfg=configs[scenario];
if(scenario==='warning'){cfg={...baseConfig(),...warningCases[Math.floor(Math.random()*warningCases.length)]}}
if(scenario==='audio_alert'){cfg={...baseConfig(),...audioCases[Math.floor(Math.random()*audioCases.length)]}}
if(!cfg) cfg={...baseConfig(),cue:'SYSTEM ABNORMALITY',seq:[],choices:[]};
function baseConfig(){return {base:base(70,900,20),fault:base(70,900,20)}}

function ensureAudio(){if(!audioCtx){const X=window.AudioContext||window.webkitAudioContext;if(X)audioCtx=new X()}if(audioCtx?.state==='suspended')audioCtx.resume();if(audioEnabled)heliAudio.play().catch(()=>{})}
function stopHorn(){if(hornOsc){try{hornOsc.stop()}catch(e){}hornOsc=null}}
function horn(on){if(!audioEnabled){stopHorn();return}ensureAudio();if(on&&!hornOsc&&audioCtx){hornOsc=audioCtx.createOscillator();const g=audioCtx.createGain();hornOsc.frequency.value=620;g.gain.value=.035;hornOsc.connect(g).connect(audioCtx.destination);hornOsc.start()}else if(!on)stopHorn()}
function stopWarble(){clearInterval(warbleTimer);warbleTimer=null}
function warble(on){stopWarble();if(!on||!audioEnabled)return;ensureAudio();let hi=false;warbleTimer=setInterval(()=>{if(!audioCtx)return;const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=hi?900:650;g.gain.value=.025;o.connect(g).connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+.16);hi=!hi},190)}
function syncAudio(){if(!audioEnabled){heliAudio.pause();horn(false);warble(false);return}ensureAudio();horn(!!cfg.horn||!!cfg.fault?.lowrpm);warble(!!cfg.warble)}

function control(name){return [...document.querySelectorAll('.emergency-cockpit-control,.emergency-cockpit-shell .cockpit-control')].find(e=>(e.dataset.control||'').toLowerCase()===name.toLowerCase())}
function setControl(name,value){const c=control(name),b=c?.querySelector('b');if(b)b.textContent=value;if(c){const v=String(value).toUpperCase();c.classList.toggle('switch-on',['ON','BOTH','ENGAGED','OPEN','FULL RICH'].includes(v));c.classList.toggle('switch-off',['OFF','CLOSED','IDLE CUT-OFF'].includes(v))}}
function lamp(name,on){document.querySelectorAll('.emergency-cockpit-shell [data-light="'+name+'"]').forEach(x=>x.classList.toggle('lit',!!on))}
function needle(id,v){const x=document.getElementById(id);if(x)x.style.transform='rotate('+v+'deg)'}
function tach(er,rr){needle('em_engineNeedle',-135+(Math.max(0,Math.min(110,er))/110)*270);needle('em_rotorNeedlePanel',-135+(Math.max(0,Math.min(110,rr))/110)*270);const x=$('#em_tachRead');if(x)x.textContent='E '+er+'% * R '+rr+'%'}
function flightState(s){tach(s.er,s.rr);setControl('Airspeed',s.asi+' KIAS');setControl('Altimeter',s.alt+' FT AGL');setControl('Manifold pressure',s.map+' IN HG');[['#emSummaryAirspeed',s.asi],['#emSummaryAltitude',s.alt],['#emSummaryERpm',s.er],['#emSummaryRRpm',s.rr],['#emSummaryMap',s.map]].forEach(([q,v])=>{const x=$(q);if(x)x.textContent=v});const oil=$('#em_oilRead');if(oil)oil.textContent=(s.er<65?'35':'55')+' PSI'}
function normalFlight(){flightState(cfg.base);const es=$('#em_engineState');if(es){es.classList.add('running');es.querySelector('b').textContent=scenario==='fire_start'?'ENGINE CRANKING':'ENGINE RUNNING'}$('#em_mainRotor')?.classList.add('spinning');[['Governor','ON'],['Clutch','ENGAGED'],['Alternator','ON'],['Battery & strobe','ON'],['Ignition','BOTH'],['Mixture','FULL RICH'],['Carb heat','AS REQUIRED'],['Rotor brake','RELEASED'],['Throttle','OPEN'],['Fuel shut-off valve','ON'],['Doors','SECURED'],['Cyclic / collective friction','OFF'],['Seat belts','FASTENED']].forEach(x=>setControl(...x));['starter','clutch','lowrpm','govoff','lowfuel','oil','alt','mrtemp','mrchip','trchip'].forEach(x=>lamp(x,false))}
function injectFault(){flightState(cfg.fault||cfg.base);if(cfg.light)lamp(cfg.light,true);lamp('lowrpm',!!cfg.fault?.lowrpm||cfg.light==='lowrpm');lamp('oil',!!cfg.fault?.oil||cfg.light==='oil');lamp('alt',!!cfg.fault?.altlight||cfg.light==='alt');lamp('govoff',scenario==='governor');$('#flightCue').textContent=cfg.cue}
function renderActions(){const box=$('#emActions');box.innerHTML='';(cfg.choices||cfg.seq).forEach(code=>{const b=document.createElement('button');b.type='button';b.dataset.control=code;b.textContent=A[code]||code;b.addEventListener('click',()=>act(b));box.appendChild(b)})}
function filterControls(){document.querySelectorAll('.em87-actions button').forEach(b=>{b.classList.remove('used','wrong','test-selected');b.hidden=false})}

function effect(id){
 if(id==='collective'){setControl('Collective','LOWERED');tach(cfg.fault.er,Math.max(102,cfg.fault.rr||102));lamp('lowrpm',false);horn(false);return'Collective lowered; rotor RPM recovery response shown.'}
 if(id==='collective-up'||id==='raise-collective'){setControl('Collective','RAISED');return'Collective raised.'}
 if(id==='aft'){setControl('Cyclic','GENTLE AFT');return'Gentle aft cyclic applied to restore positive G / rotor loading.'}
 if(id==='positive-g')return'Positive G / rotor thrust re-established before lateral cyclic correction.'
 if(id==='forward'){setControl('Cyclic','FORWARD / LEVEL');return'Forward cyclic applied to level the helicopter.'}
 if(id==='lateral'||id==='lateral-stop'){setControl('Cyclic','LATERAL');return'Lateral cyclic applied.'}
 if(id==='airspeed65'||id==='airspeed70'||id==='airspeed75'){const v=id==='airspeed65'?65:id==='airspeed70'?70:75;setControl('Airspeed',v+' KIAS');$('#emSummaryAirspeed').textContent=v;return`Airspeed changed to ${v} KIAS.`}
 if(id==='rpm97110'){tach(cfg.fault.er,102);$('#emSummaryRRpm').textContent='102';return'Rotor RPM adjusted into the 97–110% range.'}
 if(id==='rpm90'){tach(cfg.fault.er,90);$('#emSummaryRRpm').textContent='90';return'Rotor RPM set approximately 90% for maximum glide.'}
 if(id==='right-pedal'){setControl('Pedals','RIGHT INPUT');return'Right pedal applied as required.'}
 if(id==='mixture-rich'){setControl('Mixture','FULL RICH');return'Mixture set full rich.'}
 if(id==='mixture-off'){setControl('Mixture','OFF');return'Mixture moved OFF.'}
 if(id==='primer-lock'){setControl('Primer (if installed)','DOWN & LOCKED');return'Primer verified down and locked.'}
 if(id==='throttle-crack'){setControl('Throttle','CLOSED / CRACKED');return'Throttle closed, then cracked slightly.'}
 if(id==='starter'||id==='continue-crank'){setControl('Ignition','START');lamp('starter',true);return id==='starter'?'Starter actuated.':'Cranking continued.'}
 if(id==='throttle-off'){setControl('Throttle','OFF / OVERTRAVEL');return'Throttle rolled off into overtravel spring.'}
 if(id==='throttle-on'){setControl('Throttle','ROLL ON');return'Throttle rolled on.'}
 if(id==='manual-throttle'){setControl('Throttle','MANUAL CONTROL');tach(104,104);return'Manual throttle control established.'}
 if(id==='governor-off'){setControl('Governor','OFF');lamp('govoff',true);return'Governor switched OFF.'}
 if(id==='fuel-off'||id==='switches-fuel-off'){setControl('Fuel shut-off valve','OFF');if(id==='switches-fuel-off')setControl('Avionics','OFF');return id==='fuel-off'?'Fuel valve OFF.':'Unnecessary switches and fuel valve OFF.'}
 if(id==='battery'){setControl('Battery & strobe','OFF');return'Battery switched OFF.'}
 if(id==='alternator'){setControl('Alternator','OFF');return'Alternator switched OFF.'}
 if(id==='alt-reset'){setControl('Alternator','RESET');lamp('alt',false);return'Alternator reset attempted.'}
 if(id==='doors-unlatch'){setControl('Doors','UNLATCHED');return'Doors unlatched.'}
 if(id==='seatbelt-exit'){setControl('Seat belts','RELEASED');return'Seat belt released and egress initiated.'}
 if(id==='rotor-brake'){setControl('Rotor brake','APPLIED');return'Rotor brake applied when time permits.'}
 if(id==='brake-release'){setControl('Rotor brake','RELEASED');return'Rotor brake released immediately.'}
 if(id==='heater-off'){return'Cabin heater switched OFF.'}
 if(id==='vents-open'||id==='cabin-heat-off'){return id==='vents-open'?'Cabin vents opened.':'Cabin heat switched OFF.'}
 if(id==='reduce-collective'){setControl('Collective','LOWERED AS REQUIRED');return'Collective lowered to reduce power demand.'}
 if(id==='land-immediate')return'Immediate landing decision made.'
 if(id==='land-practical')return'Land-as-soon-as-practical decision made.'
 if(id==='landing')return'Suitable landing area selected.'
 if(id==='flare40')return'Cyclic flare initiated at about 40 ft AGL.'
 if(id==='flare-ground')return'Cyclic flare initiated as the ground is approached.'
 if(id==='cushion8'){setControl('Collective','RAISE FOR CUSHION');return'Helicopter leveled and collective raised just before touchdown.'}
 if(id==='settle')return'Aircraft allowed to settle.'
 if(id==='hover-water')return'Descent to a hover above the water initiated.'
 if(id==='passenger-exit')return'Passenger egress step completed.'
 if(id==='fly-clear')return'Helicopter moved clear of passenger.'
 if(id==='water-contact')return'Aircraft held level at water contact.'
 if(id==='normal-landing')return'Normal landing branch selected.'
 if(id==='auto-landing')return'Autorotation landing completed.'
 if(id==='autorotation'||id==='safe-auto'){setControl('Collective','LOWERED');return id==='safe-auto'?'Safe autorotation established before restart attempt.':'Autorotation entered.'}
 if(id==='rpm50-60'){tach(55,0);return'Engine held at 50–60% RPM briefly.'}
 if(id==='governor-control')return'Governor used to control RPM while tach indication is uncertain.'
 if(id==='monitor-tach')return'Remaining tachometer used to monitor RPM.'
 if(id==='check-engine-tach')return'Engine tach checked for power loss.'
 if(id==='check-oil')return'Oil pressure indication checked.'
 if(id==='clutch-breaker'){lamp('clutch',false);return'Clutch circuit breaker pulled after persistent light.'}
 if(id==='nonessential-off'){setControl('Avionics','OFF');return'Nonessential electrical equipment switched OFF.'}
 if(id==='reduce-turb'){setControl('Airspeed','60–70 KIAS');return'Power reduced and slower cruise speed established.'}
 if(id==='smooth-controls')return'Smooth, gentle control inputs used; overcontrol avoided.'
 if(id==='depart-turb')return'Course changed to leave isolated turbulence.'
 if(id==='no-flight')return'Flight prohibited / discontinued for the stated condition.'
 if(id==='exit')return'Helicopter egress step completed.'
 return'Procedure action recorded.'
}

function updateScore(){score=Math.max(0,100-mistakes*20);$('#emScore').textContent=score+' pts'}
function act(b){
 if(b.classList.contains('used')&&mode!=='test')return;
 const id=b.dataset.control, expected=cfg.seq[progress],ok=id===expected;
 $('#emPhase').textContent='RESPOND';history.push({id,ok});b.classList.add('used');
 if(mode==='test'){b.classList.add('test-selected');if(!ok)mistakes++;else progress++}
 else if(ok){progress++;b.classList.remove('wrong');b.classList.add('used')}else{mistakes++;b.classList.add('wrong')}
 updateScore();
 const li=document.createElement('li');li.className=mode==='test'?'selected':(ok?'correct':'wrong');
 li.textContent=`${history.length}. ${A[id]||id}${mode==='learn'?(ok?' — correct next action':' — not the next POH action'):''}`;$('#emSteps').appendChild(li);
 $('#actionSummary').textContent=history.map(x=>A[x.id]||x.id).join(' → ');
 $('#actionEffect').textContent=effect(id);
 if(progress===cfg.seq.length){
   if(mode==='test'){$('#emPhase').textContent='READY TO DEBRIEF';$('#coachTitle').textContent='Sequence entered';$('#coachText').textContent='Evaluate to reveal scoring and review.'}
   else{$('#emPhase').textContent='COMPLETE';$('#coachTitle').textContent='Scenario complete';$('#coachText').textContent='Required POH procedure sequence completed.'}
 }else if(mode==='learn'){$('#coachTitle').textContent=ok?'Correct priority':'Recheck the sequence';$('#coachText').textContent=ok?'Continue with the next POH action.':'That action is not next in this procedure.'}
}

function setInitial(){
 progress=0;history=[];mistakes=0;elapsed=0;updateScore();$('#emPhase').textContent='IN FLIGHT';$('#actionSummary').textContent='None yet.';$('#actionEffect').textContent='Awaiting pilot action.';$('#emSteps').innerHTML='';$('#eout').innerHTML='';
 if(scenario==='warning')cfg={...baseConfig(),...warningCases[Math.floor(Math.random()*warningCases.length)]};
 if(scenario==='audio_alert')cfg={...baseConfig(),...audioCases[Math.floor(Math.random()*audioCases.length)]};
 renderActions();normalFlight();injectFault();filterControls();syncAudio()
}
document.querySelectorAll('[data-emmode]').forEach(b=>b.onclick=()=>{mode=b.dataset.emmode;document.querySelectorAll('[data-emmode]').forEach(x=>x.classList.toggle('active',x===b));$('#coachText').textContent=mode==='test'?'No correctness is revealed until debrief. Operate the cockpit or choose the procedure actions in order.':mode==='practice'?'Perform the procedure in order using the cockpit controls and action choices.':'Follow the POH sequence; correct actions turn green and incorrect actions turn red.';setInitial()});
$('#emReset').onclick=setInitial;
$('#emEvaluate').onclick=async()=>{$('#emPhase').textContent='DEBRIEF';const entered=history.map(x=>A[x.id]||x.id).join(' '),complete=progress===cfg.seq.length;$('#eout').innerHTML=`<h3>Procedure debrief</h3><b>${complete?'Sequence completed':'Sequence incomplete'} — ${score}%</b><p>Expected: ${cfg.seq.map(x=>A[x]||x).join(' → ')}</p><p>Entered: ${entered||'No actions entered.'}</p>`};

document.querySelectorAll('.audio-toggle').forEach(b=>{b.setAttribute('aria-pressed','true');b.textContent='AUDIO ON';b.addEventListener('click',()=>{audioEnabled=!audioEnabled;b.setAttribute('aria-pressed',String(audioEnabled));b.textContent=audioEnabled?'AUDIO ON':'AUDIO OFF';syncAudio()})});
document.addEventListener('pointerdown',()=>{if(audioEnabled)syncAudio()},{once:true});

const controlMap={
 'governor':['governor-off'],'alternator':['alternator','alt-reset'],'battery & strobe':['battery'],
 'mixture':['mixture-rich','mixture-off'],'primer (if installed)':['primer-lock'],
 'rotor brake':['rotor-brake','brake-release'],'fuel shut-off valve':['fuel-off'],
 'throttle':['throttle-crack','throttle-off','throttle-on','manual-throttle'],
 'doors':['doors-unlatch'],'cyclic':['aft','forward','lateral','lateral-stop','positive-g'],
 'collective':['collective','collective-up','raise-collective','reduce-collective'],
 'pedals':['right-pedal'],'seat belts':['seatbelt-exit'],'ignition':['starter','continue-crank']
};
document.querySelectorAll('.emergency-cockpit-control').forEach(btn=>btn.addEventListener('click',()=>{
 const key=(btn.dataset.control||'').toLowerCase(),possible=controlMap[key]||[],expected=cfg.seq[progress];
 const code=possible.includes(expected)?expected:possible.find(x=>(cfg.choices||[]).includes(x));if(!code)return;
 const action=document.querySelector(`#emActions [data-control="${code}"]`);if(action)action.click();
 btn.classList.add('selected-control');setTimeout(()=>btn.classList.remove('selected-control'),450)
}));

timer=setInterval(()=>{if($('#emPhase').textContent==='DEBRIEF')return;elapsed++;$('#emClock').textContent=`00:${String(elapsed).padStart(2,'0')}`},1000);
setInitial();
window.addEventListener('pagehide',()=>{heliAudio.pause();horn(false);warble(false)})
})();