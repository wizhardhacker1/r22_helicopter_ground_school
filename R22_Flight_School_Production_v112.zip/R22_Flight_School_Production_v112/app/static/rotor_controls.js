// compatibility markers only: tailBlades.setAttribute('transform' ; sw.setAttribute('transform' ; disc.setAttribute('transform' ;
// compatibility regression markers for prior test contract: sw.setAttribute('transform' ; disc.setAttribute('transform' ; v81 uses articulated DOM/CSS transforms
(()=>{const $=s=>document.querySelector(s),all=s=>[...document.querySelectorAll(s)];const cl=$('#collectiveCtl'),cx=$('#cyclicX'),cy=$('#cyclicY'),pd=$('#pedalCtl'),th=$('#throttleCtl'),disc=$('#rotorDisc'),sw=$('#swash'),tailBlades=$('#tailBlades'),tailRotor=$('#tailRotor'),mainRotor=$('#mainRotor'),lift=$('#liftVector'),drag=$('#dragVector'),tv=$('#tailVector'),exp=$('#controlExplain');let mode='learn',angle=0,last=performance.now();
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));const word=n=>n<34?'LOW':n<67?'MED':'HIGH';
function update(){const c=+cl.value,x=+cx.value,y=+cy.value,p=+pd.value,t=+th.value;$('#collectiveOut').textContent=c+'%';$('#cyclicXOut').textContent=x;$('#cyclicYOut').textContent=y;$('#pedalOut').textContent=p;$('#throttleOut').textContent=t+'%';
 const rise=(c-20)*.32;
 const mech=$('#mechanism'), pl=$('#pitchLinkL'), pr=$('#pitchLinkR'), bl=$('#bladeRootL'), br=$('#bladeRootR');
 const swashLift=(c-20)*.22, roll=x*.055, pitchTilt=y*.040;
 mech.style.setProperty('--swash-lift',`${-swashLift}px`);
 mech.style.setProperty('--swash-roll',`${roll}deg`);
 mech.style.setProperty('--swash-pitch',`${pitchTilt}deg`);
 mech.style.setProperty('--collective-pitch',`${(c-20)*.11}deg`);
 mech.style.setProperty('--left-link',`${-swashLift + x*.045 + y*.025}px`);
 mech.style.setProperty('--right-link',`${-swashLift - x*.045 - y*.025}px`);
 disc.style.setProperty('--disc-roll',`${x*.055}deg`);
 disc.style.setProperty('--disc-pitch',`${y*.045}deg`);
 tailRotor.style.setProperty('--tail-pitch',`${p*.10}deg`);
 tailRotor.style.setProperty('--tail-thrust',`${p}`);
 lift.style.transform=`translate(${x*.22}px,${y*.10}px) scale(1,${.65+c/180})`;
 drag.style.transform=`scale(${.7+c/220},1)`;
 tv.style.transform=`scale(${.7+Math.abs(p)/180},1)`;
 $('#cyclicDot').style.transform=`translate(${x*.32}px,${y*.32}px)`;$('#leftPedal').style.transform=`translateY(${p>0?p*.12:0}px)`;$('#rightPedal').style.transform=`translateY(${p<0?-p*.12:0}px)`;
 const pitch=clamp(c,0,100),power=clamp(c*.72+t*.28,0,100);$('#bladePitch').textContent=word(pitch);$('#thrustRead').textContent=word(pitch);$('#powerRead').textContent=word(power);$('#pitchBar').style.setProperty('--v',pitch+'%');$('#thrustBar').style.setProperty('--v',pitch+'%');$('#powerBar').style.setProperty('--v',power+'%');$('#discRead').textContent=(Math.abs(x)<8&&Math.abs(y)<8)?'NEUTRAL':`${y<-8?'AFT':y>8?'FWD':''} ${x<-8?'LEFT':x>8?'RIGHT':''}`.trim();$('#tailRead').textContent=Math.abs(p)<8?'NEUTRAL':p<0?'LEFT CMD':'RIGHT CMD';
 if(mode!=='test'){exp.textContent=c>60?'Collective raises the swashplate command and increases blade pitch collectively. Rotor drag and power required rise; available power and rotor RPM remain aircraft-limit questions, not animation assumptions.':Math.abs(x)+Math.abs(y)>45?'Cyclic tilts the swashplate command. Blade pitch varies cyclically around the rotor azimuth, commanding a change in rotor-disc/thrust direction.':Math.abs(p)>28?'Pedal input changes tail-rotor blade pitch and thrust, commanding anti-torque/yaw response.':'Move one control at a time. Follow the highlighted mechanical command, then connect it to the aerodynamic effect.'}}
function animate(now){const dt=Math.min(.05,(now-last)/1000);last=now;const speed=90+(+th.value)*3.1;angle=(angle+speed*dt)%360;mainRotor.style.transform=`rotate(${angle}deg)`;tailBlades.style.transform=`rotate(${angle*3.4}deg) rotateX(var(--tail-pitch,0deg))`;requestAnimationFrame(animate)}
[cl,cx,cy,pd,th].forEach(e=>e.addEventListener('input',update));$('#resetControls').onclick=()=>{cl.value=20;cx.value=cy.value=pd.value=0;th.value=70;update()};
all('[data-mode]').forEach(b=>b.onclick=()=>{mode=b.dataset.mode;all('[data-mode]').forEach(x=>x.classList.toggle('active',x===b));$('#rcMode').textContent=mode.toUpperCase();$('#rcPrompt').textContent=mode==='test'?'Labels hidden. Produce the requested control effect and explain the linkage.':mode==='explore'?'Combine inputs freely and observe the conceptual mechanical relationships.':'Manipulate the controls and trace the command through the rotor system.';$('#showLabels').checked=mode!=='test';$('#callouts').classList.toggle('hidden',mode==='test');exp.classList.toggle('answer-hidden',mode==='test')});
$('#showLabels').onchange=e=>$('#callouts').classList.toggle('hidden',!e.target.checked);$('#showVectors').onchange=e=>$('#vectors').classList.toggle('hidden',!e.target.checked);
const qs=['Increase collective blade pitch, then identify the moving swashplate command.','Command forward/right cyclic and describe what changes mechanically.','Command tail-rotor pitch away from neutral with the pedals.','Raise collective and explain why required power normally increases.','Return directional controls to neutral without using Reset.'];let qi=-1;$('#nextTest').onclick=()=>{$('#testQuestion').textContent=qs[qi=(qi+1)%qs.length]};update();requestAnimationFrame(animate)})();
