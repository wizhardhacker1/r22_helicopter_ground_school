(function(){
'use strict';
function initR22Loading(){

 const byId=id=>document.getElementById(id);
 const fire=()=>{ if(typeof window.calcWB==='function') window.calcWB(); };
 const pairs=[['vis_pilot','pilot'],['vis_passenger','passenger'],['vis_left_bag','left_bag'],['vis_right_bag','right_bag']];
 function setOutput(range){const o=range?.parentElement?.querySelector('output');if(o)o.textContent=range.value;}
 pairs.forEach(([rangeId,numberId])=>{
   const range=byId(rangeId), number=byId(numberId); if(!range||!number)return;
   const fromRange=()=>{number.value=range.value;setOutput(range);fire();};
   const fromNumber=()=>{let v=Number(number.value);if(!Number.isFinite(v))return;v=Math.max(Number(range.min),Math.min(Number(range.max),v));range.value=String(v);setOutput(range);fire();};
   range.addEventListener('input',fromRange); range.addEventListener('change',fromRange);
   number.addEventListener('input',fromNumber); number.addEventListener('change',fromNumber);
   setOutput(range);
 });
 const fuel=byId('vis_fuel');
 if(fuel){
   const syncFuel=()=>{let total=Number(fuel.value);if(!Number.isFinite(total))return;total=Math.max(0,Math.min(26.3,total));const main=Math.min(16.9,total),aux=Math.max(0,total-main);const m=byId('main_fuel'),a=byId('aux_fuel');if(m)m.value=main.toFixed(1);if(a)a.value=aux.toFixed(1);const out=fuel.parentElement?.querySelector('output');if(out)out.textContent=total.toFixed(1)+' gal';fire();};
   fuel.addEventListener('input',syncFuel); fuel.addEventListener('change',syncFuel);
 }
 ['left_door_removed','right_door_removed','left_controls_removed'].forEach(id=>byId(id)?.addEventListener('change',()=>{const c=byId('doorCaution');if(c)c.hidden=!byId('left_door_removed')?.checked;fire();}));
 byId('model')?.addEventListener('change',fire);
 ['empty_weight','empty_arm','empty_lateral_arm','pilot','passenger','left_bag','right_bag','main_fuel','aux_fuel','fuel_burn_gal','accessory_weight','accessory_lateral_arm'].forEach(id=>{const e=byId(id);e?.addEventListener('input',fire);e?.addEventListener('change',fire);});
 // Initial synchronization guarantees the visible sliders and numeric W&B fields agree before the first plot.
 pairs.forEach(([r,n])=>{const range=byId(r),number=byId(n);if(range&&number){number.value=range.value;setOutput(range);}});
 if(fuel){let total=Number(fuel.value),m=byId('main_fuel'),a=byId('aux_fuel');if(m)m.value=Math.min(16.9,total).toFixed(1);if(a)a.value=Math.max(0,total-16.9).toFixed(1);}
 fire();

}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initR22Loading,{once:true});
else initR22Loading();
})();
