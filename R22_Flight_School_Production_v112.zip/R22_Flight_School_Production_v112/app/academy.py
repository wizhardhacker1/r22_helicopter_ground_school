"""R22 Academy curriculum. Grounded in FAA-S-ACS-15, FAA-H-8083-21B/25C and R22 POH/Safety Notices.
Training text is educational; aircraft-specific operating values/procedures defer to the installed current approved R22 POH/RFM and applicable supplements.
"""
ACADEMY_COURSES = [
{
 'key':'radio','title':'Radio Academy - Hear, Decode, Speak','acs':'I, III','refs':'FAA AIM Ch. 4; FAA-S-ACS-15; FAA airport operations guidance','r22':'R22 POH normal procedures where radio/electrical configuration applies',
 'objective':'Build a beginner from radio anxiety to structured, accurate VFR helicopter communications.',
 'lessons':[
  ('1. Radio anatomy','Every transmission has a job. Start by identifying who you are calling, who you are, where you are when needed, and what you want. Listen before transmitting so you do not cover another call. Learn the difference between an advisory, an instruction, a clearance, and information.'),
  ('2. Non-towered operations','Practice self-announcing position, altitude, intentions and runway/landing area without pretending CTAF is a control frequency. Build inbound, pattern, departure and helicopter-specific calls. Keep transmissions concise and update when position or intentions materially change.'),
  ('3. Tower and ground','Learn initial calls, taxi instructions, hold-short readbacks, pattern entries, takeoff/landing clearances and when to ask for clarification. Helicopters may receive routes or movement instructions different from fixed-wing traffic; comply with the actual clearance.'),
  ('4. Flight following and services','Practice requests that include aircraft identification/type, position, altitude, destination and request. Learn transponder/IDENT instructions and frequency changes without treating VFR flight following as a substitute for pilot responsibility.'),
  ('5. Abnormal and emergency radio','Use plain language when necessary. Practice declaring an emergency, stating nature, position, intentions, persons aboard and fuel when requested. Aviate first; radio work supports aircraft control rather than replacing it.'),
  ('6. Listening practicum','Use the offline controller audio scenarios, write down calls, identify call sign/instruction/runway/report point, then give the readback. When connected, the optional Live ATC link can be used for listening practice; availability and content are external and not required by the course.')],
 'lab':'radio_decode'
},
{
 'key':'weatherbrief','title':'Preflight Briefing & Dispatch Lab','acs':'I, VI','refs':'FAA-S-ACS-15; PHAK weather/navigation chapters; Aviation Weather Handbook','r22':'R22 POH \xa7\xa72,4,5,6 and applicable supplements',
 'objective':'Combine weather, airspace, NOTAM/TFR awareness, fuel, loading, performance and risk into one departure decision.',
 'lessons':[
  ('1. Define the mission','Write departure, destination, route, planned time, occupants, baggage and fuel. A good briefing begins with a specific proposed operation, not a pile of unrelated weather products.'),
  ('2. Weather picture','Build from broad to local: pressure systems/fronts, winds, clouds/visibility, precipitation, convective risk and airport observations/forecasts. Identify what can change during the flight and what would trigger delay, diversion or cancellation.'),
  ('3. Airspace and flight information','Review charted airspace, frequencies, airport/heliport data, NOTAMs and TFRs using current sources. Identify permissions/equipment/communications required along the route.'),
  ('4. R22 loading and performance','Use actual aircraft empty-weight data, occupants, baggage and fuel. Verify weight/CG for takeoff and landing, then use the correct R22 model performance data for density altitude and hover planning.'),
  ('5. Risk decision','Apply PAVE/5P thinking and personal minimums. Separate legal from prudent. State specific escape options: delay, reduce load, add fuel stop, alter route, land, or cancel.'),
  ('6. Dispatch exercise','Complete every gate in the dispatch worksheet. The exercise is not complete merely because the page was opened; each planning area requires an affirmative review and final decision.')],
 'lab':'dispatch'
},
{
 'key':'hovercheck','title':'Stabilized Hover Check & Departure Gate','acs':'IV, V','refs':'FAA SAFO 16016; FAA-H-8083-21B Ch. 9; FAA-S-ACS-15','r22':'R22 POH \xa7\xa72,4,5',
 'objective':'Teach why the helicopter is evaluated light-on-skids/stabilized before committing to departure.',
 'lessons':[
  ('1. Why hover checks matter','A stabilized hover gives the pilot an opportunity to detect control, indication, configuration or power problems before accelerating away. It is a deliberate decision gate, not a ceremonial pause.'),
  ('2. Light on the skids','As collective is increased, maintain heading and position while remaining alert for abnormal control response, vibration, warning indications or unexpected power requirement. If something is wrong, lower collective and resolve it.'),
  ('3. Stabilized hover','At an appropriate training hover, verify controllability, engine/rotor indications and available power against the planned condition. Do not use the trainer to invent aircraft limits; use the current RFM/POH and instructor technique.'),
  ('4. Abort criteria','A warning, abnormal vibration, control problem, unexpected power requirement, unsuitable wind/visibility or other unresolved discrepancy means do not continue merely because the checklist is complete.'),
  ('5. Departure decision','The app distinguishes GROUND CHECKS COMPLETE from READY FOR DEPARTURE. The latter requires the hover-check decision gate.')],
 'lab':'hover_gate'
},
{
 'key':'systems','title':'R22 Systems Explorer','acs':'I, II','refs':'FAA-H-8083-21B Ch. 4-5; FAA-S-ACS-15','r22':'R22 POH \xa77; Safety Notices as applicable',
 'objective':'Understand how the R22 systems interact so cockpit indications make sense instead of being memorized in isolation.',
 'lessons':[
  ('1. Rotor and flight controls','Trace cyclic, collective and pedals to rotor-system effects. Connect control movement to blade pitch, rotor thrust and anti-torque rather than memorizing lever names.'),
  ('2. Engine, belts, clutch and freewheeling unit','Follow power from engine through the belt drive/clutch to the rotor system. Understand why engine and rotor tach needles normally correlate and why they can separate during a sprag/freewheeling check or power loss.'),
  ('3. Governor and throttle','Learn the relationship between throttle, governor and rotor/engine RPM. The governor assists RPM control; it does not remove the pilot\u2019s responsibility to monitor RPM.'),
  ('4. Fuel and induction','Trace fuel from tanks through the system to the engine. Connect carburetor icing risk, carb heat and power/RPM management to actual indications and conditions.'),
  ('5. Electrical and annunciators','Trace battery, alternator and electrical loads. Learn what STARTER, CLUTCH, LOW RPM, GOV OFF, LOW FUEL, OIL, ALT, MR TEMP, MR CHIP and TR CHIP indications mean in the context of the approved R22 material.'),
  ('6. Instruments','Use the dual E/R tach, manifold pressure, oil indications, altimeter, airspeed and other instruments as a system. Practice recognizing relationships that do not make sense.')],
 'lab':'systems_trace'
},
{
 'key':'carbice','title':'Carburetor Ice & Induction Management','acs':'I, VII, IX','refs':'FAA-H-8083-21B; PHAK aircraft systems/weather; FAA-S-ACS-15','r22':'R22 POH normal/emergency procedures; Robinson Safety Notices including carburetor-ice guidance',
 'objective':'Recognize carb-ice conditions and understand R22 carb-heat/CAT management without reducing it to a single memorized temperature.',
 'lessons':[
  ('1. Why carb ice forms','Fuel vaporization and pressure drop can cool the carburetor enough for ice even when outside air temperature is well above freezing. Moisture and operating condition matter.'),
  ('2. CAT and carb heat','Learn what the carburetor-air-temperature indication tells you and how carb heat changes induction temperature and available power. Use the POH procedure for the aircraft configuration.'),
  ('3. Governor interaction','A governor can compensate for some power change and may make developing induction problems less obvious if the pilot only watches RPM. Cross-check power and engine indications.'),
  ('4. Scenario recognition','Work humidity/temperature/power scenarios, identify increasing risk, and choose the POH-based action rather than waiting for obvious engine roughness.'),
  ('5. Planning','Include carb-ice risk in weather and power planning, especially during reduced-power operations and conditions favorable to induction icing.')],
 'lab':'carbice'
},
{
 'key':'rotorenergy','title':'Rotor RPM & Energy Management','acs':'VII, IX','refs':'FAA-H-8083-21B aerodynamics/emergencies; FAA-S-ACS-15','r22':'R22 POH \xa7\xa72-4; Robinson low-RPM safety notices',
 'objective':'Build the cause-and-effect model behind low rotor RPM, collective input and autorotative energy.',
 'lessons':[
  ('1. Rotor energy','Rotor RPM represents stored rotational energy. Excessive loss of RPM can rapidly reduce control authority and lift; helicopter pilots monitor RPM continuously.'),
  ('2. Collective relationship','Increasing collective increases blade pitch and rotor drag. With inadequate power, that can reduce rotor RPM. Lowering collective reduces blade pitch/drag and is central to preserving RPM after power loss.'),
  ('3. Engine versus rotor RPM','The dual tach shows engine and rotor speed. Coupled operation differs from autorotative/freewheeling operation, where the needles can separate.'),
  ('4. Power failure recognition','Recognition comes before a memorized sequence: unexpected yaw, sound change, RPM behavior and warning cues must lead to immediate aircraft-control priorities.'),
  ('5. Energy at the bottom','Autorotation training is an instructor-led flight skill. The ground trainer teaches why rotor energy, airspeed, flare timing concepts and collective application matter without claiming to teach physical proficiency.')],
 'lab':'rotor_energy'
},
{
 'key':'hv','title':'R22 Height-Velocity Diagram Lab','acs':'I, V, IX','refs':'FAA-H-8083-21B performance/emergencies; FAA-S-ACS-15','r22':'R22 POH \xa75 H-V diagram for the applicable model/configuration',
 'objective':'Read the H-V diagram as a risk/planning tool rather than memorize a picture.',
 'lessons':[
  ('1. What the diagram represents','The H-V diagram identifies combinations of height and airspeed associated with reduced opportunity for a successful landing after power loss. It is not a promise that operation outside a shaded area is risk free.'),
  ('2. Read both axes','Always identify height reference and airspeed units before interpreting a point. Use the correct R22 POH chart and conditions.'),
  ('3. Takeoff profile','Understand why acceleration and climb profiles seek to reduce exposure to unfavorable combinations while accounting for obstacles and actual operating conditions.'),
  ('4. Approach profile','Apply the same thinking on approach: airspeed, height, landing area and power margin are connected.'),
  ('5. Scenario drill','Plot training points and explain the risk direction. Exact acceptability must be read from the current approved chart rather than guessed from this conceptual lab.')],
 'lab':'hv'
},
{
 'key':'wind','title':'Wind, LTE/Unanticipated Yaw & Turbulence','acs':'I, IV, V, IX','refs':'FAA-H-8083-21B; FAA-S-ACS-15; FAA/USHST helicopter safety material','r22':'R22 POH limitations/normal procedures; Robinson Safety Notices on wind/turbulence/yaw',
 'objective':'Teach a beginner to treat wind as a helicopter control/performance hazard, not just a runway number.',
 'lessons':[
  ('1. Wind around a helicopter','Relative wind affects rotor inflow, tail-rotor effectiveness, control position, hover power and workload. Buildings, ridges and obstacles can create rapidly changing local flow.'),
  ('2. Translating tendency and pedal workload','Understand why hover attitude/control position changes with wind and loading. Do not normalize large or changing pedal demand without asking why.'),
  ('3. Unanticipated yaw/LTE concepts','Recognize developing yaw early, maintain aircraft control and avoid operating assumptions that exceed aircraft/instructor guidance. Learn the aerodynamic conditions rather than treating LTE as an engine failure.'),
  ('4. Gusts and turbulence','High winds/turbulence can cause large control inputs, rotor-system loads and rapidly changing power requirements. Use POH limitations/cautions and conservative decision making.'),
  ('5. Wind decision lab','Choose wind direction, gust spread and operating area; identify likely workload/hazard cues and state an escape/abort plan before takeoff.')],
 'lab':'wind'
},
{
 'key':'wires','title':'Wire-Strike & Low-Level Hazard Awareness','acs':'I, VI, IX','refs':'FAA-H-8083-21B; FAA helicopter safety publications; FAA-S-ACS-15','r22':'Robinson Safety Notices concerning wires/low flight and flight planning',
 'objective':'Train the student to search for wire clues before trying to see the wire itself.',
 'lessons':[
  ('1. Why wires disappear','Thin conductors can blend into terrain, haze, sun angle and background clutter. Visibility of poles does not guarantee visibility of the span.'),
  ('2. Look for structures','Search for poles, towers, insulators, cleared corridors, roads crossing valleys and changes in vegetation. Assume a connection may exist between support structures until proven otherwise.'),
  ('3. Reconnaissance mindset','Low-level/confined operations require deliberate high/low/ground reconnaissance techniques taught by an instructor. Never descend into an area simply because the landing spot itself looks clear.'),
  ('4. Escape planning','Before committing, identify wind, approach/departure paths, obstacles, wires, power margin and an escape route.'),
  ('5. Hazard hunt','Use the visual hazard exercise to identify support structures and likely wire paths before revealing the answers.')],
 'lab':'hazard_hunt'
},
{
 'key':'rollover','title':'Dynamic Rollover & Slope Awareness','acs':'IV, V, IX','refs':'FAA-H-8083-21B aerodynamics/maneuvers; FAA-S-ACS-15','r22':'Robinson Safety Notices and R22 operating guidance',
 'objective':'Understand the pivot-point mechanism and why improper collective/cyclic response can make rollover unrecoverable.',
 'lessons':[
  ('1. The pivot point','Dynamic rollover can develop when a skid/wheel becomes a pivot while rolling moment continues. Once critical geometry/rate develops, cyclic authority alone may not stop it.'),
  ('2. Common setup','Slope operations, snagged skids, lateral drift at touchdown/liftoff and improper control application can create the pivot condition.'),
  ('3. Collective matters','If rollover begins around a pivot, increasing lift can worsen the rolling moment. Correct recognition and collective response are essential concepts for instructor-led slope training.'),
  ('4. Prevention','Establish stable hover/ground contact, control drift, know wind/slope limits and avoid abrupt control movement.'),
  ('5. Concept lab','Move the slope/pivot controls and identify whether the setup increases or reduces rollover risk.')],
 'lab':'rollover'
},
{
 'key':'vrs','title':'Vortex Ring State / Settling With Power','acs':'I, V, IX','refs':'FAA-H-8083-21B aerodynamics/emergencies; FAA-S-ACS-15','r22':'R22 POH/Safety Notices including vortex-ring-state guidance',
 'objective':'Recognize the aerodynamic setup before a high-rate descent becomes an emergency.',
 'lessons':[
  ('1. Rotor wake recirculation','VRS develops when a powered rotor descends into its own disturbed wake under the relevant low-forward-speed/high-descent conditions. More collective can deepen the problem rather than arrest descent.'),
  ('2. Recognition','High descent rate, reduced control effectiveness, vibration/buffeting and power without expected arrest are warning concepts. Avoid waiting for a textbook-perfect symptom set.'),
  ('3. Prevention','Manage approach angle, groundspeed/airspeed, wind and descent rate. Be especially alert on steep approaches, downwind situations and confined areas.'),
  ('4. Recovery knowledge','Use the recovery method taught by the instructor and supported by current guidance/aircraft procedures. Ground training explains the aerodynamic objective: exit disturbed air and restore effective rotor flow.'),
  ('5. Scenario lab','Adjust forward speed, descent and power to see conceptual VRS risk increase/decrease. This is not a flight-dynamics simulator.')],
 'lab':'vrs'
},
{
 'key':'lowg','title':'Low-G, Mast Bumping & R22 Safety','acs':'I, IX','refs':'FAA-H-8083-21B hazards; FAA-S-ACS-15','r22':'R22 POH limitations/safety tips; Robinson low-G/mast-bumping Safety Notices',
 'objective':'Make the R22 low-G hazard understandable enough that the prohibited response is memorable for the right reason.',
 'lessons':[
  ('1. Rotor thrust and fuselage','In normal positive-G flight, rotor thrust and fuselage response are coupled. Unloading the rotor changes that relationship and can expose teetering-rotor helicopters to dangerous mast/rotor dynamics.'),
  ('2. Why abrupt pushovers are hazardous','An abrupt forward cyclic input can unload the rotor. The danger is not simply a momentary light feeling; it changes the forces that normally help control fuselage roll.'),
  ('3. Roll response','Robinson guidance emphasizes restoring positive G with gentle aft cyclic before attempting lateral correction if a low-G roll develops. Do not practice low-G maneuvers.'),
  ('4. Turbulence and speed','Avoid aggressive control inputs and respect limitations/cautions in turbulence/high wind. Prevention is the primary defense.'),
  ('5. Visual force lab','Use the force-vector visual to compare normal positive-G and unloaded conceptual states.')],
 'lab':'lowg'
},
{
 'key':'iimc','title':'IIMC, Spatial Disorientation & Night Risk','acs':'I, VIII, IX','refs':'FAA-H-8083-21B night/ADM; PHAK aeromedical; FAA-S-ACS-15','r22':'R22 POH kinds-of-operation/limitations and applicable equipment/supplements',
 'objective':'Teach early decisions that prevent a VFR helicopter pilot from becoming trapped without reliable outside visual reference.',
 'lessons':[
  ('1. The trap','Marginal conditions often deteriorate gradually. Continuing because the next landmark is \u201cprobably visible\u201d can remove landing/turnaround options one by one.'),
  ('2. Visual illusions','At night or in reduced visibility, false horizons, black-hole effects and vestibular illusions can conflict with instruments. Believing body sensations over reliable indications is dangerous.'),
  ('3. Prevention decisions','Set weather/personal minimums before departure, maintain escape routes, monitor trends and act while options remain. Landing or turning around early is a successful risk decision.'),
  ('4. Unexpected loss of reference','Aircraft control is the first priority. The exact response depends on training, equipment, environment and ATC availability; this app does not substitute for instrument instruction.'),
  ('5. Deteriorating-weather scenario','Progress through visibility/ceiling changes and choose continue, divert, land or turn around. The debrief focuses on how early each safe option was available.')],
 'lab':'iimc'
},
{
 'key':'ground','title':'Passenger, Ramp & Rotor Safety','acs':'II, III, X','refs':'FAA-H-8083-21B Ch. 8; FAA-S-ACS-15','r22':'R22 POH normal procedures; Robinson rotor/passenger/loose-object Safety Notices',
 'objective':'Make safe behavior around a running helicopter automatic before the student ever brings a passenger.',
 'lessons':[
  ('1. Rotor hazards','Main and tail rotors are difficult for untrained passengers to judge. Control approach/departure routes and never assume a passenger understands rotor danger.'),
  ('2. Loose objects and rotor wash','Secure hats, papers, bags, covers and equipment. Rotor wash can injure people and damage nearby aircraft/property.'),
  ('3. Passenger briefing','Cover approach/departure direction, crouching only as instructed, seat belts, doors, loose items, controls, emergency exits and when not to approach.'),
  ('4. Ramp awareness','Identify vehicles, people, fueling equipment, obstacles, slopes and other aircraft before start. Reassess as conditions change.'),
  ('5. Hazard board','Find unsafe passenger/ramp conditions in the interactive checklist before allowing engine start.')],
 'lab':'ground_safety'
},
{
 'key':'annunciators','title':'R22 Annunciator & Abnormal Indication Lab','acs':'I, IX','refs':'FAA-S-ACS-15; FAA-H-8083-21B systems/emergencies','r22':'R22 POH \xa7\xa73,7 and applicable Safety Notices',
 'objective':'Recognize an indication, state what it means, and go to the correct POH procedure instead of guessing from lamp color.',
 'lessons':[
  ('1. Recognition before action','A warning/caution is a cue to identify the system and apply the approved procedure. Similar-looking lights do not imply similar actions.'),
  ('2. LOW RPM','Connect the horn/light to actual rotor RPM and power condition. Rotor RPM preservation is time critical; the simulator reinforces E/R tach cross-checking.'),
  ('3. CLUTCH and drivetrain','Understand normal actuator-light behavior versus abnormal illumination and why prolonged/unexpected indications require the POH response.'),
  ('4. Oil/ALT/fuel','Relate each indication to corroborating gauges/system state. Avoid treating a single light as the entire diagnosis.'),
  ('5. Chip/temp indications','MR CHIP, TR CHIP and MR TEMP concern drivetrain condition. Learn the approved response and avoid inventing troubleshooting in flight.'),
  ('6. Random indication drill','The lab selects an indication. Identify it and choose the source section/action category; then reveal the POH-reference reminder.')],
 'lab':'annunciator'
},
{
 'key':'oral','title':'Scenario Oral & Checkride Integration','acs':'All applicable Areas of Operation','refs':'FAA-S-ACS-15; ACS Companion Guide; FAA handbooks/AIM','r22':'Current approved R22 POH/RFM, supplements, Safety Notices and aircraft records',
 'objective':'Answer like a pilot planning a real R22 flight, not like a flash-card deck.',
 'lessons':[
  ('1. Scenario method','Start with a proposed flight and make every answer affect the next question. Explain where information came from and distinguish a regulation, POH limitation, performance result and personal minimum.'),
  ('2. Aircraft legality and documents','Determine required pilot/aircraft documents, inspections and limitations using current records and regulations rather than memorized acronyms alone.'),
  ('3. Weather and risk','Explain the weather picture, not just METAR decoding. State hazards, trends, alternatives and decision triggers.'),
  ('4. R22 systems and performance','Be able to trace systems, explain indications, calculate loading/performance and find limitations in the POH.'),
  ('5. Emergencies','Prioritize aircraft control, recognition and approved immediate actions. Know where the complete procedure is found.'),
  ('6. Debrief','Every missed item is assigned back to the relevant Academy course, POH section or FAA topic so remediation is specific.')],
 'lab':'oral_scenario'
},
{
 'key':'minimums','title':'Personal Minimums & ADM Builder','acs':'I, VI, VIII, IX','refs':'FAA-S-ACS-15; FAA Risk Management Handbook; Aviation Instructor Handbook personal-minimums material','r22':'R22 POH limitations remain hard limits; personal minimums must never exceed them',
 'objective':'Create conservative, instructor-reviewed decision triggers and use them consistently in scenarios.',
 'lessons':[
  ('1. Limits versus minimums','An aircraft limitation is not a personal target. A new pilot may need substantially more conservative limits based on training, recency and conditions.'),
  ('2. PAVE','Pilot, Aircraft, enVironment and External pressures create interacting risk. Record concrete hazards rather than simply checking the acronym.'),
  ('3. 5P review','Reassess Plan, Plane, Pilot, Passengers and Programming at logical decision points, not only before departure.'),
  ('4. External pressure','Schedule, passengers and desire to complete a flight can distort judgment. Decide cancellation/diversion triggers before the pressure appears.'),
  ('5. Instructor review','Personal minimums should evolve with training and experience. The builder stores training values for discussion; it does not certify a pilot for conditions.')],
 'lab':'minimums'
},
{
 'key':'currency','title':'FAA & Robinson Publication Currency','acs':'I, II','refs':'FAA ACS/AIM/handbook publication pages','r22':'Robinson R22 Current Status, POH revisions, Safety Notices, Service Bulletins/Letters as applicable',
 'objective':'Teach students to verify that the material they are using is current instead of assuming a saved PDF never changes.',
 'lessons':[
  ('1. Source hierarchy','Use the current approved aircraft POH/RFM and supplements for aircraft-specific limitations/procedures; FAA regulations/ACS/AIM/handbooks govern broader certification and NAS knowledge.'),
  ('2. Robinson Current Status','Robinson maintains a current-status/publications page listing R22 POH status, checklists, Safety Notices and maintenance/service publications. Administrators can compare installed training references against it when connected.'),
  ('3. FAA currency','FAA ACS, AIM, chart products and handbooks have publication/revision dates. A course should record the source/version used for each training objective.'),
  ('4. Change control','A detected web update should create an administrator review item-not silently rewrite training content. Aircraft-specific changes require deliberate validation before course publication.'),
  ('5. Student habit','Before a checkride or flight, know where to verify current regulations, NOTAMs, chart currency and aircraft documents rather than relying on an old screenshot.')],
 'lab':'currency'
}
]
COURSE_MAP={c['key']:c for c in ACADEMY_COURSES}

# v74 source-current integration courses. These supplement the existing R22 Academy rather than replacing it.
ACADEMY_COURSES.extend([
{'key':'weather2026','title':'2026 FAA Weather Mastery - Helicopter VFR','acs':'PH.I.C','refs':'FAA-S-ACS-15 PH.I.C; FAA-H-8083-28B Aviation Weather Handbook (2026); AIM/current weather products','r22':'Apply weather decisions to R22 performance, carb-ice exposure, wind/gust limits and personal minimums using current POH/RFM',
'objective':'Meet the ACS weather-information task by obtaining, interpreting, correlating and making a defensible R22 go/no-go or divert decision.',
'lessons':[('1. Weather source strategy','Start with authoritative current sources and understand what each product can and cannot tell you. Build a departure, enroute and destination picture rather than decoding isolated reports.'),('2. METAR/SPECI/PIREP','Interpret observations and pilot reports, then translate them into helicopter consequences: visibility, ceiling, wind/gusts, turbulence, obscuration and landing-site conditions.'),('3. Forecast products','Use TAF, GFA, winds/temperatures aloft and convective guidance as a forecast system. Identify uncertainty and timing rather than treating a forecast as a guarantee.'),('4. Hazards','Study stability, wind/windshear/mountain wave, moisture, fronts, clouds, turbulence, thunderstorms/microbursts, icing/freezing level, fog, frost and visibility restrictions required by PH.I.C.K3.'),('5. R22 correlation','Combine density altitude, wind/gusts, carburetor-ice considerations, performance margin and route/landing options. Aircraft limitations come from the current R22 POH/RFM and applicable directives.'),('6. ACS decision scenario','Obtain or use instructor-provided weather, analyze at least three relevant conditions, state personal minimums and make a go/no-go/continue/divert decision with reasons.')], 'lab':'dispatch'},
{'key':'charts2026','title':'2026 FAA Chart Literacy - Sectional, TAC & Helicopter Route','acs':'PH.I.D; PH.I.E; PH.VII','refs':'FAA Aeronautical Chart Users Guide effective 9 Jul 2026; FAA-S-ACS-15; current Chart Supplement/VFR products','r22':'Apply chart information to R22 route, altitude, autorotation options, performance, frequencies and helicopter-route decisions',
'objective':'Read actual FAA chart symbology and apply it to an R22 cross-country instead of memorizing isolated symbols.',
'lessons':[('1. Chart currency and scale','Identify chart product, effective dates, scale and coverage before planning. A cached training chart is not proof that a chart is current for flight.'),('2. Airports and heliports','Locate airports/heliports and decode operational information using the chart plus current Chart Supplement when detail is not carried on the chart.'),('3. Airspace','Identify Class B/C/D/E/G depictions, special use airspace, TFR/SFRA considerations and communication/equipment implications.'),('4. Navigation and frequencies','Use NAVAIDs, checkpoints, frequencies and services as planning aids while understanding their limitations.'),('5. Terrain and obstacles','Read terrain, elevations and obstruction information, then choose helicopter altitudes/routes with terrain, wire/obstacle and autorotation considerations.'),('6. Helicopter route application','Use the actual helicopter-route product where applicable; distinguish FAA chart symbols from training overlays. Plan a route and explain every major chart feature affecting the flight.')], 'lab':'navigation_charts'}])
COURSE_MAP={c['key']:c for c in ACADEMY_COURSES}
