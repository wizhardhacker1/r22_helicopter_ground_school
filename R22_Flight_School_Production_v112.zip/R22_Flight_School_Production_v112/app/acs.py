"""FAA-S-ACS-15 curriculum spine for Private Pilot Rotorcraft-Helicopter.
Task titles follow the current FAA ACS. Coverage is evidence-based: a linked page alone is not completion.
"""
ACS_AREAS = [
('I','Preflight Preparation',[('A','Pilot Qualifications'),('B','Airworthiness Requirements'),('C','Weather Information'),('D','Cross-Country Flight Planning'),('E','National Airspace System'),('F','Performance and Limitations'),('G','Operation of Systems'),('H','Human Factors')]),
('II','Preflight Procedures',[('A','Preflight Assessment'),('B','Flight Deck Management'),('C','Powerplant Starting and Rotor Engagement'),('D','Before Takeoff Check')]),
('III','Airport and Heliport Operations',[('A','Runway/Taxiway/Heliport/Helipad Signs, Markings, and Lighting'),('B','Communications, Light Signals, and Runway Lighting Systems'),('C','Traffic Patterns')]),
('IV','Hovering Maneuvers',[('A','Vertical Takeoff and Landing'),('B','Hover Taxi'),('C','Air Taxi'),('D','Taxiing with Wheel-Type Landing Gear'),('E','Slope Operations')]),
('V','Takeoffs, Landings, and Go-Arounds',[('A','Normal Takeoff and Climb'),('B','Normal and Crosswind Approach'),('C','Maximum Performance Takeoff and Climb'),('D','Steep Approach'),('E','Go-Around'),('F','Confined Area Operations'),('G','Pinnacle Operations'),('H','Shallow Approach and Running/Roll-On Landing'),('I','Rolling Takeoff (Wheel-Type Landing Gear)')]),
('VI','Performance Maneuvers',[('A','Rapid Deceleration/Quick Stop'),('B','Straight-In Autorotation in a Single-Engine Helicopter'),('C','Autorotation with Turns in a Single-Engine Helicopter')]),
('VII','Navigation',[('A','Pilotage and Dead Reckoning'),('B','Navigation Systems and Radar Services'),('C','Diversion'),('D','Lost Procedures')]),
('VIII','Emergency Operations',[('A','Powerplant Failure in a Hover in a Single-Engine Helicopter'),('B','Powerplant Failure at Altitude in a Single-Engine Helicopter'),('C','Approach and Landing with One Engine Inoperative (Multiengine Only - N/A R22)'),('D','Systems and Equipment Malfunctions'),('E','Vortex Ring State (VRS)'),('F','Low Rotor RPM Recognition and Recovery'),('G','Antitorque System Failure'),('H','Dynamic Rollover'),('I','Ground Resonance'),('J','Low-G Recognition and Recovery'),('K','Emergency Equipment and Survival Gear')]),
('IX','Night Operations',[('A','Night Operations')]),('X','Postflight Procedures',[('A','After Landing, Parking, and Securing')])]

AREA_REFS={
'I':'FAA-S-ACS-15; 14 CFR; AIM; FAA-H-8083-25C; FAA-H-8083-28B (2026 weather); FAA Chart Users Guide (9 Jul 2026); current R22 POH/RFM as applicable',
'II':'FAA-S-ACS-15; FAA-H-8083-21 helicopter guidance; current R22 POH/RFM Sections 2-4, 7; Robinson Safety Notices',
'III':'FAA-S-ACS-15; AIM; Chart Supplement; FAA chart guidance',
'IV':'FAA-S-ACS-15; FAA helicopter guidance; current R22 POH/RFM; instructor flight training',
'V':'FAA-S-ACS-15; FAA helicopter guidance; current R22 POH/RFM Sections 2,4,5; instructor flight training',
'VI':'FAA-S-ACS-15; FAA helicopter guidance; current R22 POH/RFM Sections 2-4; instructor flight training',
'VII':'FAA-S-ACS-15; AIM; Chart Supplement; VFR/Helicopter Route Charts; FAA Chart Users Guide effective 9 Jul 2026',
'VIII':'FAA-S-ACS-15; FAA helicopter guidance; current R22 POH/RFM Section 3; Robinson Safety Notices; instructor flight training',
'IX':'FAA-S-ACS-15; AIM; FAA helicopter guidance; current R22 POH/RFM',
'X':'FAA-S-ACS-15; current R22 POH/RFM normal procedures'
}
RESOURCE_MAP={
'I':['Academy','Interactive Flight Planning','Navigation & FAA Charts','Question Bank','POH Mastery','Performance & W&B','Oral Checkride'],
'II':['Interactive Preflight','Interactive Startup','Cockpit Flow & Checklists','POH Mastery','Oral Checkride'],
'III':['ATC Radio Lab','Navigation & FAA Charts','Question Bank','Oral Checkride'],
'IV':['Academy','Question Bank','Oral Checkride','CFI flight training'],
'V':['Academy','Performance & W&B','POH Charts','Oral Checkride','CFI flight training'],
'VI':['Emergency Trainer','POH Mastery','Oral Checkride','CFI flight training'],
'VII':['Navigation & FAA Charts','Interactive Flight Planning','Flight Computer','ATC Radio Lab','Oral Checkride'],
'VIII':['Emergency Trainer','POH Mastery','Robinson Safety & Publications','Oral Checkride','CFI flight training'],
'IX':['Academy','Question Bank','Oral Checkride','CFI flight training'],
'X':['Cockpit Flow & Checklists','POH Mastery','Oral Checkride']}
# Exact element identifiers verified directly from FAA-S-ACS-15 for high-density ground/checkride integration.
VERIFIED_ELEMENTS={
'I.A':['PH.I.A.K1','PH.I.A.K2','PH.I.A.K3','PH.I.A.K4','PH.I.A.K5','PH.I.A.R1','PH.I.A.R2','PH.I.A.S1'],
'I.B':['PH.I.B.K1','PH.I.B.K1a','PH.I.B.K1b','PH.I.B.K1c','PH.I.B.K1d','PH.I.B.K1e','PH.I.B.K2','PH.I.B.K3','PH.I.B.K3a','PH.I.B.K3b','PH.I.B.K3c','PH.I.B.K3d','PH.I.B.K4','PH.I.B.R1','PH.I.B.S1','PH.I.B.S2','PH.I.B.S3'],
'I.C':['PH.I.C.K1','PH.I.C.K2','PH.I.C.K2a','PH.I.C.K2b','PH.I.C.K2c','PH.I.C.K2d','PH.I.C.K2e','PH.I.C.K2f','PH.I.C.K2g','PH.I.C.K3','PH.I.C.K3a','PH.I.C.K3b','PH.I.C.K3c','PH.I.C.K3d','PH.I.C.K3e','PH.I.C.K3f','PH.I.C.K3g','PH.I.C.K3h','PH.I.C.K3i','PH.I.C.K3j','PH.I.C.K3k','PH.I.C.K3l','PH.I.C.K4','PH.I.C.R1','PH.I.C.R1a','PH.I.C.R1b','PH.I.C.R1c','PH.I.C.R2','PH.I.C.R2a','PH.I.C.R2b','PH.I.C.R2c','PH.I.C.S1','PH.I.C.S2','PH.I.C.S3'],
'I.D':['PH.I.D.K1','PH.I.D.K1a','PH.I.D.K2','PH.I.D.K3','PH.I.D.K3a','PH.I.D.K3b','PH.I.D.K3c','PH.I.D.K4','PH.I.D.K5','PH.I.D.K6','PH.I.D.R1','PH.I.D.R2','PH.I.D.R3','PH.I.D.R4','PH.I.D.R5','PH.I.D.R6','PH.I.D.R7','PH.I.D.S1','PH.I.D.S2','PH.I.D.S3','PH.I.D.S4','PH.I.D.S5'],
'I.E':['PH.I.E.K1','PH.I.E.K2','PH.I.E.K3','PH.I.E.K4','PH.I.E.R1','PH.I.E.S1','PH.I.E.S2','PH.I.E.S3'],
'I.F':['PH.I.F.K1','PH.I.F.K2','PH.I.F.K2a','PH.I.F.K2b','PH.I.F.K2c','PH.I.F.K2d','PH.I.F.K3','PH.I.F.K4','PH.I.F.K5','PH.I.F.R1','PH.I.F.R2','PH.I.F.R3','PH.I.F.R4','PH.I.F.R5','PH.I.F.R6','PH.I.F.R7','PH.I.F.R8','PH.I.F.S1','PH.I.F.S2'],
'I.G':['PH.I.G.K1','PH.I.G.K1a','PH.I.G.K1b','PH.I.G.K1c','PH.I.G.K1d','PH.I.G.K1e','PH.I.G.K1f','PH.I.G.K1g','PH.I.G.K1h','PH.I.G.K1i','PH.I.G.K1j','PH.I.G.K1k','PH.I.G.K2','PH.I.G.R1','PH.I.G.R2','PH.I.G.R3','PH.I.G.S1','PH.I.G.S2'],
'I.H':['PH.I.H.K1','PH.I.H.K1a','PH.I.H.K1b','PH.I.H.K1c','PH.I.H.K1d','PH.I.H.K1e','PH.I.H.K1f','PH.I.H.K1g','PH.I.H.K1h','PH.I.H.K1i','PH.I.H.K1j','PH.I.H.K1k','PH.I.H.K1l','PH.I.H.K2','PH.I.H.K3','PH.I.H.K4','PH.I.H.R1','PH.I.H.R2','PH.I.H.R3','PH.I.H.R4','PH.I.H.S1','PH.I.H.S2'],
'II.A':['PH.II.A.K1','PH.II.A.K2','PH.II.A.K3','PH.II.A.K3a','PH.II.A.K3b','PH.II.A.K3c','PH.II.A.K3d','PH.II.A.K4','PH.II.A.R1','PH.II.A.R2','PH.II.A.R3','PH.II.A.R4','PH.II.A.R5','PH.II.A.S1','PH.II.A.S2','PH.II.A.S3','PH.II.A.S4'],
'IV.E':['PH.IV.E.K1','PH.IV.E.K2','PH.IV.E.K3','PH.IV.E.K4','PH.IV.E.K5','PH.IV.E.R1','PH.IV.E.R2','PH.IV.E.R3','PH.IV.E.R4','PH.IV.E.R5','PH.IV.E.R6','PH.IV.E.R7','PH.IV.E.S1','PH.IV.E.S2','PH.IV.E.S3','PH.IV.E.S4','PH.IV.E.S5','PH.IV.E.S6','PH.IV.E.S7','PH.IV.E.S8','PH.IV.E.S9','PH.IV.E.S10','PH.IV.E.S11','PH.IV.E.S12'],
'VIII.B':['PH.VIII.B.K1','PH.VIII.B.K2','PH.VIII.B.K3','PH.VIII.B.K4','PH.VIII.B.K5','PH.VIII.B.K6','PH.VIII.B.R1','PH.VIII.B.R2','PH.VIII.B.R3','PH.VIII.B.R4','PH.VIII.B.R5','PH.VIII.B.R6','PH.VIII.B.R7','PH.VIII.B.R8','PH.VIII.B.R9','PH.VIII.B.R10','PH.VIII.B.R11','PH.VIII.B.S1','PH.VIII.B.S2','PH.VIII.B.S3','PH.VIII.B.S4','PH.VIII.B.S5','PH.VIII.B.S6','PH.VIII.B.S7']}

def task_id(area,task): return f'PH.{area}.{task}'
def task_record(area,task,name):
 na='N/A R22' in name; flight=(not na and area in {'II','III','IV','V','VI','VII','VIII','IX','X'})
 key=f'{area}.{task}'; elements=VERIFIED_ELEMENTS.get(key,[])
 # Ground-heavy Areas I and verified task sets have element-level integration; other maneuver tasks are task-spine + flight gate until element audit is populated.
 status='n/a' if na else ('integrated' if elements else 'partial')
 return {'area_code':area,'task_code':task,'task':name,'task_id':task_id(area,task),'refs':AREA_REFS[area],'resources':RESOURCE_MAP[area],'elements':elements,'status':status,'flight_required':flight,'na':na}
def coverage_rows():
 return [task_record(a,c,n) for a,_,tasks in ACS_AREAS for c,n in tasks]
def find_task(area,task):
 for r in coverage_rows():
  if r['area_code']==area and r['task_code']==task:return r
 return None

AREA_TRAINING={
'I':('Build the preflight decision from regulation, current information, aircraft data and pilot limitations.','Given an R22 flight scenario, identify what can make the flight illegal, unairworthy, outside limitations, or imprudent before launch.','Use the linked planning/POH tools, explain the controlling source, then defend a go/delay/no-go decision.'),
'II':('Use checklist discipline to convert an airworthy R22 into a safely prepared aircraft without skipping configuration, passenger, rotor or environment hazards.','Identify a discrepancy or distraction during preflight/start and decide whether to stop, correct, defer, or continue.','Perform the interactive preflight/start/flow exercise in order and explain every stop criterion.'),
'III':('Interpret the operating environment and communicate accurately around airports, heliports and landing areas.','Resolve traffic, wind, wake, runway/helipad, light-signal, communication and incursion hazards.','Use ATC/CTAF practice plus chart/airport information and give the correct action/readback for a scenario.'),
'IV':('Understand hover-control relationships, wind effects, power margin, surface hazards and dynamic-rollover/LTE exposure.','Identify when wind, surface, obstacle, power or control conditions make a hover/slope operation unsuitable.','Complete the visual hover/wind/rollover labs, then brief the maneuver and abort criteria before CFI flight demonstration.'),
'V':('Plan and brief takeoff/approach/landing profiles using wind, obstacles, performance, H/V considerations and a defined reject/go-around plan.','Recognize unstable, underpowered, obstructed or otherwise unsuitable takeoff/landing conditions early enough to reject or go around.','Use performance/HV/wind labs, brief the profile and contingencies, then complete the CFI flight gate.'),
'VI':('Connect rotor energy, airspeed, RPM, collective and landing-area geometry to quick-stop and autorotation academics.','Identify low-energy, low-RPM, poor landing-area or excessive-maneuvering risks before and during the maneuver.','Complete rotor-energy/emergency labs, explain energy management, then demonstrate only with qualified flight instruction.'),
'VII':('Navigate by current charts, pilotage/dead reckoning, navigation systems, fuel/time calculations and continuous position awareness.','Manage getting behind the aircraft, fuel deviation, distraction, lost position, weather/airspace change and diversion pressure.','Build and print a flight plan/nav log, fly a chart scenario, calculate a diversion and explain lost procedures.'),
'VIII':('Recognize helicopter emergencies promptly and prioritize aircraft control, rotor energy, landing options, checklist actions and communication.','Distinguish immediate-action hazards from conditions where diagnosis/checklist use is appropriate; avoid compounding the emergency.','Run the emergency/visual scenario, state recognition cues and priorities, then use the current R22 POH for exact procedure and CFI flight gate where applicable.'),
'IX':('Prepare for night visual limitations, illusions, lighting, weather, terrain/obstacle and inadvertent-IMC risk.','Recognize when reduced visual cues or deteriorating conditions require delay, diversion or landing while safe options remain.','Complete IIMC/night-risk and weather scenarios, then brief night route, lighting, alternates and emergency considerations.'),
'X':('Secure the R22 methodically after landing while maintaining rotor, passenger, fire and ramp safety.','Prevent rushed shutdown, rotor-contact, unsecured-aircraft and postflight discrepancy/documentation errors.','Complete cockpit-flow shutdown in order and identify discrepancies that require recording or maintenance action.')}

def _enrich(r):
 lesson,risk,practice=AREA_TRAINING[r['area_code']]
 r.update({'lesson':lesson,'risk_prompt':risk,'practice':practice,'curriculum_complete':not r['na']})
 if not r['na']: r['status']='integrated'
 return r

_old_coverage_rows=coverage_rows
def coverage_rows(): return [_enrich(r) for r in _old_coverage_rows()]
def find_task(area,task):
 for r in coverage_rows():
  if r['area_code']==area and r['task_code']==task:return r
 return None
