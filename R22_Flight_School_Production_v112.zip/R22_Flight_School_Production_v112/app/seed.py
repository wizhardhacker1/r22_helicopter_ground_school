from .models import Question,User
from .auth import hash_password
from .builtin_bank import PPL,R22_EXTRA,IFR
R22=[
('Limitations','Beta II maximum gross weight?','1300 lb','1370 lb','1450 lb','B','Alpha, Beta and Beta II maximum gross weight is 1370 lb.','POH \xa72 Weight Limits'),
('Limitations','Minimum R22 gross weight?','820 lb','920 lb','1020 lb','B','Minimum gross weight is 920 lb.','POH \xa72 Weight Limits'),
('Limitations','Maximum per seat including its baggage compartment?','200 lb','220 lb','240 lb','C','The limit is 240 lb.','POH \xa72 Weight Limits'),
('Limitations','Maximum in either baggage compartment?','25 lb','50 lb','75 lb','B','Each baggage compartment is limited to 50 lb.','POH \xa72 Weight Limits'),
('Limitations','Maximum operating density altitude?','10,000 ft','12,000 ft','14,000 ft','C','Maximum operating density altitude is 14,000 ft.','POH \xa72 Flight/Maneuver Limits'),
('Limitations','VNE up to 3,000 ft density altitude?','90 KIAS','102 KIAS','110 KIAS','B','VNE is 102 KIAS up to 3,000 ft density altitude.','POH \xa72 Airspeed Limits'),
('Rotor RPM','Power-on maximum rotor RPM?','101%','104%','110%','B','Power-on maximum is 104%.','POH \xa72 Rotor Speed Limits'),
('Rotor RPM','Power-off rotor RPM range?','90-110%','97-104%','101-104%','A','Power-off limits are 90% minimum and 110% maximum.','POH \xa72 Rotor Speed Limits'),
('Engine','Beta II engine model?','O-320-A2B','O-360-J2A','IO-540','B','Beta II uses the Lycoming O-360-J2A.','POH \xa71 Descriptive Data'),
('Fuel','Usable bladder-tank fuel, main plus auxiliary?','26.3 gal','28.0 gal','29.7 gal','A','Usable capacity is 16.9 main + 9.4 aux = 26.3 US gal.','POH \xa72 Fuel Capacity'),
('Operations','Solo flight is permitted from which seat?','Left only','Either','Right only','C','Solo flight is from the right seat only.','POH \xa72 Flight/Maneuver Limits'),
('Operations','Known icing flight is:','Approved','Prohibited','Approved below 3,000 ft','B','Flight in known icing conditions is prohibited.','POH \xa72 Flight/Maneuver Limits'),
('Aerodynamics','First control response to a low-G condition?','Gentle aft cyclic','Lateral cyclic','Full down collective','A','Apply gentle aft cyclic to reload the rotor before lateral cyclic if a roll develops.','POH \xa72 Flight/Maneuver Limits'),
('Emergency','On a power failure, the immediate action is to:','Raise collective','Lower collective to enter autorotation','Turn governor off','B','Immediately lower collective to enter autorotation.','POH \xa73 Power Failure'),
('Emergency','Approximate glide airspeed after power failure above 500 ft AGL?','45 KIAS','65 KIAS','85 KIAS','B','Establish approximately 65 KIAS.','POH \xa73 Power Failure Above 500 ft'),
('Emergency','Maximum-glide configuration airspeed is approximately:','55 KIAS','65 KIAS','75 KIAS','C','Maximum glide distance uses approximately 75 KIAS.','POH \xa73 Maximum Glide'),
('Emergency','Loss of tail rotor thrust in forward flight calls first for:','Immediate autorotation','Full right pedal','Climb','A','Immediately enter autorotation.','POH \xa73 Tail Rotor Thrust'),
('Emergency','Electrical fire in flight: first action?','Battery and alternator OFF','Mixture rich','Governor OFF','A','Battery and alternator switches OFF.','POH \xa73 Electrical Fire'),
('Normal Procedures','Recommended takeoff and climb airspeed?','53 KIAS','60 KIAS','83 KIAS','B','Recommended takeoff and climb is 60 KIAS.','POH \xa74 Recommended Airspeeds'),
('Normal Procedures','Maximum-rate-of-climb speed VY?','53 KIAS','60 KIAS','83 KIAS','A','VY is 53 KIAS.','POH \xa74 Recommended Airspeeds'),
('Normal Procedures','Recommended maximum-range airspeed?','60 KIAS','70 KIAS','83 KIAS','C','Maximum range is 83 KIAS, subject to VNE limitations.','POH \xa74 Recommended Airspeeds'),
('Weight & Balance','Longitudinal arm for right-seat pilot/baggage on later aircraft?','66.3 in','78.0 in','108.6 in','B','Right-seat pilot and baggage use 78.0 inches (early-seat exception in POH).','POH \xa76 Loading Instructions'),
('Weight & Balance','Main usable fuel longitudinal arm?','103.8 in','106.9 in','108.6 in','C','Main fuel uses 108.6 inches.','POH \xa76 Loading Instructions'),
('Weight & Balance','Aux usable fuel longitudinal arm?','103.8 in','106.9 in','108.6 in','A','Aux fuel uses 103.8 inches.','POH \xa76 Loading Instructions'),]

def seed(db):
    if not db.query(User).filter(User.username=='admin').first():
        db.add(User(username='admin',full_name='Administrator',role='admin',password_hash=hash_password('ChangeMe123!'),must_change_password=True))
        db.flush()
    # Retire the old numbered synthetic pool on upgraded installs. It was useful for load testing, not study quality.
    db.query(Question).filter(Question.source_kind=='synthetic_training').update({Question.active:False},synchronize_session=False)
    existing={p for (p,) in db.query(Question.prompt).all()}
    rows=[]
    for area,p,a,b,c,correct,ex,ref in R22:
        rows.append(dict(track='R22',area=area,prompt=p,a=a,b=b,c=c,correct=correct,explanation=ex,reference=ref,difficulty=1,source_kind='POH_grounded'))
    rows += R22_EXTRA + PPL + IFR
    for x in rows:
        if x['prompt'] in existing: continue
        db.add(Question(**x)); existing.add(x['prompt'])
    db.commit()
