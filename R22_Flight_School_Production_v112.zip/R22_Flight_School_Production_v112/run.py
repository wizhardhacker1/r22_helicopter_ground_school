import os
from dotenv import load_dotenv
load_dotenv()
import uvicorn
from app.tls_support import ensure_tls, paths

if __name__=='__main__':
    host=os.getenv('HOST','0.0.0.0')
    port=int(os.getenv('PORT','8086'))
    https=os.getenv('HTTPS_ENABLED','true').lower()=='true'
    kwargs={}
    if https:
        ensure_tls()
        p=paths()
        kwargs.update(ssl_certfile=str(p['server_cert']),ssl_keyfile=str(p['server_key']))
    uvicorn.run('app.main:app',host=host,port=port,**kwargs)
