# R22 Flight School v51 Release Verification

- Navigation: nested groups persist active group and sidebar scroll position across page navigation.
- Navigation cleanup: Academy courses are not duplicated as sidebar links; dedicated tools remain direct links.
- Academy: 18 courses remain course pages with ordered lessons, application/recall work, practicum, and completion gate.
- Live ATC: optional in-app external LiveATC player wrapper for KLAX Approach East; no proxying/rebroadcasting; offline radio curriculum remains required/available without Internet.
- Regression suite: 102 tests passed.
- Python compile: passed.
- Static JavaScript syntax: passed.
- Jinja templates: 34 parsed successfully.
- Release cleanliness: no runtime/test DB, __pycache__, .pytest_cache, .testdata, or .pyc files in archive.
