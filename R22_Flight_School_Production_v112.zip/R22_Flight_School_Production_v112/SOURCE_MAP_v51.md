# v51 Source Map

Primary curriculum authorities used for the v51 Academy structure:

- FAA-S-ACS-15 - Private Pilot for Rotorcraft Category Helicopter Rating Airman Certification Standards.
- FAA-H-8083-21B - Helicopter Flying Handbook: aerodynamics, controls, systems, RFM use, weight and balance, performance, ground preparation, maneuvers, emergencies/hazards, night operations, ADM.
- FAA-H-8083-25C - Pilot's Handbook of Aeronautical Knowledge for weather, NAS, navigation, aeromedical and general aeronautical knowledge.
- FAA Aeronautical Information Manual, especially communications/ATC operating practices.
- FAA SAFO 16016 - Helicopter Stabilized Hover Checks Before Departure.
- FAA Risk Management Handbook / Aviation Instructor Handbook personal-minimums and risk-management concepts.
- Current approved Robinson R22 POH/RFM and applicable supplements for aircraft-specific limitations, procedures, performance and systems.
- Robinson R22 Safety Notices and Robinson R22 Current Status/publications page for aircraft-specific safety/currency awareness.

Source rule: FAA material establishes certification/NAS/general helicopter knowledge. R22-specific operating values and procedures defer to the current approved R22 POH/RFM and applicable Robinson material. Connected publication checks do not silently rewrite course content; changes require administrator/instructor review.
