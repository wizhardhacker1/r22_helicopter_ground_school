@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\INSTALL_WINDOWS.ps1"
if errorlevel 1 pause
