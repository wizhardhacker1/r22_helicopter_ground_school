# R22 Flight School Production v54 - Release Verification

## Fixes in v54
- Removed the simulated `faa_sectional_training.svg` chart entirely.
- Navigation lab now displays only official FAA Los Angeles Sectional / Los Angeles Helicopter Route Chart PDFs cached locally.
- Added one-click FAA Chart Package install/refresh workflow using the official FAA Sep 03 2026 PDF endpoints; downloaded files persist under `R22_DATA_DIR/faa_charts` for offline use.
- If the real chart package is absent, the UI explicitly refuses to substitute a fake map.
- LiveATC remains an external connected-only link; no iframe embedding.
- Removed v53's fixed synthetic ATC WAV assets.
- Added separate controller/pilot local voice selection using installed system voices, plus controller-only, pilot-only, full exchange, slower replay, stop, and transcript controls.

## Validation
- pytest: 106 passed
- Python compileall: passed
- JavaScript `node --check`: passed for all app/static/*.js
- Jinja parse: 34/34 templates passed
- fake FAA training SVG references: 0
- old v53 cache/static references: 0
- fixed ATC WAV references: 0

## FAA chart source
Official FAA Digital VFR products, Sep 03 2026 edition. The app downloads the official Los Angeles Sectional and Los Angeles Helicopter Route Chart PDFs while connected once, then serves those local files offline. Current chart status must still be verified for operational flight planning.
