# R22 Flight School - Regulatory Ground Curriculum Audit (v75)

Audit baseline: 2026-10-04.

## Claim boundary
The application is designed to cover 100% of the applicable regulatory **ground-training subject areas** for a Private Pilot Rotorcraft-Helicopter curriculum and to index every FAA-S-ACS-15 task. It is **not itself an FAA-approved Part 141 school or approved TCO**. FAA approval requires certification of the school and approval of its course by the FAA.

## Regulatory release gates
- 14 CFR 61.105 applicable helicopter aeronautical-knowledge areas: mapped.
- Part 141 Appendix B rotorcraft ground minimum: 35.0 planned hours.
- 14 CFR 141.55 syllabus structure: objectives, standards, planned time and stage checks represented.
- FAA-S-ACS-15 Areas I-X: all 49 tasks indexed; element-level status remains explicit rather than fabricated.
- 14 CFR 61.107 helicopter areas of operation: mapped as CFI/DPE flight gates.
- 14 CFR 61.109(c) aeronautical experience: displayed as logbook/eligibility gates.
- R22/SFAR 73: separate Robinson-specific knowledge/endorsement gate.
- Stage checks/end-of-course assessment: three-stage structure with 80% internal standard and remediation.

## Source baseline
FAA-S-ACS-15; 14 CFR parts 61, 91, 141; AIM; FAA Helicopter Flying Handbook; FAA Aviation Weather Handbook; FAA Aeronautical Chart Users Guide; current Robinson R22 POH/RFM and current Robinson publications/safety material.
