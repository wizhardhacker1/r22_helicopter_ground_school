@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy\TRUST_CA_WINDOWS.ps1"
if errorlevel 1 pause
