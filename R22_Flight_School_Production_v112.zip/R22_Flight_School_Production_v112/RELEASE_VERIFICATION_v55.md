# R22 Flight School v55 Release Verification

## Chart lab correction
- Removed dependency on the browser PDF iframe for the interactive FAA chart canvas.
- Official FAA GeoTIFF sources are used for both Los Angeles Sectional and Los Angeles Helicopter Route Chart.
- Install/refresh validates the FAA ZIP, extracts the GeoTIFF, verifies georeferencing, crops the KLGB/Long Beach training area, writes a local PNG, and validates the PNG signature/size.
- The chart lab displays the resulting real FAA raster directly and supports pan, wheel zoom, +/- zoom, and reset.
- Offline status is based on the validated rendered chart image, not merely file existence.
- No synthetic FAA-style map is used.

## Validation
- pytest: 108 passed
- Python compileall: passed
- JavaScript node --check: passed
- Jinja parse: 34/34 passed
- ZIP integrity: passed

## FAA cycle configured
- Current chart cycle: Sep 03 2026
- Next chart cycle: Oct 29 2026
- Operational flight planning still requires checking chart currency and NOTAMs.
