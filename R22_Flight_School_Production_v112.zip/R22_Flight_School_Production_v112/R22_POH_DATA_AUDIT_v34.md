# R22 Flight School v34 - POH Data Audit

Source of authority: bundled user-supplied FAA-approved Robinson R22 POH/RFM, revision through 22 Feb 2024. R22-specific values below were checked against that file before release. Generic helicopter values are not substituted for these items.

## Section 2 limitations checked
- VNE: 102 KIAS through 3,000 ft density altitude; above 3,000 ft use the applicable POH placard schedule.
- Rotor RPM: power-on 101-104% (97-104% permitted only for the stated O-320/tachometer configuration); power-off 90-110%.
- Engine RPM: max continuous 104% / 2652 RPM; max transient 106% / 2700 RPM.
- CHT max 500 degF / 260 degC; oil temp max 245 degF / 118 degC.
- Oil pressure: 25 psi minimum idle; 55-95 psi flight; 115 psi max start/warm-up. Earlier-gauge marking caveat remains a POH/configuration issue.
- Oil quantity minimum for takeoff: 4 qt.
- Gross weight: Standard/HP 1300 lb; Alpha/Beta/Beta II 1370 lb; minimum gross 920 lb.
- Seat + under-seat baggage: 240 lb max per seat; baggage compartment 50 lb max.
- Bladder usable fuel: main 16.9 gal; aux 9.4 gal; combined 26.3 gal.
- MAP instrument markings are model-specific. Beta II automatic lookup uses the exact POH \xa72 p. 2-11 table and the +0.9 inHg five-minute takeoff rule. Other models direct the student to their applicable POH placard rather than fabricating an automatic value.

## Section 6 loading data checked
- Right seat/pilot + baggage: 78.0 in longitudinal, +10.7 in lateral.
- Left seat/passenger + baggage: 78.0 in longitudinal, -9.3 in lateral.
- Main fuel: 108.6 in longitudinal, -11.0 in lateral.
- Auxiliary fuel: 103.8 in longitudinal, +11.2 in lateral.
- Combined-fuel longitudinal shortcut: 106.9 in only when lateral CG is not being calculated.
- Doors: 5.2 lb each, 77.5 in longitudinal, \xb121.0 in lateral.
- Removable left-seat controls: 2.6 lb, 66.3 in longitudinal, -12.9 in lateral.
- Accessory mount bars: 53.0 in longitudinal, lateral station within \xb112.0 in.
- Early-style seat caveat before S/N 0256 (79.0 in) remains an aircraft-configuration item and is not silently applied to later aircraft.
- POH requirement retained: takeoff and empty-fuel loading must both be checked because fuel burn moves CG forward.

## v34 implementation checks
- Longitudinal CG envelope functions are separated for Standard/HP versus Alpha/Beta/Beta II and use the POH \xa72 breakpoints.
- Live W&B now calculates and displays lateral CG from POH \xa76 station arms; unusual lateral loading is explicitly directed back to the POH \xa72 lateral envelope rather than being falsely auto-certified.
- Default training example: 800 lb empty weight, 103.8 in longitudinal arm, 0.0 in lateral arm, 150 lb right seat, 120 lb left seat, full usable bladder fuel. It starts within the Beta II longitudinal envelope and moves immediately when loading inputs change. It is labeled as a training example, not aircraft-specific empty-weight data.
- Aircraft-specific empty weight and arms must come from that helicopter's current W&B record.
- Density-altitude and E6B outputs remain labeled training calculations, not Robinson POH performance data.
- Model-specific POH Section 5 chart images remain the controlling performance reference in the Performance Pad.

## Release-blocking safety rule
If an R22-specific value cannot be traced to the supplied POH/RFM or a clearly identified applicable Robinson/FAA source, it must not be presented as authoritative R22 data. Calculated or digitized training aids must be labeled as such.
