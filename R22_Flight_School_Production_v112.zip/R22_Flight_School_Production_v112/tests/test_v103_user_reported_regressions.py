from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding="utf-8")
def test_component_lab_has_exactly_one_reference_picture():
 h=t("app/templates/rotor_components.html")
 assert h.count('class="rotor-photo-base') == 1
 assert 'id="quizClickLayer"' in h
def test_quiz_does_not_show_baked_label_photo():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert 'rotor_quiz_clean_v105.png' in j
 assert 'id="quizClickLayer"' in h
def test_motion_is_automatic_and_drives_visible_mechanism():
 j=t("app/static/rotor_components_v91.js")
 assert "function startDemo()" in j and "setInterval" in j
 assert "--swash-y" in j and "--swash-tilt" in j
def test_emergency_condition_is_not_overwritten_by_actions():
 j=t("app/static/emergency_v87.js")
 a=j[j.index("function effect(id){"):j.index("function updateScore(){")]
 assert "flightCue" not in a
 assert "flightCue" not in a
 assert "actionEffect" in j
def test_emergency_readouts_are_explicitly_not_controls():
 h=t("app/templates/emergency.html")
 assert "LIVE FLIGHT INSTRUMENTS — READOUTS, NOT CONTROLS" in h
 assert 'id="actionEffect"' in h
