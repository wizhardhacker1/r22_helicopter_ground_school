from pathlib import Path
from app.flashcard_deck import FLASHCARD_DECK

ROOT=Path(__file__).resolve().parents[1]

def test_v65_has_500_source_tagged_flashcards():
    assert len(FLASHCARD_DECK) >= 500
    assert all(len(c)==4 for c in FLASHCARD_DECK)
    assert all(all(str(v).strip() for v in c) for c in FLASHCARD_DECK)
    fronts=[c[1].strip().lower() for c in FLASHCARD_DECK]
    assert len(fronts) == len(set(fronts)) == 500

def test_v65_flashcards_have_broad_category_coverage():
    cats={c[0] for c in FLASHCARD_DECK}
    required={'Aerodynamics','Weather','Airspace','Performance','Systems','Weight & Balance','Communications','Checkride'}
    assert required <= cats
    assert len(cats) >= 15

def test_v65_flashcard_ui_has_mastery_controls():
    t=(ROOT/'app/templates/flashcards.html').read_text(encoding='utf-8')
    j=(ROOT/'app/static/flashcards.js').read_text(encoding='utf-8')
    for x in ('Missed only','Unseen only','Known only','Shuffle','Reset progress'):
        assert x in t
    assert 'localStorage' in j and '500 total' in j

def test_v65_real_helicopter_audio_is_bundled_and_used_by_both_trainers():
    audio=ROOT/'app/static/audio/r22_helicopter_running.mp3'
    assert audio.exists() and audio.stat().st_size > 800_000
    for name in ('startup.js','checklists.js'):
        text=(ROOT/'app/static'/name).read_text(encoding='utf-8')
        assert '/static/audio/r22_helicopter_running.mp3?v=76' in text
        assert 'realHeliAudio.loop=true' in text
        assert 'realHeliAudio.pause()' in text

def test_v65_audio_and_flashcards_are_offline_core_assets():
    sw=(ROOT/'app/static/sw.js').read_text(encoding='utf-8')
    v=(ROOT/'VERSION').read_text(encoding='utf-8').strip(); assert f'/static/audio/r22_helicopter_running.mp3?v={v}' in sw
    assert f'/static/flashcards.js?v={v}' in sw
