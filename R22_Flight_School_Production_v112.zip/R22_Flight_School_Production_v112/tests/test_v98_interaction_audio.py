from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')
def test_lab_direct_manipulation_and_quiz():
 h=t("app/templates/rotor_components.html"); j=t("app/static/rotor_components_v91.js")
 assert all(f'id="{x}" type="range"' in h for x in ["labCollective","labCyclic","labPedals"])
 assert "data-labcmd=" not in h and "quizKey" in j
 assert "addEventListener('input'" in j and "layer.addEventListener('pointerdown'" in j
def test_audio_defaults_on_all_cockpits():
 assert "audioEnabled=true" in t("app/static/startup.js")
 assert "audio=true" in t("app/static/checklists.js")
 e=t("app/static/emergency_v87.js")
 assert "audioEnabled=true" in e and "r22_helicopter_running.mp3" in e and "syncAudio()" in e
 for x in ["app/templates/startup.html","app/templates/checklists.html","app/templates/emergency.html"]:
  assert 'aria-pressed="true">AUDIO ON' in t(x)
def test_emergency_success_green():
 c=t("app/static/app.css")
 assert ".em87-actions button.used:not(.wrong){background:#16823b" in c
