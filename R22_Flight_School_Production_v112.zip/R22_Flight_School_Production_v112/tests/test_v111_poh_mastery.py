import os, shutil, json
from pathlib import Path
R=Path(__file__).resolve().parents[1]

def t(p): return (R/p).read_text(encoding='utf-8')

def test_poh_mastery_has_real_course_and_separate_reference():
    h=t('app/templates/poh_mastery.html'); j=t('app/static/poh_mastery.js'); m=t('app/main.py')
    assert 'READ' in h and 'APPLY' in h and 'TEST' in h
    assert 'data-poh-quiz' in h and 'GRADE FINAL ASSESSMENT' in h
    assert '/poh/reference' in h
    assert "@app.get('/poh',response_class=HTMLResponse)" in m
    assert "@app.get('/poh/reference')" in m
    assert "module='poh_mastery'" in m
    assert "score>=80" in m
    assert 'reviewed' in j

def test_poh_mastery_source_has_ten_sections_and_fifty_section_questions():
    from app.poh_mastery import POH_MASTERY_SECTIONS, POH_FINAL_QUESTIONS
    assert len(POH_MASTERY_SECTIONS)==10
    assert sum(len(x['questions']) for x in POH_MASTERY_SECTIONS)==50
    assert len(POH_FINAL_QUESTIONS)==10
    assert all(len(x['lessons'])>=3 for x in POH_MASTERY_SECTIONS)

def test_navigation_uses_mastery_while_explicit_reference_links_use_pdf_route():
    base=t('app/templates/base.html'); perf=t('app/templates/performance.html'); startup=t('app/templates/startup.html'); flow=t('app/templates/checklists.html')
    assert 'href=/poh><span>POH Mastery</span>' in base
    assert 'href=/poh>Study the POH' in perf
    assert 'href="/poh/reference"' in startup and 'href="/poh/reference"' in flow
    assert "href='/poh/reference' target=_blank>Open Bundled R22 POH" in t('app/templates/question_bank.html')

def test_poh_course_completion_cannot_be_earned_by_opening_page_or_skipping_lessons():
    # API logic must require both lesson review and an 80% section score.
    m=t('app/main.py')
    assert "lessons_complete=required.issubset(reviewed)" in m
    assert "complete=lessons_complete and score>=80" in m
    assert "status='complete' if complete else 'attempted'" in m

def test_final_assessment_requires_all_sections_first():
    m=t('app/main.py')
    assert "if not section_keys.issubset(completed)" in m
    assert "Complete all 10 POH sections before the final assessment." in m
