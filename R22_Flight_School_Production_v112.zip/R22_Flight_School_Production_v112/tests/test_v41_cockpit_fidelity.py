from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def txt(p): return (ROOT/p).read_text(encoding="utf-8")
def test_v41_user_panel_reference_retained_but_not_rendered():
    assert (ROOT/"app/static/r22_panel_reference.png").stat().st_size > 100000
    assert "r22_panel_reference.png?v=112" in txt("app/templates/startup.html")
    assert "r22_panel_reference.png?v=112" in txt("app/templates/checklists.html")
def test_v41_dual_tach_and_sprag_are_functional():
    for f in ["app/templates/startup.html","app/templates/checklists.html"]:
        s=txt(f); assert 'id="engineNeedle"' in s and 'id="rotorNeedlePanel"' in s
    s=txt("app/static/startup.js"); assert "setSplit(base-12,base)" in s and "setSplit(base,base)" in s
    s=txt("app/static/checklists.js"); assert "setRpm(base-12,base)" in s
def test_v41_engine_rotor_motion_audio_and_readiness():
    s=txt("app/static/startup.js")
    for x in ["engineOsc","rotorOsc","ENGINE RUNNING","READY TO FLY","rotorRpm","mainRotor"]: assert x in s
    c=txt("app/static/checklists.js")
    for x in ["engineOsc","rotorOsc","ENGINE RUNNING","READY TO FLY","SHUTDOWN COMPLETE"]: assert x in c
