from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JS=(ROOT/'app/static/checklists.js').read_text(encoding='utf-8')
CSS=(ROOT/'app/static/app.css').read_text(encoding='utf-8')
HTML=(ROOT/'app/templates/checklists.html').read_text(encoding='utf-8')

def test_flow_has_stateful_controls_and_gauges():
    for token in ["function baseCockpit()","function applyPhaseSystemState()","control('Battery & strobe','ON',true)","control('Clutch','ENGAGED',true)","control('Alternator','ON',true)","control('Avionics','ON',true)","control('Doors','CLOSED & LATCHED',true)","gauge('Manifold pressure'","oilRead","setRpm(103,103)"]:
        assert token in JS

def test_flow_green_correct_state_visual():
    assert '.cockpit-control.system-on' in CSS
    assert '.flow-state-summary span.system-on' in CSS

def test_shutdown_models_decay_and_secure_state():
    for token in ["setRpm(70,70)","setRpm(0,46)","setRpm(0,30)","setRpm(0,0)","control('Rotor brake',idx>=13?'ENGAGED':'DISENGAGED',idx>=13)"]:
        assert token in JS

def test_flow_asset_cache_bumped():
    assert f'/static/checklists.js?v={Path("VERSION").read_text(encoding="utf-8").strip()}' in HTML
