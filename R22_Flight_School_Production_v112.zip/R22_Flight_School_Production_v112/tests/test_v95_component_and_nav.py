from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding='utf-8')
def test_component_photo_has_no_fake_motion_overlay():
 h=t("app/templates/rotor_components.html")
 assert "motion-overlay87" not in h and "ov-swash" not in h and "ov-link" not in h
def test_component_learning_has_real_pedal_state_motion():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert 'id="labPedalVisual"' in h and 'id="labTailRotor"' in h
 assert "--lab-pedal-left" in j and "--lab-pedal-right" in j and "--tail-feather" in j
def test_emergency_is_in_flight_training_nav():
 h=t("app/templates/base.html")
 assert "<summary>SAFETY & FLIGHT LABS</summary>" in h
 assert '<a href=/emergency><span>Emergency Procedures Trainer</span></a>' in h
