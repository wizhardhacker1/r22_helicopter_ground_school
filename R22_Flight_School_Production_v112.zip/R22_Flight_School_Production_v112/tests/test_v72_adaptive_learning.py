from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_spaced_repetition_due_scheduler():
 j=(R/'app/static/flashcards.js').read_text(encoding='utf-8'); h=(R/'app/templates/flashcards.html').read_text(encoding='utf-8')
 assert "due:Date.now()+days*DAY" in j and "g==='hard'" in j and 'Due for review' in h
def test_personalized_daily_plan_uses_mastery():
 h=(R/'app/templates/dashboard.html').read_text(encoding='utf-8'); j=(R/'app/static/student_coach.js').read_text(encoding='utf-8')
 assert 'PERSONALIZED DAILY PLAN' in h and "sort((a,b)=>(a.score||0)-(b.score||0))" in j
def test_mock_oral_accumulates_session_evidence():
 h=(R/'app/templates/oral.html').read_text(encoding='utf-8'); j=(R/'app/static/mock_oral.js').read_text(encoding='utf-8')
 assert 'ACS MOCK ORAL' in h and "total+=Number(d.score||0)" in j and 'oralAverage' in j
def test_readiness_is_evidence_not_page_completion():
 h=(R/'app/templates/readiness.html').read_text(encoding='utf-8')
 assert 'EVIDENCE-BASED READINESS' in h and 'does not certify flight proficiency' in h
