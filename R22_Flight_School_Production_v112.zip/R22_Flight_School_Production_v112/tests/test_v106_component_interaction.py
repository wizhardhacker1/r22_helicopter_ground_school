from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding="utf-8")
def test_identify_and_motion_keep_live_controls():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 for x in ['id="labCollective" type="range"','id="labCyclic" type="range"','id="labPedals" type="range"']: assert x in h
 assert "$('#motionControls').hidden=quiz" in j
 assert "else labMove()" in j
def test_quiz_is_image_click_not_answer_buttons():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert 'id="quizClickLayer"' in h
 assert "layer.addEventListener('pointerdown'" in j
 assert "Where is the" in j
 assert "Click directly on that component" in j
def test_quiz_uses_clean_image():
 j=t("app/static/rotor_components_v91.js")
 assert "rotor_quiz_clean_v105.png" in j
def test_control_motion_drives_visible_mechanism():
 j=t("app/static/rotor_components_v91.js")
 for x in ["--swash-y","--swash-tilt","--link-left","--link-right"]: assert x in j
 assert "component-manual-motion" in j
def test_watch_mode_runs_demo():
 j=t("app/static/rotor_components_v91.js")
 assert "function startDemo()" in j and "setInterval" in j and "if(m==='motion')startDemo()" in j
