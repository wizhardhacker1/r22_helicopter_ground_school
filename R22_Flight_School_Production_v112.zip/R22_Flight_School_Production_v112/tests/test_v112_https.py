from pathlib import Path
import os
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')

def test_tls_dependency_and_secure_env_defaults():
    assert 'cryptography==50.0.2' in t('requirements.txt')
    env=t('.env.example')
    assert 'APP_NAME="R22 Flight School"' in env
    assert 'HTTPS_ENABLED=true' in env and 'COOKIE_SECURE=true' in env

def test_run_py_enables_uvicorn_tls():
    s=t('run.py')
    assert 'ssl_certfile' in s and 'ssl_keyfile' in s
    assert 'ensure_tls()' in s
    assert 'load_dotenv()' in s

def test_tls_generator_keeps_ca_private_and_server_sans():
    s=t('app/tls_support.py')
    assert 'R22 Flight School Local CA' in s
    assert 'BasicConstraints(ca=True' in s
    assert 'SubjectAlternativeName' in s
    assert '127.0.0.1' in s and 'r22school.local' in s
    assert "os.chmod(path, 0o600)" in s

def test_installers_generate_and_trust_ca():
    l=t('deploy/install_linux.sh'); w=t('deploy/INSTALL_WINDOWS.ps1')
    assert 'Do not run the entire R22 installer with sudo' in l
    assert 'python deploy/setup_https.py' in l
    assert 'update-ca-certificates' in l
    assert 'deploy\\setup_https.py' in w
    assert 'certutil.exe -user -addstore -f Root' in w

def test_launchers_use_https():
    assert 'https://127.0.0.1' in t('deploy/start_linux.sh')
    assert 'https://127.0.0.1' in t('deploy/START_WINDOWS.ps1')

def test_profile_has_network_https_ui_and_ca_download():
    h=t('app/templates/profile.html'); m=t('app/main.py')
    assert 'NETWORK & HTTPS' in h
    assert '/network/ca.crt' in h
    assert 'Download Local CA Certificate' in h
    assert "@app.get('/network/ca.crt')" in m
    assert "@app.post('/admin/https/regenerate')" in m

def test_private_ca_key_is_not_bundled():
    assert not list(R.rglob('r22-local-ca.key'))
    assert not list(R.rglob('r22-server.key'))


def test_installer_verification_uses_testing_cookie_override():
    assert 'R22_TESTING=true python -m pytest -q' in t('deploy/install_linux.sh')
    assert "$env:R22_TESTING='true'" in t('deploy/INSTALL_WINDOWS.ps1')
    m=t('app/main.py')
    assert 'def _secure_cookie()' in m and "os.getenv('R22_TESTING'" in m


def test_root_linux_install_and_trust_helpers_exist():
    assert (R/'INSTALL_LINUX.sh').exists()
    assert (R/'TRUST_R22_CERTIFICATE_LINUX.sh').exists()
    assert 'deploy/install_linux.sh' in t('INSTALL_LINUX.sh')
