from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding="utf-8")

def test_all_emergency_scenarios_have_interactive_configs():
    j=t("app/static/emergency_v87.js")
    scenarios=[
        "power_high","power_mid","power_low","max_glide","air_restart",
        "water_off","water_on","tail_forward","tail_hover","audio",
        "fire_start","engine_fire","electrical_fire","tach","governor",
        "low_g","ad_wind"
    ]
    for key in scenarios:
        assert f" {key}:{{" in j or f"\n {key}:{{" in j, key
    assert "warningCases=[" in j
    assert "audioCases=[" in j

def test_required_procedure_controls_exist():
    j=t("app/static/emergency_v87.js")
    required=[
      "collective","collective-up","aft","lateral","airspeed65","airspeed70","airspeed75",
      "rpm97110","rpm90","landing","flare40","flare-ground","cushion8","right-pedal","settle",
      "autorotation","safe-auto","mixture-rich","mixture-off","primer-lock","throttle-crack",
      "starter","throttle-off","throttle-on","manual-throttle","governor-off","fuel-off",
      "battery","alternator","doors-unlatch","lateral-stop","seatbelt-exit","normal-landing",
      "auto-landing","cabin-heat-off","vents-open","rotor-brake","exit","continue-crank",
      "rpm50-60","governor-control","land-practical","land-immediate","clutch-breaker",
      "alt-reset","reduce-collective","reduce-turb","smooth-controls","depart-turb",
      "raise-collective","positive-g"
    ]
    for code in required:
        assert f"'{code}'" in j, code

def test_physical_cockpit_controls_trigger_matching_procedure_steps():
    j=t("app/static/emergency_v87.js")
    for physical in [
      "'governor'","'alternator'","'battery & strobe'","'mixture'",
      "'primer (if installed)'","'rotor brake'","'fuel shut-off valve'",
      "'throttle'","'doors'","'cyclic'","'collective'","'pedals'",
      "'seat belts'","'ignition'"
    ]:
        assert physical in j

def test_source_aligned_high_risk_sequences():
    j=t("app/static/emergency_v87.js")
    assert "seq:['collective','airspeed65','rpm97110','landing','switches-fuel-off','flare40','cushion8']" in j
    assert "seq:['collective','rpm97110','flare-ground','cushion8']" in j
    assert "seq:['right-pedal','settle','collective-up']" in j
    assert "seq:['manual-throttle','governor-off']" in j
    assert "seq:['battery','alternator','vents-open','land-immediate','mixture-off','fuel-off','rotor-brake','exit']" in j
    assert "seq:['aft','positive-g','lateral']" in j

def test_every_configured_action_has_a_visible_label():
    import re
    j=t("app/static/emergency_v87.js")
    a=j[j.index("const A={")+len("const A={"):j.index("};\n\nconst base")]
    catalog={x or y for x,y in re.findall(r"(?:'([^']+)'|([A-Za-z0-9_-]+))\\s*:",a)}
    used=set()
    for m in re.finditer(r"(?:seq|choices):\\[(.*?)\\]",j,re.S):
        used.update(re.findall(r"'([^']+)'",m.group(1)))
    assert used <= catalog, sorted(used-catalog)
