from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_startup_active_check_above_cockpit():
    s=(ROOT/'app/templates/startup.html').read_text(encoding='utf-8')
    assert s.index('id="simActionPanel"') < s.index('id="cockpitPanel"')

def test_flow_active_check_above_cockpit():
    s=(ROOT/'app/templates/checklists.html').read_text(encoding='utf-8')
    start=s.index('id="cockpitFlowVisual"')
    a=s.index('id="flowActionPanel"', start)
    c=s.index('id="cockpitPanel"', start)
    assert a < c

def test_movement_controls_remain_visual_sliders():
    a=(ROOT/'app/static/startup.js').read_text(encoding='utf-8')
    b=(ROOT/'app/static/checklists.js').read_text(encoding='utf-8')
    assert 'type="range"' in a and 'data-motion="cyclic"' in a and 'data-motion="throttle"' in a
    assert 'type="range"' in b and 'data-fmotion="a"' in b and 'data-fmotion="throttle"' in b
