from pathlib import Path

def test_flow_checklist_is_right_side_sticky_workspace():
    html=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    css=Path("app/static/app.css").read_text(encoding="utf-8")
    assert 'flow-guide flow-guide-right' in html
    assert 'flow-state-summary' in html
    for label in ['CYCLIC','COLLECTIVE','PEDALS','FRICTIONS','SEAT BELTS']:
        assert label in html
    assert '.flow-guide-right{position:sticky!important' in css
    assert 'grid-template-columns:1fr 1fr' in css

def test_v45_cache_bust():
    base=Path("app/templates/base.html").read_text(encoding="utf-8")
    sw=Path("app/static/sw.js").read_text(encoding="utf-8")
    checks=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'app.css?v={v}' in base and f'app.js?v={v}' in base and f'sw.js?v={v}' in base
    assert f'r22-school-v{Path("VERSION").read_text(encoding="utf-8").strip()}-static' in sw
    assert f'checklists.js?v={v}' in checks
