from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def txt(p): return (ROOT/p).read_text(encoding='utf-8')

def test_every_cockpit_has_full_annunciator_set_and_warning_tests():
    for f in ['app/templates/startup.html','app/templates/checklists.html']:
        s=txt(f)
        for light in ['starter','clutch','lowrpm','govoff','lowfuel','oil','alt','mrtemp','mrchip','trchip']:
            assert f'data-light="{light}"' in s
        for test in ['mrtemp','mrchip','trchip','lowfuel']:
            assert f'data-test-light="{test}"' in s
        assert 'audio-toggle' in s

def test_startup_checklist_controls_exist_on_cockpit():
    s=txt('app/templates/startup.html')
    for control in ['Seat belts','Fuel shut-off valve','Cyclic / collective friction','Throttle','Collective','Cyclic','Pedals','Rotor brake','Circuit breakers','Carb heat','Mixture','Mixture guard','Primer (if installed)','Landing lights','Avionics','Clutch','Altimeter','Governor','Battery & strobe','Ignition','Alternator','Doors']:
        assert f'data-control="{control}"' in s

def test_cockpit_state_logic_and_offline_audio_are_present():
    s=txt('app/static/startup.js')
    for token in ['updateSystems','simulateStart','AudioContext','lowrpm','govoff','oil','alt','testedLights','Warning light tests']:
        assert token in s
    assert 'fetch(' in s  # training-record API only
    # v65: user-provided helicopter-running audio is deliberately bundled locally.
    assert "/static/audio/r22_helicopter_running.mp3?v=76" in s
    assert 'http://' not in s and 'https://' not in s

def test_v40_asset_versions_are_consistent():
    version=txt('VERSION').strip()
    assert version.isdigit() and int(version)>=39
    for f in ['app/templates/base.html','app/templates/startup.html','app/templates/checklists.html','app/templates/performance.html','app/templates/navigation_charts.html']:
        assert '?v=38' not in txt(f)
    assert f'r22-school-v{version}-static' in txt('app/static/sw.js')
