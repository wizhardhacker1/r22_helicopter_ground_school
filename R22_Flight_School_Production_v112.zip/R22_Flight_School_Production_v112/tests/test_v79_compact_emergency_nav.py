from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')
def test_v79_version_and_cache():
 assert t('VERSION').strip()=='112'; assert "APP_VERSION='112'" in t('app/main.py'); assert 'r22-school-v112-static' in t('app/static/sw.js')
def test_rotor_is_under_r22_aircraft_only():
 b=t('app/templates/base.html'); aircraft=b.split('R22 AIRCRAFT',1)[1].split('RADIO & NAVIGATION',1)[0]; radio=b.split('RADIO & NAVIGATION',1)[1].split('SAFETY & FLIGHT LABS',1)[0]
 assert '/rotor-controls' in aircraft and '/rotor-controls' not in radio
def test_navigation_hero_removed():
 h=t('app/templates/navigation_charts.html'); assert 'compact-pagebar' in h and 'hero nav-hero' not in h
def test_emergency_is_interactive():
 h=t('app/templates/emergency.html'); js=t('app/static/emergency_v87.js')
 for x in ['em87-grid','emergency-original-cockpit','em87-actions','data-emmode','EVALUATE & DEBRIEF']: assert x in h
 assert 'cfg=' in js and 'filterControls' in js
