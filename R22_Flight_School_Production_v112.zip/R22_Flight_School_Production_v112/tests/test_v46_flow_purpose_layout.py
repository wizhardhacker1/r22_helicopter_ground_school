from pathlib import Path

def test_flow_is_true_right_column_on_desktop():
    css=Path("app/static/app.css").read_text(encoding="utf-8")
    assert "@media(min-width:761px)" in css
    assert "grid-template-columns:minmax(0,1fr) 360px!important" in css
    assert ".flow-guide-right{grid-column:2!important;grid-row:1!important" in css
    assert "@media(max-width:760px)" in css

def test_trainers_have_distinct_purposes():
    startup=Path("app/templates/startup.html").read_text(encoding="utf-8")
    flow=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    assert "STARTUP SIMULATOR" in startup
    assert "engine start, clutch engagement, run-up" in startup
    assert "FLOW / CHECKLIST TRAINER" in flow
    assert "Preflight -> Before Start -> Start & Run-Up -> Takeoff -> Shutdown" in flow
    assert "rather than duplicating the dedicated engine-start simulator" in flow

def test_v46_cache_bust():
    base=Path("app/templates/base.html").read_text(encoding="utf-8")
    sw=Path("app/static/sw.js").read_text(encoding="utf-8")
    checks=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'app.css?v={v}' in base and f'app.js?v={v}' in base and f'sw.js?v={v}' in base
    assert f'r22-school-v{Path("VERSION").read_text(encoding="utf-8").strip()}-static' in sw
    assert f"checklists.js?v={v}" in checks
