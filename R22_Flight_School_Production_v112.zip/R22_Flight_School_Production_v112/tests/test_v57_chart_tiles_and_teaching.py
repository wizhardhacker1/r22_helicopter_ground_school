from pathlib import Path

def test_chart_pipeline_preserves_source_detail_as_tiles():
 m=Path("app/main.py").read_text(encoding='utf-8')
 assert "out_h=1800" not in m
 assert "_build_faa_tiles" in m and "tile_size" in m and "FAA GeoTIFF" in m
 assert "/faa-chart-tile/{kind}/{z}/{x}/{y}.png" in m

def test_chart_course_teaches_on_real_chart():
 h=Path("app/templates/navigation_charts.html").read_text(encoding='utf-8')
 j=Path("app/static/navigation_charts.js").read_text(encoding='utf-8')
 assert "faaTileLayer" in h and "faaTrainingLayer" in h
 assert "Learn" in h and "Practice" in h and "Test" in h
 assert "no synthetic position markers" in j.lower() and "function taskFeature(){return null}" in j and "Read the real FAA chart" in j
 assert "mode==='learn'" in j and "mode==='practice'" in j

def test_refresh_is_maintenance_not_student_prerequisite():
 h=Path("app/templates/navigation_charts.html").read_text(encoding='utf-8')
 assert "students should never need to install chart media from this screen" in h
 assert "once while connected" not in h
