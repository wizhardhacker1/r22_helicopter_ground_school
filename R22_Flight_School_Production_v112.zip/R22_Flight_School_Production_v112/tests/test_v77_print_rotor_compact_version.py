from pathlib import Path
R=Path(__file__).resolve().parents[1]
def read(p): return (R/p).read_text(encoding='utf-8')
def test_v78_version_on_login_and_single_source():
 assert (R/'VERSION').read_text(encoding='utf-8').strip()=='112'
 assert 'v{{app_version}}' in read('app/templates/login.html')
 assert "APP_VERSION='112'" in read('app/main.py')
def test_print_routes_use_current_starlette_request_first_signature():
 s=read('app/main.py')
 assert "tpl.TemplateResponse(request,'checklist_reference_print.html'" in s
 assert "tpl.TemplateResponse(request,'flight_plan_print.html'" in s
 assert "templates.TemplateResponse('checklist_reference_print.html'" not in s
 assert "templates.TemplateResponse('flight_plan_print.html'" not in s
def test_rotor_control_trainer_has_all_primary_controls_and_modes():
 h=(R/'app/templates/rotor_controls.html').read_text(encoding='utf-8')
 for x in ['collective','cyclicPitch','cyclicRoll','pedals','motionReset','sideSwash','sideMainRotor','sideTailRotor']: assert x in h
 for x in ['data-mode="learn"','data-mode="explore"','data-mode="test"']: assert x in h

def test_compact_first_headers_are_global():
 css=read('app/static/app.css')
 assert '.page-head{padding:4px 0 8px!important' in css
 assert '.compact-head' in css
