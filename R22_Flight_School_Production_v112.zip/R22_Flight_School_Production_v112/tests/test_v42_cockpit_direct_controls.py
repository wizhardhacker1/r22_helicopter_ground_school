from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def txt(p): return (ROOT/p).read_text(encoding="utf-8")
def test_v42_active_check_is_inside_cockpit_and_reference_not_rendered():
    s=txt("app/templates/startup.html")
    assert 'cockpit-active-check' in s and s.index('cockpit-active-check') < s.index('trainer-command')
    assert 'panel-reference' not in s
    c=txt("app/templates/checklists.html")
    assert 'flowActionPanel' in c and 'panel-reference' not in c
def test_v42_warning_tests_use_panel_buttons_not_duplicate_action_buttons():
    s=txt("app/static/startup.js")
    assert 'Use the four physical TEST buttons on the annunciator panel above' in s
    assert 'data-sim="test-mrtemp"' not in s
    c=txt("app/static/checklists.js")
    assert 'Press the four TEST buttons directly on the annunciator panel' in c
    assert "if(s()?.[3]==='warning')" in c
def test_v42_movement_items_use_visual_sliders():
    s=txt("app/static/startup.js")
    for x in ['data-motion="cyclic"','data-motion="collective"','data-motion="pedals"','data-motion="throttle"','data-motion="prime"']: assert x in s
    c=txt("app/static/checklists.js")
    for x in ['data-fmotion="a"','data-fmotion="b"','data-fmotion="c"','data-fmotion="throttle"','data-fmotion="prime"']: assert x in c
