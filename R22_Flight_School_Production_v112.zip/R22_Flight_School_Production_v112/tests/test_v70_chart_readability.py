from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_no_unverified_chart_position_markers():
 js=(R/'app/static/navigation_charts.js').read_text(encoding='utf-8')
 assert "b.className='faa-hotspot'" not in js
 assert "function taskFeature(){return null}" in js
 assert "max_zoom-1" in js
 assert "v=76" in js
def test_chart_teaching_panel_is_legible_and_unobstructed():
 h=(R/'app/templates/navigation_charts.html').read_text(encoding='utf-8')
 c=(R/'app/static/app.css').read_text(encoding='utf-8')
 assert 'No synthetic location dots' in h
 assert 'color:#eef8fc!important' in c
