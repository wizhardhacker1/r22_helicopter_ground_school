from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')
def test_component_reference_has_no_duplicate_floating_hotspots():
 h=t('app/templates/rotor_components.html')
 assert 'hot87 blade' not in h and 'zoomIn' not in h and 'component-picker' in h
def test_component_photo_uses_natural_height_not_650_canvas():
 c=t('app/static/app.css'); assert '.r87-component-photo .photo-viewport{height:auto!important' in c
def test_emergency_is_presented_as_inflight_not_startup_console():
 h=t('app/templates/emergency.html'); c=t('app/static/app.css')
 assert 'IN-FLIGHT CONDITION' in h and 'em-flight-summary' in h
 assert '.emergency-cockpit-shell .r22-breakers' in c and '.emergency-cockpit-shell .r22-lower-controls' in c
def test_no_770_kias_typo():
 assert '770 KIAS' not in t('app/templates/emergency.html')
