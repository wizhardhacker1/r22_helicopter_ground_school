from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_local_voice_helicopter_library_no_robotic_bundled_wavs():
 h=(ROOT/'app/templates/atc.html').read_text(encoding='utf-8'); js=(ROOT/'app/static/atc_offline.js').read_text(encoding='utf-8')
 assert 'controllerVoice' in h and 'pilotVoice' in h
 assert 'SpeechSynthesisUtterance' in js and 'localService' in js
 assert '/static/audio/atc/' not in js and 'offlineAtcAudio' not in h
 assert not list((ROOT/'app/static/audio/atc').glob('*.wav'))
def test_offline_player_and_external_liveatc():
 h=(ROOT/'app/templates/atc.html').read_text(encoding='utf-8')
 assert 'offlineAtcSelect' in h and 'Open LiveATC' in h and '<iframe' not in h
 assert 'not represented as captured FAA transmissions' in h
