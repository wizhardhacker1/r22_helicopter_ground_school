from fastapi.testclient import TestClient
from app.main import app,startup
from app.db import SessionLocal
from app.models import User
from app.auth import token

def client():
 startup(); db=SessionLocal(); u=db.query(User).filter(User.username=='admin').first(); c=TestClient(app); c.cookies.set('session',token(u.id,u.role)); db.close(); return c

def test_v87_pages_and_assets_serve():
 c=client()
 for p in ['/rotor-controls','/rotor-components','/emergency?scenario=power_high','/static/rotor_motion_v87.js','/static/rotor_components_v87.js','/static/emergency_v87.js','/static/r22_preflight_three_view.jpg','/static/rotor_trainer_reference.png','/static/r22_panel_reference.png']:
  r=c.get(p); assert r.status_code==200,(p,r.status_code)
