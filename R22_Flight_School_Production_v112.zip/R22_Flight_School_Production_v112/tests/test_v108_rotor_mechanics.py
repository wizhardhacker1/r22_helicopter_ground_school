from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding="utf-8")

def test_rotor_overlay_shows_visible_blades_and_root_pitch():
    h=t("app/templates/rotor_components.html")
    assert "motion-blade left" in h and "motion-blade right" in h
    assert "motion-grip left" in h and "motion-grip right" in h

def test_collective_and_cyclic_drive_blade_and_swash_motion():
    j=t("app/static/rotor_components_v91.js")
    for x in ["--pitch-left","--pitch-right","--disc-tilt","--blade-heave","--swash-tilt","--link-left","--link-right"]:
        assert x in j

def test_blade_span_moves_as_rotor_disc_while_root_pitch_feathers_differentially():
    c=t("app/static/app.css")
    assert "#rotorMotionRig .motion-blade.left" in c
    assert "#rotorMotionRig .motion-blade.right" in c
    assert "rotate(var(--disc-tilt" in c
    assert "rotate(var(--pitch-left" in c and "rotate(var(--pitch-right" in c
