from pathlib import Path

def test_loading_initializer_waits_for_dom_and_appjs():
    root=Path(__file__).resolve().parents[1]
    js=(root/'app/static/performance_v12.js').read_text(encoding='utf-8')
    tpl=(root/'app/templates/performance.html').read_text(encoding='utf-8')
    base=(root/'app/templates/base.html').read_text(encoding='utf-8')
    assert "DOMContentLoaded" in js
    assert "initR22Loading" in js
    v=(root/'VERSION').read_text(encoding='utf-8').strip()
    assert f"performance_v12.js?v={v}" in tpl
    assert f"app.js?v={v}" in base
    for i in ["vis_pilot","vis_passenger","vis_left_bag","vis_right_bag","vis_fuel"]:
        assert f'id="{i}"' in tpl
