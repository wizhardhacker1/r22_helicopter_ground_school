from pathlib import Path

def t(p): return Path(p).read_text(encoding='utf-8')

def test_v50_academy_is_full_curriculum_not_cards_only():
    from app.academy import ACADEMY_COURSES
    assert len(ACADEMY_COURSES) >= 17
    assert all(len(c['lessons']) >= 4 for c in ACADEMY_COURSES)
    assert all(c.get('acs') and c.get('refs') and c.get('r22') and c.get('lab') for c in ACADEMY_COURSES)
    keys={c['key'] for c in ACADEMY_COURSES}
    required={'radio','weatherbrief','hovercheck','systems','carbice','rotorenergy','hv','wind','wires','rollover','vrs','lowg','iimc','ground','annunciators','oral','minimums','currency'}
    assert required <= keys

def test_v50_nested_navigation_prevents_sidebar_sprawl():
    base=t('app/templates/base.html')
    assert base.count('class="nav-group"') >= 6
    assert 'R22 Academy' in base and 'SAFETY & FLIGHT LABS' in base and 'RADIO & NAVIGATION' in base
    assert 'document.querySelectorAll(\'.nav-group\')' in base

def test_v50_completion_is_not_page_visit():
    main=t('app/main.py'); js=t('app/static/academy.js')
    assert "@app.post('/api/academy/complete')" in main
    assert "lessons < len(course['lessons']) or not lab" in main
    assert "ticks.every(x=>x.checked)||!passed" in js

def test_v50_optional_live_atc_does_not_replace_offline_training():
    atc=t('app/templates/atc.html'); main=t('app/main.py')
    assert 'Live ATC Player' in atc and 'offline radio training remains fully functional' in atc
    assert '/connected/live-atc' in main and 'liveatc.net' in main

def test_v50_release_assets_are_version_consistent():
    v=t('VERSION').strip(); assert v.isdigit() and int(v)>=50
    for f in ['app/templates/base.html','app/templates/startup.html','app/templates/checklists.html','app/templates/performance.html','app/static/sw.js']:
        s=t(f); assert 'v=49' not in s
    assert f'app.css?v={v}' in t('app/templates/base.html')
