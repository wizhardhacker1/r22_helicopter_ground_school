from pathlib import Path
import re
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding="utf-8")
def test_no_javascript_style_unicode_escapes_in_css():
 s=t("app/static/app.css")
 assert not re.search(r"\\u[0-9a-fA-F]{4}",s)
def test_no_invalid_capital_U_unicode_escape_in_runtime_js():
 for p in (R/"app/static").glob("*.js"):
  assert "\\U" not in p.read_text(encoding="utf-8"),p.name
def test_emergency_has_no_decorative_terrain_windshield():
 h=t("app/templates/emergency.html")
 assert "terrain87" not in h and 'id="windshield"' not in h
 assert 'id="flightCue"' in h and "em87-cuebar" in h
def test_pedals_use_opposed_visible_motion():
 j=t("app/static/rotor_motion_v91.js");c=t("app/static/app.css")
 assert "y*.26" in j and "--pedal-left" in j and "--pedal-right" in j
 assert "translateY(var(--pedal-left" in c and "translateY(var(--pedal-right" in c
def test_component_controls_wrap_on_narrow_screens():
 c=t("app/static/app.css")
 assert "@media(max-width:700px)" in c and ".lab-command-row,.lab-command-row.pedals" in c
