from pathlib import Path
import ast
R=Path(__file__).resolve().parents[1]

def test_emergency_utf8_text_is_read_explicitly():
    h=(R/"app/templates/emergency.html").read_text(encoding="utf-8")
    assert "LIVE FLIGHT INSTRUMENTS \u2014 READOUTS, NOT CONTROLS" in h

def test_active_tests_do_not_use_implicit_read_text_encoding():
    this_file=Path(__file__).resolve()
    offenders=[]
    for p in (R/"tests").glob("test_*.py"):
        if p.resolve() == this_file:
            continue
        tree=ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr=="read_text":
                if not any(k.arg=="encoding" for k in node.keywords):
                    offenders.append(p.name)
                    break
    assert not offenders, f"Implicit Path.read_text encoding in: {offenders}"
