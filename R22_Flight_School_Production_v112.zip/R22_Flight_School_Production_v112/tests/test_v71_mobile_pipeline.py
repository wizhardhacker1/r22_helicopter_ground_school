from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_nav_has_no_bracket_pseudo_icons():
 h=(R/'app/templates/base.html').read_text(encoding='utf-8')
 for x in ('[C]','[V]','[P]','[START]','[FLOW]','[NAV]','[SET]','[ATC]'): assert x not in h
def test_checklist_is_normal_app_page_and_printable():
 h=(R/'app/templates/checklist_reference.html').read_text(encoding='utf-8')
 assert "extends 'base.html'" in h and '/checklist-reference/print' in h and 'checklist-mobile-note' in h
def test_mobile_and_flight_planning():
 h=(R/'app/templates/flight_planner.html').read_text(encoding='utf-8'); j=(R/'app/static/navigation_charts.js').read_text(encoding='utf-8')
 assert 'Interactive Flight Planning' in h and 'PAVE / go-no-go' in h and 'NAV LOG' in h
 assert 'activePointers' in j and 'pinchDistance' in j
def test_security_install_pipeline_stays_strict():
 ps=(R/'deploy/INSTALL_WINDOWS.ps1').read_text(encoding='utf-8')
 assert 'pytest' in ps and 'Installation was NOT verified' in ps
