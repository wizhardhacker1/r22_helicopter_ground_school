from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_fake_chart_removed_and_real_faa_cache_workflow_present():
 h=(ROOT/'app/templates/navigation_charts.html').read_text(encoding='utf-8'); m=(ROOT/'app/main.py').read_text(encoding='utf-8'); js=(ROOT/'app/static/navigation_charts.js').read_text(encoding='utf-8')
 assert not (ROOT/'app/static/faa_sectional_training.svg').exists()
 assert 'FAA-STYLE OFFLINE' not in h
 assert 'Official FAA chart training media is unavailable.' in h
 assert '/api/faa-charts/install' in m and '/faa-chart-tile/{kind}/{z}/{x}/{y}.png' in m
 assert 'Los_Angeles.zip' in m and 'Los_Angeles_Heli.zip' in m
 assert 'Install / Refresh FAA Charts' not in h
 assert "fetch('/api/faa-charts/status')" in js
def test_real_chart_cache_uses_persistent_data_dir():
 m=(ROOT/'app/main.py').read_text(encoding='utf-8')
 assert "R22_DATA_DIR" in m and "'faa_charts'" in m
