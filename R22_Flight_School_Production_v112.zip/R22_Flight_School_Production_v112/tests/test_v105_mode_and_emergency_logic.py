from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding="utf-8")
def test_component_modes_preserve_controls_and_image_quiz():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert 'id="motionControls"' in h
 assert 'id="quizClickLayer"' in h
 assert "$('#motionControls').hidden=quiz" in j
 assert "rotor_quiz_clean_v105.png" in j
def test_quiz_requires_click_on_picture():
 j=t("app/static/rotor_components_v91.js")
 assert "Where is the" in j
 assert "layer.addEventListener('pointerdown'" in j
def test_motion_controls_drive_visible_rig():
 j=t("app/static/rotor_components_v91.js");c=t("app/static/app.css")
 assert "startDemo()" in j and "--swash-y" in j and "--swash-tilt" in j
 assert "#rotorMotionRig" in c
def test_low_g_uses_full_recovery_order_without_fake_landing_step():
 j=t("app/static/emergency_v87.js")
 assert "low_g:{cue:'LOW-G / RIGHT-ROLL TENDENCY'" in j
 assert "seq:['aft','positive-g','lateral']" in j
 assert "[...cfg.seq,'landing']" not in j
def test_correct_sequence_can_complete_without_extra_action():
 j=t("app/static/emergency_v87.js")
 assert "progress===cfg.seq.length" in j
 assert "$('#emPhase').textContent='COMPLETE'" in j
