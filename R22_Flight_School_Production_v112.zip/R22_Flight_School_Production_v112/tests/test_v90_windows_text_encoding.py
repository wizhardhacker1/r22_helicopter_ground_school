from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_runtime_text_files_decode_on_windows_cp1252():
    for rel in ["app/static/app.css","app/static/rotor_motion_v89.js",
                "app/templates/startup.html","app/templates/checklists.html",
                "app/templates/rotor_controls.html","app/templates/rotor_components.html"]:
        (R/rel).read_bytes().decode("cp1252")
def test_css_is_ascii_safe_for_windows_installer_tests():
    data=(R/"app/static/app.css").read_bytes()
    assert all(b < 128 for b in data)
