from app.calculators import pressure_altitude,density_altitude,wind_triangle,wb,cg_limits_beta
def test_pa(): assert pressure_altitude(5000,29.92)==5000
def test_da_standardish(): assert 4800<density_altitude(5000,29.92,5)<5200
def test_wind_headwind(): assert wind_triangle(90,100,90,10,50)['ground_speed']==90.0
def test_wind_impossible(): assert wind_triangle(0,20,90,30,10)['possible'] is False
def test_wb_sample_close_to_poh():
 r=wb(880,104,170,160,0,0,16.9,9.4,'Beta II'); assert abs(r['takeoff']['weight']-1367.8)<.3; assert 97.8<r['takeoff']['cg']<98.2; assert r['takeoff']['over_gross'] is False
def test_wb_seat_bag_flag(): assert wb(700,100,230,100,0,20,0,0)['right_seat_plus_bag_over'] is True
def test_fuel_limit():
 import pytest
 with pytest.raises(ValueError): wb(800,100,100,100,0,0,17,0)
def test_beta_cg_envelope():
 f,a=cg_limits_beta(1370); assert f==96.5 and a==100.0

def test_fuel_plan_reserve():
 from app.calculators import fuel_plan
 x=fuel_plan(12.8,6.5,9.0,61,20)
 assert x['endurance_minutes'] > 128
 assert x['reserve_minutes_remaining'] > 67
 assert x['meets_selected_reserve'] is True

def test_poh_wb_alerts_are_data_driven():
 from app.calculators import wb
 r=wb(880,104,230,160,0,20,16.9,9.4,'Beta II',0)
 assert r['right_seat_plus_bag_over'] is True
 assert any('240 lb' in x for x in r['alerts'])
 assert r['poh_basis']['main_fuel_arm_in']==108.6
 assert r['poh_basis']['aux_fuel_arm_in']==103.8
 assert r['poh_basis']['max_gross_lb']==1370

def test_standard_hp_cg_envelope_is_checked():
    from app.calculators import cg_limits
    assert cg_limits('Standard', 920) == (95.5, 101.5)
    assert cg_limits('Standard', 1300) == (96.5, 99.5)

def test_beta_family_cg_envelope_breakpoints():
    from app.calculators import cg_limits
    assert cg_limits('Beta II', 920) == (95.5, 102.0)
    assert cg_limits('Beta II', 1370) == (96.5, 100.0)

def test_door_removal_changes_weight_and_cg():
 from app.calculators import wb
 base=wb(880,104,170,160,0,0,10,5,'Beta II')
 right=wb(880,104,170,160,0,0,10,5,'Beta II',right_door_removed=True)
 assert round(base['takeoff']['weight']-right['takeoff']['weight'],1)==5.2
 assert right['poh_basis']['door_long_arm_in']==77.5

def test_left_door_removal_adds_poh_caution():
 from app.calculators import wb
 r=wb(880,104,170,160,0,0,10,5,'Beta II',left_door_removed=True)
 assert any('left door removed' in x.lower() for x in r['alerts'])

def test_v34_poh_section6_lateral_and_loading_stations():
 r=wb(800,103.8,150,120,0,0,16.9,9.4,'Beta II',8,empty_lateral_arm=0)
 assert r['takeoff']['weight']==1227.8
 assert r['takeoff']['cg']==98.52
 assert r['takeoff']['lateral_cg']==0.0
 assert r['zero_fuel']['cg']==97.29
 assert r['poh_basis']['seat_arms']=={'right_long':78.0,'right_lat':10.7,'left_long':78.0,'left_lat':-9.3}
 assert r['poh_basis']['usable_fuel_gal']=={'main':16.9,'aux':9.4,'combined':26.3}
 assert r['poh_basis']['removable_controls']=={'weight':2.6,'long':66.3,'lat':-12.9}
 assert r['poh_basis']['accessory_mount']=={'long':53.0,'lat_range':'\xb112.0'}
 assert r['all_checked_states_in_limits'] is True
