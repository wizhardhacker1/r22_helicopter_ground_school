from pathlib import Path

def t(p): return Path(p).read_text(encoding='utf-8')

def test_v61_declares_chart_runtime_dependencies():
    req=t('requirements.txt')
    assert 'Pillow==' in req and 'numpy==' in req and 'certifi==' in req and 'httpx==' in req

def test_v61_windows_preserves_real_chart_error_log():
    s=t('deploy/INSTALL_WINDOWS.ps1')
    assert 'deploy\\install_faa_charts.py' in s
    assert 'FAA_CHART_INSTALL.log' in s
    assert 'Start-Process' in s
    assert '-RedirectStandardOutput $faaOut' in s
    assert '-RedirectStandardError $faaErr' in s
    assert 'Tee-Object' not in s

def test_v61_chart_downloader_uses_httpx_and_reports_url():
    s=t('app/main.py')
    assert "httpx.stream('GET',meta['zip']" in s
    assert 'response.raise_for_status()' in s
    assert 'FAA download failed for' in s

def test_v61_installs_all_three_in_one_driver():
    s=t('deploy/install_faa_charts.py')
    assert 'for kind, meta in FAA_CHARTS.items()' in s
    assert '_verify_chart_tiles' in s
