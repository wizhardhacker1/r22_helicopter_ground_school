from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding='utf-8')
def test_quiz_is_separate_from_labeled_photo():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert 'id="quizClickLayer"' in h and "rotor_quiz_clean_v105.png" in j
def test_motion_mode_actually_animates():
 j=t("app/static/rotor_components_v91.js");c=t("app/static/app.css")
 assert "startDemo()" in j and "setInterval" in j and "--swash-y" in j and "--swash-tilt" in j
 assert 'body[data-component-mode="motion"] .rotor-motion-rig{display:block' in c
def test_emergency_summary_is_display_only():
 h=t("app/templates/emergency.html")
 assert "LIVE FLIGHT INSTRUMENTS — READOUTS, NOT CONTROLS" in h
 assert 'class="em-flight-summary"' in h
def test_motion_readouts_high_contrast():
 c=t("app/static/app.css")
 assert ".motion-data small{color:#b9d7e2!important;opacity:1!important" in c
 assert ".motion-data b{color:#fff!important;opacity:1!important" in c
