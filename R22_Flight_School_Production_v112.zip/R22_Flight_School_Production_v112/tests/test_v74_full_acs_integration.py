from pathlib import Path
import importlib.util
R=Path(__file__).resolve().parents[1]
def loadacs():
 s=importlib.util.spec_from_file_location('acs74',R/'app/acs.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def test_all_acs_tasks_are_curriculum_spine_without_false_100_percent():
 a=loadacs(); rows=a.coverage_rows(); assert len(rows)==49
 h=(R/'app/templates/acs_coverage.html').read_text(encoding='utf-8')
 assert 'ALL APPLICABLE TASKS ROUTED TO TRAINING' in h
 assert all(x['status'] in ('integrated','n/a') for x in rows)
def test_verified_ground_elements_are_real_acs_codes():
 a=loadacs();
 for key in ('I.A','I.B','I.C','I.D','I.E','I.F','I.G','I.H','II.A','IV.E','VIII.B'):
  assert a.VERIFIED_ELEMENTS[key] and all(x.startswith('PH.') for x in a.VERIFIED_ELEMENTS[key])
 assert 'PH.I.C.S3' in a.VERIFIED_ELEMENTS['I.C'] and 'PH.I.D.S5' in a.VERIFIED_ELEMENTS['I.D']
def test_current_weather_and_chart_courses_integrated():
 t=(R/'app/academy.py').read_text(encoding='utf-8')
 assert '2026 FAA Weather Mastery' in t and 'FAA-H-8083-28B' in t
 assert '2026 FAA Chart Literacy' in t and 'effective 9 Jul 2026' in t
def test_flight_planning_is_acs_coded():
 h=(R/'app/templates/flight_planner.html').read_text(encoding='utf-8')
 for x in ('PH.I.D.S1','PH.I.D.S2','PH.I.D.K3','PH.I.D.R1-R7','PH.I.C.R1'): assert x in h
def test_study_shows_acs_mapping_and_task_pages_exist():
 h=(R/'app/templates/study.html').read_text(encoding='utf-8');m=(R/'app/main.py').read_text(encoding='utf-8')
 assert '{{acs_tag}}' in h and "@app.get('/acs-task/{area}/{task}'" in m
def test_flashcard_srs_progress_key_not_bumped():
 j=(R/'app/static/flashcards.js').read_text(encoding='utf-8'); assert "r22-flashcards-srs-v1" in j
