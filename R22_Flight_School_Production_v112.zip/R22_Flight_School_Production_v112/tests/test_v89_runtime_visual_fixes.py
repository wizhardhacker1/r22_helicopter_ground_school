from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')
def test_motion_uses_side_profile_and_no_concept_mechanism():
 h=t('app/templates/rotor_controls.html')
 assert 'r22_side_profile_v88.jpg?v=112' in h
 assert 'mechanism-window' not in h and 'thrust-vector' not in h and 'yaw-vector' not in h
 assert 'rotor_motion_v91.js?v=112' in h
def test_motion_registers_real_side_view_positions_and_moves_controls():
 c=t('app/static/app.css'); j=t('app/static/rotor_motion_v89.js')
 assert 'left:67.2%' in c and 'left:10.9%' in c
 for x in ['--collective','--cy-x','--cy-y','--pedal']: assert x in j
def test_component_lab_does_not_use_concept_dashboard_image():
 h=t('app/templates/rotor_components.html')
 assert 'rotor_trainer_reference.png' not in h
 assert 'rotor_trainer_v82.png?v=112' in h
 assert 'labCollective' in h and 'labCyclic' in h and 'START GUIDED LESSON' in h
def test_startup_has_one_visible_panel_and_legacy_hidden():
 h=t('app/templates/startup.html'); c=t('app/static/app.css')
 assert h.count('photo-cockpit-live startup-photo-cockpit')==1
 assert 'legacy-state-panel' in h and '.legacy-state-panel{display:none!important}' in c
 assert 'photo-hotspots' in h
def test_flow_has_one_visible_photo_panel_and_legacy_hidden():
 h=t('app/templates/checklists.html')
 assert h.count('photo-cockpit-live flow-photo-cockpit')==1
 assert 'legacy-state-panel' in h and 'photo-hotspots' in h
def test_live_panel_state_drives_needles_and_lamps():
 s=t('app/static/startup.js'); f=t('app/static/checklists.js')
 assert 'startupPhotoRpm' in s and 'startupPhotoEngine' in s and "startupPhotoLow')?.classList.toggle('on'" in s
 assert 'flowPhotoRpm' in f and 'flowPhotoEngine' in f and "govoff:'flowPhotoAlt'" in f
def test_no_old_concept_asset_in_component_template():
 assert 'rotor_trainer_reference.png' not in t('app/templates/rotor_components.html')
def test_flow_photo_is_outside_hidden_legacy_panel():
 h=t('app/templates/checklists.html')
 assert h.index('photo-cockpit-live flow-photo-cockpit') < h.index('legacy-state-panel')
