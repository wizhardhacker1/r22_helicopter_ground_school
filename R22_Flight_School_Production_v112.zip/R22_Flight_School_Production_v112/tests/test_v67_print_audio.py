from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_v67_has_two_dedicated_professional_print_sheets():
    a=(R/'app/templates/checklist_reference.html').read_text(encoding='utf-8')
    b=(R/'app/templates/startup_reference.html').read_text(encoding='utf-8')
    css=(R/'app/static/app.css').read_text(encoding='utf-8')
    assert 'aviation-sheet' in a and 'aviation-sheet' in b
    assert '@page{size:letter landscape' in css
    assert 'height:7.88in' in css and 'overflow:hidden' in css
    assert '/checklist-reference/print' in a and 'no-print' in b
def test_v67_startup_reference_has_own_route():
    m=(R/'app/main.py').read_text(encoding='utf-8')
    s=(R/'app/templates/startup.html').read_text(encoding='utf-8')
    assert "@app.get('/startup-reference'" in m
    assert 'href="/startup-reference"' in s and 'href="/startup-reference" target="_blank"' not in s
def test_v67_audio_is_trimmed_middle_loop():
    f=R/'app/static/audio/r22_helicopter_running.mp3'
    assert f.exists() and 800000 < f.stat().st_size < 1100000
    data=f.read_bytes()
    # Pure-Python MP3 frame scan: no ffmpeg/ffprobe dependency on student PCs.
    i=0
    if data[:3]==b'ID3' and len(data)>=10:
        sz=((data[6]&0x7f)<<21)|((data[7]&0x7f)<<14)|((data[8]&0x7f)<<7)|(data[9]&0x7f)
        i=10+sz
    br={1:{1:[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320],2:[0,32,48,56,64,80,96,112,128,160,192,224,256,320,384],3:[0,32,40,48,56,64,80,96,112,128,160,192,224,256,320]},2:{1:[0,32,48,56,64,80,96,112,128,144,160,176,192,224,256],2:[0,8,16,24,32,40,48,56,64,80,96,112,128,144,160],3:[0,8,16,24,32,40,48,56,64,80,96,112,128,144,160]}}
    srbase=[44100,48000,32000]; seconds=0.0; frames=0
    while i+4<=len(data):
        h=int.from_bytes(data[i:i+4],'big')
        if (h>>21)&0x7ff != 0x7ff: i+=1; continue
        ver=(h>>19)&3; layerbits=(h>>17)&3; bi=(h>>12)&15; si=(h>>10)&3; pad=(h>>9)&1
        if ver==1 or layerbits==0 or bi in (0,15) or si==3: i+=1; continue
        version=1 if ver==3 else 2; layer=4-layerbits
        sr=srbase[si]//(1 if ver==3 else (2 if ver==2 else 4))
        kb=br[version][layer][bi]
        samples=384 if layer==1 else (1152 if layer==2 or ver==3 else 576)
        flen=((12*kb*1000//sr)+pad)*4 if layer==1 else ((144 if (layer==2 or ver==3) else 72)*kb*1000//sr)+pad
        seconds += samples/sr; frames+=1; i+=max(flen,1)
    assert frames>100 and 25.5 < seconds < 26.7
    for name in ('startup.js','checklists.js'):
        s=(R/'app/static'/name).read_text(encoding='utf-8')
        assert '/static/audio/r22_helicopter_running.mp3?v=76' in s and 'loop=true' in s
