from pathlib import Path

def t(p): return Path(p).read_text(encoding='utf-8')

def test_small_valid_png_tiles_are_not_rejected_by_size():
    s=t('app/main.py')
    assert "os.path.getsize(path)<64" in s
    assert "os.path.getsize(path)>100000" not in s
    assert 'im.verify()' in s

def test_palette_faa_geotiff_is_rendered_to_rgb():
    s=t('app/main.py')
    assert 'src.colormap(1)' in s
    assert "Image.fromarray(rgb,'RGB')" in s
    assert 'Resampling.nearest' in s

def test_edge_tiles_use_actual_dimensions():
    js=t('app/static/navigation_charts.js')
    css=t('app/static/app.css')
    assert "Math.min(manifest.tile_size,l.width-x*manifest.tile_size)" in js
    assert "Math.min(manifest.tile_size,l.height-y*manifest.tile_size)" in js
    assert '.faa-tile-layer img{position:absolute;width:512px;height:512px' not in css


def test_student_chart_lab_has_no_install_refresh_button_and_has_all_three_products():
    h=t('app/templates/navigation_charts.html')
    assert 'Install / Refresh FAA Charts' not in h
    assert 'Los Angeles Sectional' in h and 'Los Angeles TAC' in h and 'Los Angeles Helicopter Route Chart' in h
    assert 'Re-run the application installer' in h
