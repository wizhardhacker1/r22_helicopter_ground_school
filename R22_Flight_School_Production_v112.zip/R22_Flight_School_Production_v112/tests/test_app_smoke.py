import os, shutil
from pathlib import Path
# Tests MUST use an isolated disposable database. Never inherit the installed
# application's R22_DATA_DIR/DATABASE_URL because that can point at live user data.
TEST_DATA = Path('.testdata').resolve()
shutil.rmtree(TEST_DATA, ignore_errors=True)
TEST_DATA.mkdir(parents=True, exist_ok=True)
os.environ['R22_DATA_DIR'] = str(TEST_DATA)
os.environ['DATABASE_URL'] = f"sqlite:///{(TEST_DATA / 'r22school.db').as_posix()}"
os.environ['SECRET_KEY'] = 'test-secret-key-that-is-at-least-32-characters-long'
from fastapi.testclient import TestClient
from app.main import app, startup
from app.db import SessionLocal
from app.models import User
from app.auth import token

def auth_client():
    startup(); db=SessionLocal(); u=db.query(User).filter(User.username=='admin').first(); uid=u.id; role=u.role; db.close()
    c=TestClient(app); c.cookies.set('session',token(uid,role)); return c

def test_public_login_and_health():
    startup(); c=TestClient(app)
    assert c.get('/').status_code==200
    assert c.get('/login').status_code==200
    r=c.get('/health'); assert r.status_code==200 and r.json()['ok'] is True

def test_authenticated_ui_routes():
    c=auth_client()
    routes=['/dashboard','/syllabus','/lesson/orientation','/knowledge','/study?track=R22','/study?track=PPL','/study?track=IFR','/performance','/startup','/charts','/aircraft','/checklists','/emergency','/atc','/oral','/readiness','/logbook','/tracker','/exam?track=PPL&count=10','/profile','/academy','/academy/radio','/academy/weatherbrief','/academy/hovercheck','/academy/annunciators','/admin','/instructor']
    for route in routes:
        r=c.get(route); assert r.status_code==200, (route,r.status_code,r.text[:300])

def test_poh_and_manifest():
    c=auth_client()
    assert c.get('/poh').status_code==200
    assert c.get('/manifest.webmanifest').status_code==200

def test_core_json_apis():
    c=auth_client()
    r=c.post('/api/performance',json={'elevation':5000,'altimeter':29.92,'oat_c':20}); assert r.status_code==200 and 'density_altitude' in r.json()
    r=c.post('/api/fuel',json={'main_gal':10,'aux_gal':5,'fuel_flow_gph':9,'planned_minutes':60,'reserve_minutes':20}); assert r.status_code==200
    r=c.post('/api/e6b',json={'cas':80,'pressure_altitude_ft':5000,'oat_c':15,'true_course':90,'wind_from':180,'wind_speed':15,'distance_nm':50,'variation_deg':10,'deviation_deg':2}); assert r.status_code==200 and 'compass_heading' in r.json()
    r=c.post('/api/atc',json={'scenario':'taxi','message':'Helicopter 22BH runway 30 via Alpha hold short runway 30'}); assert r.status_code==200 and r.json()['score']>=75

def test_real_login_flow_and_security_headers():
    startup(); c=TestClient(app)
    r=c.get('/login'); assert r.status_code==200 and 'csrf' in c.cookies
    r=c.post('/login',data={'username':'admin','password':'ChangeMe123!','csrf':c.cookies['csrf']},follow_redirects=False)
    assert r.status_code==303 and r.headers['location']=='/profile'
    assert 'session' in c.cookies
    r=c.get('/profile'); assert r.status_code==200 and r.headers.get('x-frame-options')=='DENY' and r.headers.get('cache-control')=='no-store'

def test_wb_three_states_and_standard_requires_chart_verification():
    c=auth_client()
    r=c.post('/api/wb',json={'empty_weight':880,'empty_arm':104,'pilot':170,'passenger':160,'left_bag':0,'right_bag':0,'main_fuel':16.9,'aux_fuel':9.4,'fuel_burn_gal':8,'model':'Beta II'})
    assert r.status_code==200 and all(k in r.json() for k in ('takeoff','landing','zero_fuel'))
    r=c.post('/api/wb',json={'empty_weight':800,'empty_arm':100,'pilot':170,'passenger':160,'left_bag':0,'right_bag':0,'main_fuel':10,'aux_fuel':5,'fuel_burn_gal':5,'model':'Standard'})
    assert r.status_code==200 and r.json()['takeoff']['cg_status']=='calculated_against_poh_section_2_envelope' and isinstance(r.json()['all_checked_states_in_limits'], bool)

def test_backup_ui_create_download_and_integrity():
    c=auth_client(); r=c.get('/admin/backups'); assert r.status_code==200 and 'Backup & Restore' in r.text
    csrf=c.cookies['csrf']; r=c.post('/admin/backups/create',data={'csrf':csrf},follow_redirects=False); assert r.status_code==303
    import glob,sqlite3,os
    from app.main import _backup_dir
    files=sorted(glob.glob(os.path.join(_backup_dir(),'r22school_*.db'))); assert files
    con=sqlite3.connect(files[-1]); assert con.execute('PRAGMA integrity_check').fetchone()[0]=='ok'; con.close()
    name=os.path.basename(files[-1]); assert c.get('/admin/backups/'+name+'/download').status_code==200

def test_exam_auto_rotation_and_answer_review():
    c=auth_client(); r=c.get('/exam?track=R22&count=5&minutes=5'); assert r.status_code==200 and 'Automatic rotation' in r.text
    import re
    qids=re.findall(r"name=qid value='([0-9]+)'",r.text); assert len(qids)==5
    csrf=c.cookies['csrf']; data=[('csrf',csrf),('track','R22')]+[('qid',q) for q in qids]
    # httpx accepts dict more reliably; submit first answer for each question and allow unanswered remainder.
    form={'csrf':csrf,'track':'R22'}
    for q in qids: form.setdefault('qid',[])
    # use encoded list of tuples through request content
    from urllib.parse import urlencode
    pairs=[('csrf',csrf),('track','R22')]+[('qid',q) for q in qids]+[(f'q_{q}','A') for q in qids]
    rr=c.post('/exam/grade',content=urlencode(pairs),headers={'content-type':'application/x-www-form-urlencoded'}); assert rr.status_code==400
    r2=c.get('/exam?track=R22&count=5&minutes=5'); qids2=re.findall(r"name=qid value='([0-9]+)'",r2.text); assert len(qids2)==5


def test_passing_exam_issues_printable_certificate():
    c=auth_client()
    c.get('/exams')
    from app.db import SessionLocal
    from app.models import Question, Certificate, User
    db=SessionLocal(); u=db.query(User).filter_by(username='admin').first(); uid=u.id; qs=db.query(Question).filter_by(track='R22',active=True).limit(10).all(); pairs=[('csrf',c.cookies['csrf']),('track','R22')]
    for q in qs:
        pairs += [('qid',str(q.id)),(f'q_{q.id}',q.correct)]
    db.close()
    from urllib.parse import urlencode
    r=c.post('/exam/grade',content=urlencode(pairs),headers={'content-type':'application/x-www-form-urlencoded'})
    assert r.status_code==200 and 'View Certificate' in r.text and '100.0% - PASS' in r.text
    db=SessionLocal(); cert=db.query(Certificate).filter_by(user_id=uid).order_by(Certificate.id.desc()).first(); assert cert and cert.certificate_code.startswith('R22FS-'); cid=cert.id; code=cert.certificate_code; db.close()
    r=c.get(f'/certificate/{cid}'); assert r.status_code==200 and 'Certificate of Training Achievement' in r.text and 'Print / Save as PDF' in r.text
    r=c.get('/certificates'); assert r.status_code==200 and code in r.text
    r=c.get(f'/verify-certificate/{code}'); assert r.status_code==200 and 'Valid R22 Flight School training certificate' in r.text

def test_v16_navigation_and_startup_workspace_present():
    base=Path('app/templates/base.html').read_text(encoding='utf-8')
    startup_tpl=Path('app/templates/startup.html').read_text(encoding='utf-8')
    startup_js=Path('app/static/startup.js').read_text(encoding='utf-8')
    css=Path('app/static/app.css').read_text(encoding='utf-8')
    assert 'Settings & Profile' in base
    assert 'liveChecklist' in startup_tpl
    assert 'identifyMode' in startup_tpl and 'identify-mode' in css
    assert "height:100vh!important" in css and "overflow-y:scroll!important" in css
    assert 'Governor' in startup_js and "'ON','control'" in startup_js

def test_v17_full_cockpit_and_clickable_checklist():
    from pathlib import Path
    tpl=Path('app/templates/startup.html').read_text(encoding='utf-8')
    js=Path('app/static/startup.js').read_text(encoding='utf-8')
    css=Path('app/static/app.css').read_text(encoding='utf-8')
    assert 'r22-main-panel' in tpl and 'r22-pedestal' in tpl and 'r22-breakers' in tpl
    assert 'Fuel shut-off valve' in tpl and 'Circuit breakers' in tpl and 'Altimeter' in tpl
    assert 'data-step=' in js and 'focusStep' in js
    assert 'selected-control' in css and '.live-check' in css
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'startup.js?v={v}' in tpl
    assert 'attitude-face' in tpl and 'pitch ladder' not in tpl.lower()


def test_v18_visual_trainers():
    from pathlib import Path
    t=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    assert "real-r22-preflight" in t and "R22 COCKPIT FLOW TRAINER" in t
    assert "heli-cabin" not in t
    assert 'data-zone="tailrotor"' in t and 'data-control="Circuit breakers"' in t


def test_v20_topdown_preflight_and_clickable_reference():
    from pathlib import Path
    t=Path("app/templates/checklists.html").read_text(encoding="utf-8")
    j=Path("app/static/checklists.js").read_text(encoding="utf-8")
    assert "PERSPECTIVE TRAINING VIEW" in t
    assert "data-zone=\"tailrotor\"" in t and "data-zone=\"mainrotor\"" in t
    assert "data-step-index" in j

def test_faa_acs_coverage_matrix_is_complete_at_task_level():
 from app.acs import coverage_rows, ACS_AREAS
 rows=coverage_rows()
 assert len(ACS_AREAS)==10
 assert len(rows)==49
 assert all(r['resources'] for r in rows)
 assert all(r['status'] in ('integrated','n/a') for r in rows)
 assert any(r['na'] for r in rows)  # multiengine-only task is explicitly N/A to R22

def test_interactive_trainers_have_learn_practice_test_modes():
 from pathlib import Path
 startup=Path('app/templates/startup.html').read_text(encoding='utf-8')
 checks=Path('app/templates/checklists.html').read_text(encoding='utf-8')
 js=Path('app/static/startup.js').read_text(encoding='utf-8')+Path('app/static/checklists.js').read_text(encoding='utf-8')
 for label in ('Learn','Practice','Test'):
  assert label in startup and label in checks
 assert "module:'startup'" in js and "module:'cockpit_flow'" in js
 assert 'completed-control' in Path('app/static/app.css').read_text(encoding='utf-8')

def test_v22_navigation_chart_school():
    from pathlib import Path
    tpl=Path('app/templates/navigation_charts.html').read_text(encoding='utf-8')
    js=Path('app/static/navigation_charts.js').read_text(encoding='utf-8')
    base=Path('app/templates/base.html').read_text(encoding='utf-8')
    acs=Path('app/acs.py').read_text(encoding='utf-8')
    assert 'Learn' in tpl and 'Practice' in tpl and 'Test' in tpl
    assert 'FAA VFR Digital Products' in tpl and 'Aeronautical Chart' in tpl
    assert 'Sectional fundamentals' in tpl and 'Helicopter charts' in tpl and 'Cross-country workflow' in tpl
    assert 'Navigation & FAA Charts' in base and '/navigation-charts' in base
    assert 'Navigation & FAA Charts' in acs
    assert '/api/training/interactive' in js
    assert 'Maximum Elevation Figure' in js and 'Chart Supplement' in js

def test_v22_service_worker_cache_bumped():
    from pathlib import Path
    sw=Path('app/static/sw.js').read_text(encoding='utf-8')
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'r22-school-v{v}-static' in sw and f'navigation_charts.js?v={v}' in sw

def test_v23_readability_chart_walkaround_and_performance_sources():
    from pathlib import Path
    css=Path('app/static/app.css').read_text(encoding='utf-8')
    nav=Path('app/templates/navigation_charts.html').read_text(encoding='utf-8')
    chk=Path('app/templates/checklists.html').read_text(encoding='utf-8')
    perf=Path('app/templates/performance.html').read_text(encoding='utf-8')
    js=Path('app/static/checklists.js').read_text(encoding='utf-8')
    assert 'grid-template-columns:38px minmax(0,1fr)' in css
    assert 'REAL FAA CHART LAB' in nav and 'faaTileLayer' in nav
    assert 'ACTIVE CHECKLIST' in chk and 'orbitAngle' in chk and 'setOrbit' in js
    assert 'POH PERFORMANCE RULES' in perf and 'model-specific performance charts' in perf
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'app.css?v={v}' in Path('app/templates/base.html').read_text(encoding='utf-8')

def test_v23_performance_model_chart_mapping_present():
    from pathlib import Path
    js=Path('app/static/app.js').read_text(encoding='utf-8')
    for img in ('p75.jpg','p76.jpg','p77.jpg','p78.jpg'):
        assert img in js


def test_v24_walkaround_js_parses_and_has_single_orbit_binding():
    from pathlib import Path
    js=Path('app/static/checklists.js').read_text(encoding='utf-8')
    assert js.count("const orbit=document.getElementById('orbitStage')")==1
    assert "orbitLeft" in js and "orbitRight" in js and "orbitReset" in js

def test_v24_short_activity_cannot_become_exam_or_certificate():
    c=auth_client(); import re
    r=c.get('/exam?track=R22&count=5&minutes=5')
    qids=re.findall(r"name=qid value='([0-9]+)'",r.text)
    from urllib.parse import urlencode
    pairs=[('csrf',c.cookies['csrf']),('track','R22')]+[('qid',q) for q in qids]
    rr=c.post('/exam/grade',content=urlencode(pairs),headers={'content-type':'application/x-www-form-urlencoded'})
    assert rr.status_code==400

def test_v24_readability_and_cache_version():
    from pathlib import Path
    css=Path('app/static/app.css').read_text(encoding='utf-8')
    base=Path('app/templates/base.html').read_text(encoding='utf-8')
    assert 'flex:0 0 36px' in css and 'grid-template-columns:1fr!important' in css
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'app.css?v={v}' in base and f'sw.js?v={v}' in base

def test_v25_performance_pad_has_detailed_teaching_guide_and_no_raw_e6b_renderer():
    from pathlib import Path
    tpl=Path('app/templates/performance.html').read_text(encoding='utf-8')
    js=Path('app/static/app.js').read_text(encoding='utf-8')
    assert 'HOW TO USE THE PAD' in tpl
    assert 'What you are doing' in tpl and 'Worked training example' in tpl
    assert 'POH \xa7\xa72, 5 & 6' in tpl
    assert "e6bout.textContent=JSON.stringify" not in js
    assert 'Fly compass heading' in js
    assert 'computeFlightBtn' in tpl and 'onclick="return computeFlightNow(event)"' in tpl
    assert 'src="/static/app.js' not in tpl  # base loads app.js exactly once

def test_v25_dashboard_filters_short_diagnostic_exams_and_completion_is_verified():
    from pathlib import Path
    main=Path('app/main.py').read_text(encoding='utf-8')
    syllabus=Path('app/templates/syllabus.html').read_text(encoding='utf-8')
    assert 'Exam.total>=10' in main
    assert 'roadmap completion is earned' in main
    assert "lesson_key=key,completed=True" in main
    assert 'Check earned completion' in syllabus
    assert 'Opening a page or clicking around does not count' in syllabus

def test_v25_interactive_completion_requires_all_steps():
    from pathlib import Path
    main=Path('app/main.py').read_text(encoding='utf-8')
    startup=Path('app/static/startup.js').read_text(encoding='utf-8')
    checks=Path('app/static/checklists.js').read_text(encoding='utf-8')
    assert 'completed>=total and score>=70' in main
    assert 'total:steps.length' in startup
    assert 'total:flow().steps.length' in checks


def test_v28_admin_can_clear_own_training_stats_and_import_templates_present():
    from pathlib import Path
    t=Path('app/templates/admin.html').read_text(encoding='utf-8')
    assert 'Clear Training Stats' in t
    assert '/admin/training/reset/{{x.id}}' in t
    assert '/admin/questions/template.csv' in t and '/admin/questions/template.txt' in t

def test_v28_cockpit_click_feedback_colors_and_atc_beginner_examples():
    from pathlib import Path
    css=Path('app/static/app.css').read_text(encoding='utf-8')
    sj=Path('app/static/startup.js').read_text(encoding='utf-8')
    cj=Path('app/static/checklists.js').read_text(encoding='utf-8')
    atc=Path('app/templates/atc.html').read_text(encoding='utf-8')
    tr=Path('app/training.py').read_text(encoding='utf-8')
    assert '.wrong-control' in css and '.order-control' in css and '.completed-control' in css
    assert 'wrong-control' in sj and 'order-control' in sj
    assert 'wrong-control' in cj and 'order-control' in cj
    assert 'WHAT SHOULD I SAY?' in atc and 'Example pilot transmission' in atc
    assert '_ATC_TEACH' in tr and 'Build the call' not in tr

def test_v29_first_study_answer_creates_mastery_without_server_error():
    from app.models import Question, Mastery
    c=auth_client(); db=SessionLocal(); q=db.query(Question).filter(Question.active==True).first(); qid=q.id; correct=q.correct; area=q.area; db.close()
    c.get('/study?track=R22'); csrf=c.cookies['csrf']
    r=c.post(f'/answer/{qid}',data={'selected':correct,'track':'R22','csrf':csrf})
    assert r.status_code==200 and 'Correct' in r.text
    db=SessionLocal(); u=db.query(User).filter(User.username=='admin').first(); m=db.query(Mastery).filter_by(user_id=u.id,area=area).first(); assert m is not None and m.seen>=1; db.close()

def test_v29_performance_ui_has_no_orphan_plus_marker_and_map_readout():
    c=auth_client(); r=c.get('/performance'); assert r.status_code==200
    assert 'chartMarker' not in r.text and 'mapLimitText' in r.text and 'input-unit' in r.text
    js=Path('app/static/app.js').read_text(encoding='utf-8')
    assert 'beta2MapLimit' in js and 'maximum continuous MAP' in js


def test_v30_compute_flight_is_self_contained_and_visible():
    from pathlib import Path
    tpl=Path('app/templates/performance.html').read_text(encoding='utf-8')
    assert 'computeFlightNow(event)' in tpl
    assert "fetch('/api/e6b'" in tpl
    assert 'Computing flight plan' in tpl
    assert 'FLIGHT PLANNING RESULT' in tpl
    assert 'Flight computer error:' in tpl

def test_v30_service_worker_does_not_pin_old_app_js():
    from pathlib import Path
    sw=Path('app/static/sw.js').read_text(encoding='utf-8')
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'r22-school-v{v}-static' in sw
    assert f'/static/app.js?v={v}' in sw
    assert '/static/app.js?v=28' not in sw


def test_v31_real_r22_preflight_photo_and_interactive_hotspots():
    from pathlib import Path
    tpl=Path('app/templates/checklists.html').read_text(encoding='utf-8')
    asset=Path('app/static/r22_preflight_three_view.jpg')
    assert asset.exists() and asset.stat().st_size > 100000
    v=Path('VERSION').read_text(encoding='utf-8').strip(); assert f'/static/r22_preflight_three_view.jpg?v={v}' in tpl
    assert 'r22-top-svg' not in tpl
    for zone in ['cowl','right','rear','emp','tailrotor','left','mainfuel','mainrotor','fuselageleft','nose','fuselageright','cabin']:
        assert f'data-zone="{zone}"' in tpl
    js=Path('app/static/checklists.js').read_text(encoding='utf-8')
    assert 'wrong-control' in js and 'order-control' in js and 'completed-control' in js


def test_v32_interactive_chart_and_100_percent_acs_gate():
 from pathlib import Path
 nav=Path('app/templates/navigation_charts.html').read_text(encoding='utf-8')
 js=Path('app/static/navigation_charts.js').read_text(encoding='utf-8')
 acs=Path('app/templates/acs_coverage.html').read_text(encoding='utf-8')
 assert 'faaTileLayer' in nav and 'Los Angeles TAC' in nav and 'Install / Refresh FAA Charts' not in nav
 assert 'chart-hotspot' not in nav
 assert 'refreshChartStatus' in js and 'showChart' in js
 assert 'ALL APPLICABLE TASKS ROUTED TO TRAINING' in acs
 assert 'KNOWLEDGE * source-grounded instruction/questions' in acs and 'RISK * scenario decision practice' in acs and 'CFI/DPE FLIGHT GATE' in acs

def test_chart_lab_uses_real_chart_not_schematic():
    c=auth_client(); r=c.get('/navigation-charts')
    assert r.status_code == 200
    assert 'faa_sectional_training.svg' not in r.text and 'Official FAA chart training media is unavailable.' in r.text
    assert 'Schematic VFR sectional' not in r.text
    assert 'Install / Refresh FAA Charts' not in r.text and 'Re-run the application installer' in r.text

def test_default_admin_hint_disappears_after_password_change():
    startup(); db=SessionLocal(); u=db.query(User).filter(User.username=='admin').first(); from app.auth import hash_password
    u.password_hash=hash_password('DifferentPass123!'); u.must_change_password=False; db.commit(); db.close()
    c=TestClient(app); r=c.get('/')
    assert 'ChangeMe123!' not in r.text

def test_v34_long_beach_chart_updater_and_live_cg_defaults():
    from pathlib import Path
    nav=Path('app/templates/navigation_charts.html').read_text(encoding='utf-8')
    perf=Path('app/templates/performance.html').read_text(encoding='utf-8')
    appjs=Path('app/static/app.js').read_text(encoding='utf-8')
    pjs=Path('app/static/performance_v12.js').read_text(encoding='utf-8')
    admin=Path('app/templates/admin.html').read_text(encoding='utf-8')
    main=Path('app/main.py').read_text(encoding='utf-8')
    assert 'faa_sectional_training.svg' not in nav and 'Los Angeles Sectional' in nav
    assert "['empty_weight',800]" in appjs and "['empty_arm',103.8]" in appjs
    assert "['pilot',150]" in appjs and "['passenger',120]" in appjs
    assert "addEventListener('input',fire)" in pjs
    assert 'FAA CONTENT & UPDATES' in admin and '/admin/faa-content/update' in admin
    assert "from .faa_content import install_long_beach_chart" in main
    assert 'aeronav.faa.gov/visual/09-03-2026/sectional-files/Los_Angeles.zip' in Path('app/faa_content.py').read_text(encoding='utf-8')
    assert 'input-unit' in perf


def test_v35_loading_sliders_are_live_and_clickable():
    from pathlib import Path
    perf=Path('app/templates/performance.html').read_text(encoding='utf-8')
    js=Path('app/static/performance_v12.js').read_text(encoding='utf-8')
    css=Path('app/static/app.css').read_text(encoding='utf-8')
    appjs=Path('app/static/app.js').read_text(encoding='utf-8')
    for control in ['vis_pilot','vis_passenger','vis_left_bag','vis_right_bag','vis_fuel']:
        assert f'id="{control}"' in perf
    assert "range.addEventListener('input',fromRange)" in js
    assert "fuel.addEventListener('input',syncFuel)" in js
    assert '.heli-visual>svg{pointer-events:none}' in css
    assert "document.getElementById('model')?.value" in appjs

def test_v35_all_template_static_scripts_exist():
    from pathlib import Path
    import re
    for tpl in Path('app/templates').glob('*.html'):
        txt=tpl.read_text(encoding='utf-8')
        for src in re.findall(r'<script[^>]+src=["\']([^"\']+)',txt):
            if src.startswith('/static/'):
                rel=src.split('/static/',1)[1].split('?',1)[0]
                assert (Path('app/static')/rel).exists(), (tpl.name,src)
