from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_real_chart_canvas_not_pdf_iframe():
 h=(ROOT/'app/templates/navigation_charts.html').read_text(encoding='utf-8')
 j=(ROOT/'app/static/navigation_charts.js').read_text(encoding='utf-8')
 assert 'faaTileLayer' in h and 'faaMapViewport' in h
 assert 'faa-chart-tile' in j and 'faaChartPdf' not in j
 assert 'wheel' in j and 'pointermove' in j and 'mapZoomIn' in j
def test_official_geotiff_sources_and_validation():
 s=(ROOT/'app/main.py').read_text(encoding='utf-8')
 assert 'sectional-files/Los_Angeles.zip' in s
 assert 'heli_files/Los_Angeles_Heli.zip' in s
 assert 'rasterio' in s and '_valid_png' in s
 assert '_valid_png' in s
