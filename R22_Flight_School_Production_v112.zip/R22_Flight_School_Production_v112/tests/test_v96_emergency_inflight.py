from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding='utf-8')
def test_emergency_static_cockpit_is_not_cold_dark():
 h=t("app/templates/emergency.html")
 for x in ["ENGINE RUNNING","E 104% * R 104%","70 KIAS","1000 FT AGL","55 PSI","FULL RICH","ROTOR BRAKE</span><b>RELEASED"]:
  assert x in h
 assert "ENGINE STOPPED" not in h and "E 0% * R 0%" not in h
def test_emergency_has_separate_normal_flight_and_fault_states():
 j=t("app/static/emergency_v87.js")
 assert "const base=(asi=70,alt=900,map=20)=>({er:104,rr:104" in j
 assert "function normalFlight()" in j and "function injectFault()" in j
 assert "function setInitial()" in j and "normalFlight();injectFault()" in j
def test_scenario_actions_change_live_cockpit():
 j=t("app/static/emergency_v87.js")
 for x in ["setControl('Collective','LOWERED')","setControl('Pedals','RIGHT INPUT')","setControl('Governor','OFF')","setControl('Throttle','MANUAL CONTROL')","lamp('lowrpm',false)"]:
  assert x in j
def test_emergency_not_mislabeled_as_new_flight_training_nav_group():
 h=t("app/templates/base.html")
 assert "<summary>FLIGHT TRAINING</summary>" not in h
 assert "SAFETY & FLIGHT LABS" in h
