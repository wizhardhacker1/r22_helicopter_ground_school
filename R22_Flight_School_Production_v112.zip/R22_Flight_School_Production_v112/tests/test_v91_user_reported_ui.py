from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')
def test_menu_has_no_literal_unicode_escape():
 c=t('app/static/app.css'); assert "content:'\\u203a'" not in c and "content:'>'" in c
def test_startup_and_flow_reverted_to_original_cockpit():
 c=t('app/static/app.css'); assert '.startup-photo-cockpit,.flow-photo-cockpit{display:none!important}' in c
 assert '.startup-layout .legacy-state-panel,.startup-cockpit-reuse .legacy-state-panel{display:block!important}' in c
def test_side_view_overlay_shares_image_coordinate_stage():
 h=t('app/templates/rotor_controls.html'); c=t('app/static/app.css')
 assert 'side-image-stage' in h and 'aspect-ratio:1190/770' in c
 assert 'left:10.9%!important;top:36.4%!important' in c
def test_pedals_move_and_component_lab_teaches_tail_rotor():
 j=t('app/static/rotor_motion_v91.js'); h=t('app/templates/rotor_components.html'); cj=t('app/static/rotor_components_v91.js')
 assert '--pedal-left' in j and '--pedal-right' in j
 assert 'labPedals' in h and 'PEDALS / TAIL ROTOR' in h and 'tail-rotor' in h.lower()
 assert 'labTailRotor' in cj and 'labPedalVisual' in cj
