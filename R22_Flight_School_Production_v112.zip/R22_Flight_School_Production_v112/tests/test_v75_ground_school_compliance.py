from pathlib import Path
import importlib.util
R=Path(__file__).resolve().parents[1]
def load():
 spec=importlib.util.spec_from_file_location('gs',R/'app/ground_school.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def test_35_hour_rotorcraft_ground_syllabus():
 m=load(); assert m.PART141_GROUND_HOURS==35.0; assert sum(x['hours'] for x in m.GROUND_MODULES)==35.0; assert len(m.GROUND_MODULES)==14
def test_all_applicable_61105_knowledge_areas_are_crosswalked():
 m=load(); codes={x[0] for x in m.PART61_KNOWLEDGE}; assert len(codes)==12; assert '61.105(b)(1)' in codes and '61.105(b)(13)' in codes
def test_61107_helicopter_flight_areas_are_explicit_cfi_gates():
 m=load(); assert len(m.FLIGHT_AREAS)==10; assert 'Hovering maneuvers' in m.FLIGHT_AREAS and 'Emergency operations' in m.FLIGHT_AREAS
def test_61109_helicopter_experience_gate_present():
 m=load(); txt=' '.join(m.EXPERIENCE_61_109); assert '40 total hours' in txt and '100 NM' in txt and '25 NM' in txt and 'operating control tower' in txt
def test_part141_approval_claim_is_bounded():
 h=(R/'app/templates/ground_school_compliance.html').read_text(encoding='utf-8'); assert 'not FAA-approved until' not in h; assert 'does <b>not</b> mean this software is itself an FAA-certificated Part 141 school' in h; assert '35.0-hour syllabus' in h
def test_part141_stage_checks_and_records_are_release_gates():
 m=load(); txt=' '.join(m.PART141_APPROVAL_GATES); assert 'Stage' in txt and 'Chronological attendance' in txt and len(m.STAGES)==3
def test_srs_progress_key_not_bumped_by_v75():
 j=(R/'app/static/flashcards.js').read_text(encoding='utf-8'); assert "r22-flashcards-srs-v1" in j
