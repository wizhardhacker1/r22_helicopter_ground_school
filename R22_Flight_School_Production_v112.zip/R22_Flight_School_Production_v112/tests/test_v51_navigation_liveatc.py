from pathlib import Path

def t(p): return Path(p).read_text(encoding='utf-8')

def test_nav_has_no_academy_course_bounce_links():
    base=t('app/templates/base.html')
    assert 'href=/academy/radio' not in base
    assert 'href=/academy/weatherbrief' not in base
    assert 'href=/academy/hovercheck' not in base
    assert 'href=/academy/oral' not in base
    assert 'href=/academy>' in base and '<span>R22 Academy</span>' in base

def test_nav_persists_group_and_scroll():
    base=t('app/templates/base.html')
    assert 'r22.nav.group' in base and 'r22.nav.scroll' in base
    assert 'activeGroup' in base and 'sessionStorage' in base and 'localStorage' in base

def test_liveatc_is_external_only_and_offline_library_is_primary():
    academy=t('app/templates/academy.html'); atc=t('app/templates/atc.html'); main=t('app/main.py')
    assert '<iframe class="live-atc-frame"' not in academy and '<iframe class="live-atc-frame"' not in atc
    assert "@app.get('/connected/live-atc')" in main
    assert 'Helicopter ATC Listening Library' in atc
    assert 'does not depend on an online speech service' in atc
    assert 'not represented as captured FAA transmissions' in atc

def test_academy_delivers_course_not_menu_redirect():
    a=t('app/templates/academy.html')
    assert 'Class structure:' in a and 'Teach' in a and 'Apply it' in a and 'Recall check' in a
    assert 'Verify course completion' in a
