from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_checkride_center_and_owned_source_features():
 m=(R/'app/main.py').read_text(encoding='utf-8'); b=(R/'app/templates/base.html').read_text(encoding='utf-8'); assert "/checkride-center" in m and "/flashcards" in m and "/vfr-reference" in m and "/checklist-reference" in m; assert 'Checkride Center' in b
def test_logbook_expanded_and_migrated():
 m=(R/'app/main.py').read_text(encoding='utf-8'); model=(R/'app/models.py').read_text(encoding='utf-8'); t=(R/'app/templates/logbook.html').read_text(encoding='utf-8');
 for x in ['ground_trainer_hours','cross_country_hours','actual_instrument_hours','simulated_instrument_hours','day_landings','night_landings','total_duration','instructor_approval']: assert x in model and x in m and x in t
def test_printable_reference_has_safety_authority_boundary():
 t=(R/'app/templates/checklist_reference.html').read_text(encoding='utf-8'); assert 'TRAINING AID' in t and 'current approved R22 POH/RFM' in t and '/checklist-reference/print' in t
