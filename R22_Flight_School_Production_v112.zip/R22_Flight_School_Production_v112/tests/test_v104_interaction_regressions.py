from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding="utf-8")
def test_rotor_quiz_clicks_directly_on_image():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert 'id="quizClickLayer"' in h
 assert "layer.addEventListener('pointerdown'" in j
 assert "INCORRECT — TRY AGAIN" in j and "CORRECT —" in j
def test_motion_mode_no_longer_depends_on_deleted_side_button():
 j=t("app/static/rotor_components_v91.js")
 assert "if(m==='motion')startDemo()" in j
 assert "$('#partMotion').click()" not in j
def test_test_mode_actions_visibly_select_without_revealing_correctness():
 j=t("app/static/emergency_v87.js");c=t("app/static/app.css")
 assert "b.classList.add('test-selected')" in j
 assert "mode==='test'?'selected'" in j
 assert ".em87-actions button.test-selected" in c
def test_flight_readouts_have_instrument_styling():
 c=t("app/static/app.css")
 assert ".em-flight-summary span:not(.summary-label) b{font-family:ui-monospace" in c
