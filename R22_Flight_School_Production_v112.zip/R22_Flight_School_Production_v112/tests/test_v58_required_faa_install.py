from pathlib import Path

def t(p): return Path(p).read_text(encoding='utf-8')

def test_v58_three_required_faa_products():
    s=t('app/main.py')
    assert "'sectional'" in s and 'Los_Angeles.zip' in s
    assert "'tac'" in s and 'Los_Angeles_TAC.zip' in s
    assert "'helicopter'" in s and 'Los_Angeles_Heli.zip' in s

def test_v58_windows_installs_and_verifies_charts_before_completion():
    s=t('deploy/INSTALL_WINDOWS.ps1')
    install=s.index('Installing required FAA Los Angeles Sectional, TAC, and Helicopter Route charts')
    verify=s.index('FAA offline chart payload verified.')
    complete=s.index('Installation complete.')
    assert install < verify < complete
    assert 'Installation cannot complete without the offline chart lab.' in s
    assert 'lgb-sectional-chart.jpg' not in s and 'retry online' not in s

def test_v58_linux_installs_and_verifies_charts_before_completion():
    s=t('deploy/install_linux.sh')
    install=s.index('Installing required FAA Los Angeles Sectional, TAC, and Helicopter Route charts')
    verify=s.index('FAA offline chart payload verified.')
    complete=s.index('Installation complete.')
    assert install < verify < complete
    assert 'Installation cannot complete without the offline chart lab.' in s
    assert 'lgb-sectional-chart.jpg' not in s and 'retry online' not in s

def test_v58_chart_builder_preserves_source_detail_and_tiles():
    s=t('app/main.py')
    assert "tile=512" in s and "source':'FAA GeoTIFF'" in s
    assert 'native_w,native_h=int(win.width),int(win.height)' in s
    assert 'out_h=1200' not in s
