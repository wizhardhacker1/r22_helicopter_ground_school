from pathlib import Path

def test_clutch_light_tracks_actuator_not_low_rpm():
    js=Path("app/static/startup.js").read_text(encoding="utf-8")
    assert "master&&clutch&&clutchActuating" in js
    assert "master&&clutch&&rpm()<70" not in js
    assert "clutchActuating=true;light('clutch',true)" in js
    assert "clutchActuating=false;light('clutch',false);updateSystems()" in js

def test_auto_clutch_advances_after_light_out():
    js=Path("app/static/startup.js").read_text(encoding="utf-8")
    assert "s[3]==='autoClutch'&&!$('clutchLight').classList.contains('lit')" in js
