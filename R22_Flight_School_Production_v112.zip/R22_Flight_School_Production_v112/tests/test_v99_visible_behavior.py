from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p):return (R/p).read_text(encoding='utf-8')
def test_rotor_picture_has_live_motion_rig():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert "rotor-motion-rig" in h and "motion-swash" in h and "motion-link" in h
 assert "style.setProperty('--swash-y'" in j and "style.setProperty('--swash-tilt'" in j
def test_emergency_audio_visible_and_on():
 h=t("app/templates/emergency.html")
 assert 'em-audio-main' in h and 'aria-pressed="true">AUDIO ON' in h
def test_emergency_switches_and_lights_have_live_states():
 j=t("app/static/emergency_v87.js");c=t("app/static/app.css")
 assert "classList.toggle('switch-on'" in j and "lamp('govoff',scenario==='governor')" in j
 assert ".cockpit-control.switch-on" in c and ".annun.lit" in c
def test_emergency_audio_has_engine_and_warning_horn():
 j=t("app/static/emergency_v87.js")
 assert "r22_helicopter_running.mp3" in j and "function horn(on)" in j and "horn(!!cfg.horn||!!cfg.fault?.lowrpm)" in j
