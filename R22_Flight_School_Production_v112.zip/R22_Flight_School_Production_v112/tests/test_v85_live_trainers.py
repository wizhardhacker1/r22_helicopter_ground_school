from test_v87_trainers import *
