from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding="utf-8")
def test_bat_is_supported_entrypoint_and_pauses_on_failure():
    s=t("INSTALL_WINDOWS.bat")
    assert "INSTALL_WINDOWS.ps1" in s and "if errorlevel 1 pause" in s
def test_powershell_does_not_pipe_python_stderr():
    s=t("deploy/INSTALL_WINDOWS.ps1")
    assert "Start-Process" in s
    assert "-RedirectStandardOutput $faaOut" in s
    assert "-RedirectStandardError $faaErr" in s
    assert "Tee-Object" not in s
    assert "$faaProc.ExitCode" in s
    assert "FAA_CHART_INSTALL.log" in s
