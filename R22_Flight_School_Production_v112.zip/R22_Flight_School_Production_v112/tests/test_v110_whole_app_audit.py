from pathlib import Path
import re, collections
R=Path(__file__).resolve().parents[1]

def t(p): return (R/p).read_text(encoding="utf-8")

def test_internal_version_is_v110():
    assert t("VERSION").strip()=="112"
    assert "APP_VERSION='112'" in t("app/main.py")
    assert "r22-school-v112-static" in t("app/static/sw.js")

def test_known_dead_checkride_links_are_removed():
    all_html="\n".join(p.read_text(encoding="utf-8") for p in (R/"app/templates").glob("*.html"))
    assert "/poh-mastery" not in all_html
    assert "/practice-exams" not in all_html
    assert "href=/poh" in t("app/templates/checkride_center.html")
    assert "href=/exams" in t("app/templates/checkride_center.html")

def test_static_assets_referenced_by_templates_exist():
    missing=[]
    for p in (R/"app/templates").glob("*.html"):
        s=p.read_text(encoding="utf-8")
        for m in re.finditer(r'(?:src|href)=["\'](/static/[^"\'?#]+)',s):
            u=m.group(1)
            if "{{" in u: continue
            if not (R/"app/static"/u[8:]).exists(): missing.append((p.name,u))
    assert not missing, missing

def test_templates_have_no_duplicate_literal_ids():
    bad=[]
    for p in (R/"app/templates").glob("*.html"):
        ids=re.findall(r'\bid=["\']([^"\']+)',p.read_text(encoding="utf-8"))
        dup=[x for x,n in collections.Counter(ids).items() if n>1]
        if dup: bad.append((p.name,dup))
    assert not bad,bad

def test_visible_hex_entities_are_not_baked_into_ui_source():
    for p in list((R/"app/templates").glob("*.html"))+list((R/"app/static").glob("*.js")):
        s=p.read_text(encoding="utf-8",errors="ignore")
        assert not re.search(r'&(?:amp;)?#x[0-9A-Fa-f]+;',s),p.name


def test_base_navigation_optional_chain_is_safe_on_login():
    h=t("app/templates/base.html")
    assert "sideNav?.querySelectorAll('nav a')?.forEach" in h

def test_oral_does_not_load_app_js_twice():
    h=t("app/templates/oral.html")
    assert "/static/app.js" not in h

def test_service_worker_caches_current_trainer_scripts():
    s=t("app/static/sw.js")
    for x in ["rotor_motion_v91.js","rotor_components_v91.js","emergency_v87.js"]: assert x in s
    for stale in ["rotor_motion_v89.js?v=112","rotor_components_v88.js?v=112","emergency_v85.js?v=112"]: assert stale not in s


def test_app_js_array_listener_is_not_accidentally_chained_to_calc_function():
    s=t("app/static/app.js")
    assert ";['fmain','faux'].forEach" in s
