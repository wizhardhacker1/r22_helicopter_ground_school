from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding="utf-8")

def test_rotor_quiz_asks_each_component_once_then_passes():
    j=t("app/static/rotor_components_v91.js")
    assert "quizOrder=shuffle(Object.keys(data).slice())" in j
    assert "quizIndex=0;quizCorrect=0" in j
    assert "quizIndex>=quizOrder.length" in j
    assert "COMPONENT QUIZ PASSED" in j
    assert "PASS — ${quizCorrect}/${quizOrder.length}" in j

def test_cyclic_moves_opposing_blades():
    j=t("app/static/rotor_components_v91.js"); c=t("app/static/app.css")
    assert "--pitch-left" in j and "--pitch-right" in j
    assert ".motion-grip.left .pitch-tab" in c
    assert ".motion-grip.right .pitch-tab" in c

def test_login_has_no_ascii_arrow_artifact():
    h=t("app/templates/login.html")
    assert "<span>-></span>" not in h
    assert "ENTER FLIGHT SCHOOL" in h and "›" in h

def test_roadmap_has_no_known_dead_routes():
    r=t("app/roadmap.py")
    for dead in ["/checkride-prep","/preflight","/poh-charts","/flight-computer"]:
        assert dead not in r
    assert "/checkride-center" in r
