from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def t(p): return (ROOT/p).read_text(encoding='utf-8')
def test_v60_selects_geotiff_by_geographic_overlap_not_zip_order():
 s=t('app/main.py'); assert 'best_overlap' in s and "for n in names" in s and "covering the Long Beach training area" in s
def test_v60_deep_verifies_every_expected_tile_and_color_content():
 s=t('app/main.py'); assert 'def _verify_chart_tiles' in s and 'missing/invalid tile' in s and 'mostly blank' in s and 'color-content validation' in s
def test_v60_browser_suppresses_training_overlay_when_tile_fails():
 s=t('app/static/navigation_charts.js'); assert 'Chart integrity failure:' in s and "trainingLayer.innerHTML=''" in s and "addEventListener('error'" in s
def test_v60_has_all_three_real_chart_selectors():
 s=t('app/templates/navigation_charts.html'); assert 'data-chart-kind="sectional"' in s and 'data-chart-kind="tac"' in s and 'data-chart-kind="helicopter"' in s
