from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_base_template_can_be_read_with_windows_cp1252():
    text=(R/'app/templates/base.html').read_text(encoding='cp1252')
    assert 'Checkride Center' in text and '/flashcards' in text
def test_v64_regression_reads_source_explicitly_as_utf8():
    t=(R/'tests/test_v64_learning_expansion.py').read_text(encoding='utf-8')
    assert "read_text(encoding='utf-8')" in t
