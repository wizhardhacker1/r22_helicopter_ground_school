from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
def test_print_checklist_has_hard_print_visibility_fix():
 c=(R/'app/static/app.css').read_text(encoding='utf-8')
 assert 'body:has(.checklist-page-head) .aviation-sheet *' in c and 'visibility:visible!important' in c
def test_current_robinson_snapshot_and_external_accident_research():
 h=(R/'app/templates/robinson_safety.html').read_text(encoding='utf-8'); m=(R/'app/main.py').read_text(encoding='utf-8')
 assert 'R22 SB-123A' in m and 'Aug 2026' in m and 'Sep 2026' in m
 for typ in ('r22','r44','r66'): assert f'aviation-safety.net/asndb/type/{typ}' in h
 assert 'robinsonheli.com/publications' in h
def test_flight_plan_is_icao_aligned_and_not_misrepresented():
 h=(R/'app/templates/flight_planner.html').read_text(encoding='utf-8')
 for x in ('7 AIRCRAFT IDENTIFICATION','8 FLIGHT RULES','10 EQUIPMENT','13 DEPARTURE / TIME','15 ROUTE','16 DESTINATION / TOTAL EET','18 OTHER INFORMATION','19 ENDURANCE'): assert x in h
 assert 'not an FAA filing service' in h
def test_content_audit_is_explicit():
 a=json.loads((R/'data/content_audit_v73.json').read_text(encoding='utf-8'))
 assert a['built_in_authored_questions']=={'PPL':92,'R22':36,'IFR':10,'total':138}
 assert 'not represented as live FAA test questions' in a['bank_representation']
def test_r22_cockpit_geometry_shared():
 c=(R/'app/static/app.css').read_text(encoding='utf-8')
 assert 'grid-template-areas:"breakers main lower" "breakers pedestal lower"' in c
 for f in ('startup.html','checklists.html'):
  h=(R/'app/templates'/f).read_text(encoding='utf-8')
  assert 'r22-main-panel' in h and 'r22-pedestal' in h and 'r22-breakers' in h

def test_robinson_refresh_is_hardcoded_not_user_url():
 m=(R/'app/main.py').read_text(encoding='utf-8')
 block=m[m.index("@app.get('/api/robinson-feed')"):m.index("@app.get('/robinson-safety'")]
 assert "url='https://www.robinsonheli.com/publications'" in block
 assert "read(2_000_001)" in block and "timeout=8" in block
