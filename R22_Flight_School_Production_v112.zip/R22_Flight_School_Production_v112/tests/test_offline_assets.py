from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
def test_training_ui_has_no_required_external_web_assets():
    bad=[]
    for base in (ROOT/'app'/'templates',ROOT/'app'/'static'):
        for p in base.rglob('*'):
            if p.is_file() and p.suffix.lower() in {'.html','.js','.css'}:
                txt=p.read_text(encoding='utf-8', errors='ignore')
                if re.search(r'''(?:script\s+[^>]*src|link\s+[^>]*href|img\s+[^>]*src)=["']https?://''',txt,re.I): bad.append(str(p.relative_to(ROOT)))
    assert not bad, f'external runtime links found: {bad}'
def test_core_offline_reference_assets_exist():
    required=[ROOT/'data'/'R22_POH_reference.pdf']+[ROOT/'app'/'static'/'charts'/f'p{x}.jpg' for x in range(70,80)]
    assert all(p.exists() and p.stat().st_size>0 for p in required)
def test_startup_and_chart_interaction_assets_exist():
    for rel in ['app/static/startup.js','app/static/charts.js','app/templates/startup.html','app/templates/charts.html']:
        p=ROOT/rel; assert p.exists() and p.stat().st_size>500
