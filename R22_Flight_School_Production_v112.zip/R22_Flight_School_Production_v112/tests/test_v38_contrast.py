from pathlib import Path


def test_flight_result_light_cards_force_dark_readable_text():
    root = Path(__file__).resolve().parents[1]
    css = (root / 'app/static/app.css').read_text(encoding='utf-8')
    assert 'v38 accessibility/contrast audit' in css
    assert '.meaning-box,.training-check,.calc-explain,.training-note' in css
    assert 'color:#173642!important' in css
    assert '.visual-status#e6bout .meaning-box *' in css


def test_v38_cache_version():
    root = Path(__file__).resolve().parents[1]
    version = (root/'VERSION').read_text(encoding='utf-8').strip()
    sw = (root/'app/static/sw.js').read_text(encoding='utf-8')
    assert version.isdigit()
    assert f'r22-school-v{version}-static' in sw
    assert f'?v={version}' in sw
