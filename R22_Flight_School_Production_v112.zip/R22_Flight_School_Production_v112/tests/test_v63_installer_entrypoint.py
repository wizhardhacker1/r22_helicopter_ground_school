from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def test_faa_helper_bootstraps_project_root_before_app_import():
    text=(ROOT/'deploy'/'install_faa_charts.py').read_text(encoding='utf-8')
    assert "Path(__file__).resolve().parent.parent" in text
    assert "sys.path.insert(0, project_root_text)" in text
    assert text.index("sys.path.insert(0, project_root_text)") < text.index("from app.main import")

def test_actual_direct_script_resolves_app_from_installer_context():
    proc=subprocess.run(
        [sys.executable, str(ROOT/'deploy'/'install_faa_charts.py'), '--bootstrap-check'],
        cwd=ROOT, text=True, capture_output=True
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr
    assert "FAA_INSTALLER_BOOTSTRAP_OK" in proc.stdout

def test_windows_installer_runs_helper_from_project_root():
    ps=(ROOT/'deploy'/'INSTALL_WINDOWS.ps1').read_text(encoding='utf-8')
    assert "-WorkingDirectory $Root" in ps
    assert "'-u','deploy\\install_faa_charts.py'" in ps
