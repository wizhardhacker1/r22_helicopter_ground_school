from pathlib import Path
R=Path(__file__).resolve().parents[1]
def test_print_reference_is_standalone_not_app_shell():
 t=(R/'app/templates/checklist_reference.html').read_text(encoding='utf-8')
 assert "extends 'base.html'" in t and 'aviation-sheet' in t and '/checklist-reference/print' in t
def test_chart_explains_training_targets():
 t=(R/'app/templates/navigation_charts.html').read_text(encoding='utf-8')
 assert 'No synthetic location dots' in t
 assert '1. Orient' in t and '2. Decode' in t and '3. Apply' in t and '4. Prove it' in t
def test_checkride_center_has_four_stage_curriculum():
 t=(R/'app/templates/checkride_center.html').read_text(encoding='utf-8')
 for x in ('STAGE 1','STAGE 2','STAGE 3','STAGE 4','Oral answer discipline','CHECKRIDE WORKBOOK'): assert x in t
