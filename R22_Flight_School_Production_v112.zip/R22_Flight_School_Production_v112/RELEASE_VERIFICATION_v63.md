# v63 installer correction

- Fixed direct execution of `deploy/install_faa_charts.py` from the BAT/PowerShell installer.
- The helper now inserts the extracted project root into `sys.path` before importing `app.main`.
- The helper changes its working directory to that same project root.
- Added a regression that executes the helper import/bootstrap from installer context.
- Windows FAA process still captures stdout/stderr and uses the native process exit code.
