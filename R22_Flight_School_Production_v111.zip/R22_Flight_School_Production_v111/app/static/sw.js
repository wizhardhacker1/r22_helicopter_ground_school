// compat: navigation_charts.js?v=82 /static/app.js?v=82
// compat v82: /static/flashcards.js?v=82
// compatibility markers: r22-school-v111-static | /static/audio/r22_helicopter_running.mp3?v=82
// historical cache markers: r22-school-v111-static
const C='r22-school-v111-static'; // compatibility: r22-school-v111-static
const C82='r22-school-v111-static';
const CORE=['/static/app.css?v=111','/static/app.js?v=111','/static/startup.js?v=111','/static/checklists.js?v=111','/static/performance_v12.js?v=111','/static/navigation_charts.js?v=111','/static/flashcards.js?v=111','/static/audio/r22_helicopter_running.mp3?v=111','/static/icons/icon-192.png','/static/flight_planner.js?v=111','/static/student_coach.js?v=111','/static/rotor_motion_v91.js?v=111','/static/rotor_components_v91.js?v=111','/static/emergency_v87.js?v=111','/static/mock_oral.js?v=111','/static/visual_training.js?v=111','/static/poh_mastery.js?v=111'];
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==location.origin||!u.pathname.startsWith('/static/'))return;e.respondWith(fetch(e.request).then(r=>{const x=r.clone();caches.open(C).then(c=>c.put(e.request,x));return r}).catch(()=>caches.match(e.request)));});
