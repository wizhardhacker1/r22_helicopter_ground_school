import os,random,json,csv,io,secrets,sqlite3,datetime,subprocess,shutil,urllib.request,re
from contextlib import asynccontextmanager
from fastapi import FastAPI,Request,Depends,Form,HTTPException,UploadFile,File
from fastapi.responses import HTMLResponse,RedirectResponse,FileResponse,JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import BaseModel
from .db import Base,engine,get_db
from .models import *
from .auth import hash_password,verify,token,current,csrf_token,check_csrf
from .seed import seed
from .calculators import wb,density_altitude,pressure_altitude,wind_triangle,fuel_plan,e6b
from .training import SYLLABUS,EMERGENCIES,ATC_SCENARIOS,LESSONS
from .roadmap import ROADMAP_LINKS
from .content import POH_SECTIONS,LIMITS,SAFETY_NOTICES,CHECKRIDE_AREAS
from .acs import ACS_AREAS, coverage_rows, find_task
from .academy import ACADEMY_COURSES, COURSE_MAP
from .ground_school import GROUND_MODULES,PART61_KNOWLEDGE,FLIGHT_AREAS,EXPERIENCE_61_109,PART141_APPROVAL_GATES,STAGES,PART141_GROUND_HOURS
from .poh_mastery import POH_MASTERY_SECTIONS,POH_MASTERY_MAP,POH_FINAL_QUESTIONS
APP_VERSION='111' # historical test marker: APP_VERSION='80'
def startup():
 os.makedirs('data',exist_ok=True); Base.metadata.create_all(engine)
 # Additive migration preserves existing student logbook data across upgrades.
 with engine.begin() as con:
  cols={r[1] for r in con.exec_driver_sql('PRAGMA table_info(flight_logs)').fetchall()}
  for name,typ in [('ground_trainer_hours','FLOAT DEFAULT 0'),('day_hours','FLOAT DEFAULT 0'),('cross_country_hours','FLOAT DEFAULT 0'),('actual_instrument_hours','FLOAT DEFAULT 0'),('simulated_instrument_hours','FLOAT DEFAULT 0'),('day_landings','INTEGER DEFAULT 0'),('night_landings','INTEGER DEFAULT 0'),('total_duration','FLOAT DEFAULT 0'),('instructor_approval',"VARCHAR(120) DEFAULT ''")]:
   if name not in cols: con.exec_driver_sql(f'ALTER TABLE flight_logs ADD COLUMN {name} {typ}')
 from .db import SessionLocal
 db=SessionLocal(); seed(db); db.close()
@asynccontextmanager
async def lifespan(app):
 startup(); yield
app=FastAPI(title='R22 Flight School',docs_url=None if os.getenv('ENVIRONMENT')=='production' else '/api/docs',lifespan=lifespan)
@app.middleware("http")
async def security_headers(request,call_next):
 r=await call_next(request)
 r.headers['X-Content-Type-Options']='nosniff'; r.headers['X-Frame-Options']='DENY'; r.headers['Referrer-Policy']='same-origin'; r.headers['Permissions-Policy']='geolocation=(self), microphone=(self)'
 r.headers['Cache-Control']='no-store' if not request.url.path.startswith('/static/') else 'public, max-age=3600'
 return r
app.mount('/static',StaticFiles(directory='app/static'),name='static'); tpl=Jinja2Templates(directory='app/templates')
LOGIN_FAILURES={}
def _login_blocked(ip):
 import time
 now=time.time(); xs=[t for t in LOGIN_FAILURES.get(ip,[]) if now-t<600]; LOGIN_FAILURES[ip]=xs; return len(xs)>=8
def _login_fail(ip):
 import time
 LOGIN_FAILURES.setdefault(ip,[]).append(time.time())

def user_obj(request,db):
 p=current(request); u=db.get(User,int(p['sub']))
 if not u or not u.active: raise HTTPException(401,'Account unavailable')
 return u
def ctx(request,u=None,**kw):
 c={'request':request,'u':u,'csrf':csrf_token(request),'app_version':APP_VERSION}; c.update(kw); return c
def html(template,request,u=None,**kw):
 c=ctx(request,u,**kw); r=tpl.TemplateResponse(request,template,c)
 if not request.cookies.get('csrf'): r.set_cookie('csrf',c['csrf'],httponly=False,samesite='lax',secure=os.getenv('COOKIE_SECURE','false').lower()=='true')
 return r
@app.exception_handler(ValueError)
async def value_error(_,exc): return JSONResponse({'error':str(exc)},400)

def acs_for_area(area):
 a=(area or '').lower()
 rules=[(('weather',),'PH.I.C'),(('airspace','regulation','airport'),'PH.I.E'),(('navigation','chart'),'PH.I.D / PH.VII'),(('performance','weight','balance'),'PH.I.F'),(('system','r22 systems'),'PH.I.G'),(('human','adm','risk'),'PH.I.H'),(('emerg','autorotation','low-g','vortex','rpm'),'PH.VIII'),(('communication','radio'),'PH.III.B')]
 for keys,code in rules:
  if any(k in a for k in keys): return code
 return 'FAA-S-ACS-15'

@app.get('/health')
def health(db:Session=Depends(get_db)): return {'ok':True,'questions':db.query(Question).filter(Question.active==True).count(),'users':db.query(User).count()}
def _show_default_admin(db):
 u=db.query(User).filter(User.username=='admin',User.role=='admin').first()
 return bool(u and u.must_change_password and verify('ChangeMe123!',u.password_hash))
@app.get('/',response_class=HTMLResponse)
def home(request:Request,db:Session=Depends(get_db)): return html('login.html',request,show_default_admin=_show_default_admin(db))
@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request,db:Session=Depends(get_db)): return html('login.html',request,show_default_admin=_show_default_admin(db))
@app.post('/login')
def login(request:Request,username:str=Form(),password:str=Form(),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); ip=request.client.host if request.client else 'unknown'
 if _login_blocked(ip): raise HTTPException(429,'Too many failed login attempts. Try again later.')
 u=db.query(User).filter(User.username==username.strip()).first()
 if not u or not u.active or not verify(password,u.password_hash): _login_fail(ip); return RedirectResponse('/?error=1',303)
 LOGIN_FAILURES.pop(ip,None); r=RedirectResponse('/profile' if u.must_change_password else '/dashboard',303); r.set_cookie('session',token(u.id,u.role),httponly=True,samesite='lax',secure=os.getenv('COOKIE_SECURE','false').lower()=='true',max_age=43200); db.add(Audit(user_id=u.id,action='login',detail=request.client.host if request.client else '')); db.commit(); return r
@app.get('/logout')
def logout():
 r=RedirectResponse('/',303); r.delete_cookie('session'); return r
@app.get('/dashboard',response_class=HTMLResponse)
def dashboard(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); ats=db.query(Attempt).filter(Attempt.user_id==u.id).all(); acc=round(100*sum(a.correct for a in ats)/len(ats)) if ats else 0; ms=db.query(Mastery).filter(Mastery.user_id==u.id).order_by(Mastery.score).all(); assignments=db.query(Assignment).filter(Assignment.student_id==u.id,Assignment.completed==False).all(); exams=db.query(Exam).filter(Exam.user_id==u.id,Exam.total>=10).order_by(Exam.created_at.desc()).limit(5).all()
 
 completed={r.item for r in db.query(TrainingRecord).filter(TrainingRecord.user_id==u.id,TrainingRecord.module=='syllabus',TrainingRecord.status=='complete').all()}
 readiness=round((min(acc,100)*.35)+(100*len(completed)/len(SYLLABUS)*.35)+(min(100,(sum(m.score for m in ms)/len(ms)*100 if ms else 0))*.30))
 
 dates=sorted({a.created_at.date() for a in ats if a.created_at},reverse=True); streak=0
 if dates:
  import datetime
  d=dates[0]; today=datetime.date.today()
  if (today-d).days<=1:
   streak=1
   while d-datetime.timedelta(days=1) in dates: d-=datetime.timedelta(days=1); streak+=1
 points=sum(10 if a.correct else 2 for a in ats)+25*len(completed)
 return html('dashboard.html',request,u,attempts=len(ats),accuracy=acc,mastery=ms,assignments=assignments,exams=exams,readiness=readiness,completed=len(completed),syllabus_total=len(SYLLABUS),streak=streak,points=points)
@app.get('/study',response_class=HTMLResponse)
def study(request:Request,track:str='R22',mode:str='adaptive',db:Session=Depends(get_db)):
 u=user_obj(request,db); base=db.query(Question).filter(Question.track==track,Question.active==True); qs=base.all(); mastery={m.area:m.score for m in db.query(Mastery).filter(Mastery.user_id==u.id).all()}
 if mode=='bookmarked':
  ids=[x.question_id for x in db.query(Bookmark).filter_by(user_id=u.id).all()]; qs=[q for q in qs if q.id in ids]
 elif mode=='missed':
  missed={a.question_id for a in db.query(Attempt).filter_by(user_id=u.id,correct=False).all()}; qs=[q for q in qs if q.id in missed]
 elif mode=='weak':
  weak={a for a,v in mastery.items() if v<.65}; qs=[q for q in qs if q.area in weak]
 random.shuffle(qs); qs.sort(key=lambda q:mastery.get(q.area,.25)+random.random()*.15)
 bookmarked=set(x.question_id for x in db.query(Bookmark).filter_by(user_id=u.id).all())
 q=qs[0] if qs else None; acs_tag=acs_for_area(q.area) if q else None; return html('study.html',request,u,q=q,track=track,mode=mode,bookmarked=bookmarked,acs_tag=acs_tag)
@app.post('/answer/{qid}')
def answer(request:Request,qid:int,selected:str=Form(),track:str=Form('R22'),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db); q=db.get(Question,qid)
 if not q or not q.active: raise HTTPException(404)
 ok=selected.upper()==q.correct; db.add(Attempt(user_id=u.id,question_id=q.id,selected=selected.upper(),correct=ok)); m=db.query(Mastery).filter_by(user_id=u.id,area=q.area).first()
 if not m: m=Mastery(user_id=u.id,area=q.area,score=.25,seen=0,correct=0); db.add(m)
 m.seen+=1; m.correct+=int(ok); recent=.85 if ok else .15; m.score=max(.05,min(.99,m.score*.8+recent*.2)); db.commit(); return html('result.html',request,u,q=q,ok=ok,selected=selected,track=track)
@app.post('/questions/{qid}/bookmark')
def bookmark_toggle(request:Request,qid:int,track:str=Form('R22'),mode:str=Form('adaptive'),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db); q=db.get(Question,qid)
 if not q: raise HTTPException(404)
 x=db.query(Bookmark).filter_by(user_id=u.id,question_id=qid).first()
 if x: db.delete(x)
 else: db.add(Bookmark(user_id=u.id,question_id=qid))
 db.commit(); return RedirectResponse(f'/study?track={track}&mode={mode}',303)

@app.get('/lesson/{key}',response_class=HTMLResponse)
def lesson(request:Request,key:str,db:Session=Depends(get_db)):
 u=user_obj(request,db); item=LESSONS.get(key)
 if not item: raise HTTPException(404)
 p=db.query(LessonProgress).filter_by(user_id=u.id,lesson_key=key).first(); return html('lesson.html',request,u,key=key,lesson=item,progress=p)

@app.post('/lesson/{key}')
def lesson_save(request:Request,key:str,completed:bool=Form(False),notes:str=Form(''),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if key not in LESSONS: raise HTTPException(404)
 p=db.query(LessonProgress).filter_by(user_id=u.id,lesson_key=key).first()
 if not p: p=LessonProgress(user_id=u.id,lesson_key=key); db.add(p)
 p.completed=completed; p.notes=notes[:5000]; db.commit(); return RedirectResponse(f'/lesson/{key}',303)

@app.get('/exams',response_class=HTMLResponse)
def exam_center(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); hist=db.query(Exam).filter(Exam.user_id==u.id,Exam.total>=10).order_by(Exam.created_at.desc()).limit(20).all(); counts={t:db.query(Question).filter(Question.track==t,Question.active==True).count() for t in ('PPL','R22','IFR')}; return html('exam_center.html',request,u,history=hist,counts=counts)

@app.get('/exam',response_class=HTMLResponse)
def exam_page(request:Request,track:str='PPL',count:int=60,minutes:int=150,db:Session=Depends(get_db)):
 u=user_obj(request,db); track=track.upper(); count=max(5,min(count,100)); minutes=max(5,min(minutes,240)); qs=db.query(Question).filter(Question.track==track,Question.active==True).all()
 last={}
 for item in db.query(ExamItem).filter_by(user_id=u.id).order_by(ExamItem.created_at.desc()).all():
  if item.question_id not in last: last[item.question_id]=item.created_at
 unseen=[q for q in qs if q.id not in last]; seen=[q for q in qs if q.id in last]; random.shuffle(unseen); random.shuffle(seen); seen.sort(key=lambda q:last.get(q.id)); selected=(unseen+seen)[:count]
 return html('exam.html',request,u,track=track,questions=selected,minutes=minutes,rotation_unseen=len(unseen))
@app.post('/exam/grade')
async def grade_exam(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); form=await request.form(); check_csrf(request,str(form.get('csrf',''))); track=str(form.get('track','PPL')).upper(); qids=[int(x) for x in form.getlist('qid')]; correct=0; rows=[]
 if len(qids)<10: raise HTTPException(400,'A scored practice exam requires at least 10 questions. Short trainer/diagnostic activity is not stored as an exam.')
 ex=Exam(user_id=u.id,track=track,total=len(qids),correct=0,score=0,passed=False); db.add(ex); db.flush()
 for qid in qids:
  q=db.get(Question,qid); sel=str(form.get(f'q_{qid}','')).upper(); ok=bool(q and sel==q.correct); correct+=int(ok); db.add(Attempt(user_id=u.id,question_id=qid,selected=sel,correct=ok,mode='exam')); db.add(ExamItem(exam_id=ex.id,user_id=u.id,question_id=qid,selected=sel,correct=ok)); rows.append({'q':q,'selected':sel,'correct':ok})
 score=round(100*correct/len(qids),1) if qids else 0; ex.correct=correct; ex.score=score; ex.passed=score>=70
 cert=None
 if ex.passed:
  cert=db.query(Certificate).filter_by(exam_id=ex.id).first()
  if not cert:
   cert=Certificate(user_id=u.id,exam_id=ex.id,track=track,score=score,certificate_code='R22FS-'+secrets.token_hex(6).upper()); db.add(cert)
 db.commit();
 if cert: db.refresh(cert)
 return html('exam_result.html',request,u,exam=ex,rows=rows,certificate=cert)

@app.get('/certificates',response_class=HTMLResponse)
def certificates(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); certs=db.query(Certificate).join(Exam,Certificate.exam_id==Exam.id).filter(Certificate.user_id==u.id,Exam.total>=10).order_by(Certificate.issued_at.desc()).all(); return html('certificates.html',request,u,certificates=certs)

@app.get('/certificate/{cid}',response_class=HTMLResponse)
def certificate_view(request:Request,cid:int,db:Session=Depends(get_db)):
 u=user_obj(request,db); cert=db.get(Certificate,cid)
 if not cert or (cert.user_id!=u.id and u.role not in ('admin','instructor')): raise HTTPException(404)
 student=db.get(User,cert.user_id); exam=db.get(Exam,cert.exam_id)
 return html('certificate.html',request,u,certificate=cert,student=student,exam=exam)

@app.get('/verify-certificate/{code}',response_class=HTMLResponse)
def certificate_verify(request:Request,code:str,db:Session=Depends(get_db)):
 cert=db.query(Certificate).filter_by(certificate_code=code.strip().upper()).first()
 if not cert: return html('certificate_verify.html',request,None,certificate=None,student=None)
 student=db.get(User,cert.user_id); return html('certificate_verify.html',request,None,certificate=cert,student=student)

@app.get('/academy',response_class=HTMLResponse)
def academy_home(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); done={r.item for r in db.query(TrainingRecord).filter_by(user_id=u.id,module='academy',status='complete').all()}; return html('academy.html',request,u,courses=ACADEMY_COURSES,course=None,completed_keys=done,completed_count=len(done))

@app.get('/academy/{key}',response_class=HTMLResponse)
def academy_course(request:Request,key:str,db:Session=Depends(get_db)):
 u=user_obj(request,db); course=COURSE_MAP.get(key)
 if not course: raise HTTPException(404,'Academy course not found')
 done={r.item for r in db.query(TrainingRecord).filter_by(user_id=u.id,module='academy',status='complete').all()}; return html('academy.html',request,u,courses=ACADEMY_COURSES,course=course,completed_keys=done,completed_count=len(done))

@app.post('/api/academy/complete')
async def academy_complete(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); p=await request.json(); key=str(p.get('course','')); course=COURSE_MAP.get(key)
 if not course: raise HTTPException(404,'Academy course not found')
 lessons=int(p.get('lessons',0) or 0); lab=bool(p.get('lab_passed'))
 if lessons < len(course['lessons']) or not lab: return JSONResponse({'ok':False,'error':'Course requirements incomplete'},400)
 rec=db.query(TrainingRecord).filter_by(user_id=u.id,module='academy',item=key).first()
 notes=json.dumps({'lessons':lessons,'lab_passed':True,'acs':course['acs'],'refs':course['refs'],'r22':course['r22']})
 if rec: rec.status='complete'; rec.score=100; rec.notes=notes
 else: db.add(TrainingRecord(user_id=u.id,module='academy',item=key,status='complete',score=100,notes=notes))
 db.commit(); return {'ok':True,'course':key}

@app.get('/official/faa-acs')
def official_faa_acs(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('https://www.faa.gov/training_testing/testing/acs',302)
@app.get('/official/robinson-r22')
def official_robinson_r22(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('https://www.robinsonheli.com/publications',302)
@app.get('/connected/live-atc')
def connected_live_atc(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('https://www.liveatc.net/hlisten.php?mount=kpoc2_klax_app_east_feeder&icao=klax',302)

@app.get('/performance',response_class=HTMLResponse)
def performance(request:Request,db:Session=Depends(get_db)): return html('performance.html',request,user_obj(request,db))
@app.get('/startup',response_class=HTMLResponse)
def startup_trainer(request:Request,db:Session=Depends(get_db)): return html('startup.html',request,user_obj(request,db))

@app.post('/api/training/interactive')
async def save_interactive(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); p=await request.json(); module=str(p.get('module','interactive'))[:80]; item=str(p.get('item','session'))[:160]; mode=str(p.get('mode','practice'))[:20]; score=max(0,min(100,float(p.get('score',0)))); completed=max(0,int(p.get('completed',0) or 0)); total=max(0,int(p.get('total',0) or 0)); fully_complete=bool(total>0 and completed>=total and score>=70); notes=json.dumps({'mode':mode,'mistakes':int(p.get('mistakes',0)),'seconds':int(p.get('seconds',0)),'completed':completed,'total':total})
 db.add(TrainingRecord(user_id=u.id,module=module,item=item,status='complete' if fully_complete else 'attempted',score=score,notes=notes)); db.commit(); return {'ok':True,'score':score}

@app.get('/official/faa-vfr')
def official_faa_vfr(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('https://www.faa.gov/air_traffic/flight_info/aeronav/digital_products/vfr/',status_code=302)
@app.get('/official/faa-mry-chart')
def official_faa_mry_chart(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('https://www.faa.gov/sites/faa.gov/files/inline-images/MRY-Chart-Supplement.jpg',status_code=302)
@app.get('/official/faa-chart-guide')
def official_faa_chart_guide(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('https://www.faa.gov/air_traffic/flight_info/aeronav/digital_products/aero_guide/',status_code=302)
@app.get('/official/faa-aim-charts')
def official_faa_aim_charts(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('https://www.faa.gov/air_traffic/publications/atpubs/aim_html/chap9_section_1.html',status_code=302)

FAA_CHARTS={
 'sectional':{'name':'Los Angeles Sectional','zip':'https://aeronav.faa.gov/visual/09-03-2026/sectional-files/Los_Angeles.zip','image':'Los_Angeles_Sectional_KLGB.png'},
 'tac':{'name':'Los Angeles Terminal Area Chart','zip':'https://aeronav.faa.gov/visual/09-03-2026/tac-files/Los_Angeles_TAC.zip','image':'Los_Angeles_TAC_KLGB.png'},
 'helicopter':{'name':'Los Angeles Helicopter Route Chart','zip':'https://aeronav.faa.gov/visual/09-03-2026/heli_files/Los_Angeles_Heli.zip','image':'Los_Angeles_Helicopter_KLGB.png'}}
FAA_CHART_EDITION='2026-09-03'; FAA_CHART_NEXT='2026-10-29'
FAA_BUNDLED_CHART_DIR=os.path.join(os.path.dirname(__file__),'static','faa_charts')
FAA_TRAINING_BOUNDS=(-118.55,33.55,-117.72,34.18)
def _faa_chart_dir():
 d=os.path.join(os.path.abspath(os.getenv('R22_DATA_DIR','./data')),'faa_charts'); os.makedirs(d,exist_ok=True); return d
def _valid_png(path):
 try:
  if not os.path.isfile(path) or os.path.getsize(path)<64: return False
  if open(path,'rb').read(8)!=b'\x89PNG\r\n\x1a\n': return False
  from PIL import Image
  with Image.open(path) as im: im.verify()
  return True
 except Exception:return False
def _valid_manifest(path):
 try:
  j=json.load(open(path,encoding='utf-8')); return j.get('tile_size')==512 and j.get('levels') and j.get('source')=='FAA GeoTIFF'
 except Exception:return False
def _seed_bundled_faa_charts(d):
 # Seed complete bundled training media only when persistent media is absent. Never replace a newer refreshed chart.
 for kind,meta in FAA_CHARTS.items():
  src=os.path.join(FAA_BUNDLED_CHART_DIR,kind); dst=os.path.join(d,kind)
  if os.path.isdir(src) and _valid_manifest(os.path.join(src,'manifest.json')) and not _valid_manifest(os.path.join(dst,'manifest.json')):
   shutil.copytree(src,dst,dirs_exist_ok=True)
 return d
def _chart_manifest(d,kind):
 p=os.path.join(d,kind,'manifest.json')
 if not _valid_manifest(p): return None
 try:return json.load(open(p,encoding='utf-8'))
 except Exception:return None
def _build_faa_tiles(kind,d):
 import tempfile,zipfile,math
 import rasterio
 from rasterio.windows import from_bounds,Window
 from rasterio.warp import transform_bounds
 from rasterio.enums import Resampling
 meta=FAA_CHARTS[kind]; final=os.path.join(d,kind); staging=final+'.new'
 if os.path.isdir(staging): shutil.rmtree(staging)
 os.makedirs(staging,exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='r22_faa_') as td:
  zpath=os.path.join(td,'chart.zip'); # Use httpx/certifi on Windows instead of urllib's machine certificate store.
  # Stream the large FAA ZIP and surface HTTP/network errors verbatim to the installer.
  import httpx
  try:
   with httpx.stream('GET',meta['zip'],headers={'User-Agent':'Mozilla/5.0 R22FlightSchool/62'},follow_redirects=True,timeout=httpx.Timeout(240.0,connect=30.0)) as response:
    response.raise_for_status()
    with open(zpath,'wb') as out:
     for chunk in response.iter_bytes(1024*1024): out.write(chunk)
  except Exception as e:
   raise RuntimeError(f"FAA download failed for {meta['name']} from {meta['zip']}: {type(e).__name__}: {e}") from e
  if os.path.getsize(zpath)<1000000 or not zipfile.is_zipfile(zpath): raise RuntimeError('FAA GeoTIFF package failed validation')
  with zipfile.ZipFile(zpath) as z:
   names=[n for n in z.namelist() if n.lower().endswith(('.tif','.tiff'))]
   if not names: raise RuntimeError('FAA package contained no GeoTIFF')
   for n in names: z.extract(n,td)
  # FAA archives may contain multiple chart rasters/sides. Never assume the first TIFF
  # is the geographic surface needed by the training lab. Choose the georeferenced
  # raster with the greatest overlap with the requested WGS84 training bounds.
  west,south,east,north=FAA_TRAINING_BOUNDS
  best=None; best_overlap=0.0
  for n in names:
   candidate=os.path.join(td,n)
   try:
    with rasterio.open(candidate) as test:
     if not test.crs: continue
     wb=transform_bounds(test.crs,'EPSG:4326',*test.bounds,densify_pts=21)
     iw=max(0.0,min(east,wb[2])-max(west,wb[0])); ih=max(0.0,min(north,wb[3])-max(south,wb[1])); overlap=iw*ih
     if overlap>best_overlap: best_overlap=overlap; best=candidate
   except Exception: continue
  if not best or best_overlap<=0: raise RuntimeError('FAA package has no georeferenced raster covering the Long Beach training area')
  tif=best
  with rasterio.open(tif) as src:
   if not src.crs: raise RuntimeError('FAA GeoTIFF is missing georeferencing')
   left,bottom,right,top=transform_bounds('EPSG:4326',src.crs,west,south,east,north,densify_pts=21)
   win=from_bounds(left,bottom,right,top,src.transform).round_offsets().round_lengths().intersection(Window(0,0,src.width,src.height))
   # Preserve source detail. Pyramid levels are generated from the FAA raster, never from a tiny browser preview.
   native_w,native_h=int(win.width),int(win.height); max_dim=max(native_w,native_h); tile=512
   max_z=max(0,int(math.ceil(math.log2(max_dim/tile))))
   levels=[]
   for zlev in range(max_z+1):
    scale=2**(max_z-zlev); w=max(1,math.ceil(native_w/scale)); h=max(1,math.ceil(native_h/scale)); cols=math.ceil(w/tile); rows=math.ceil(h/tile)
    zdir=os.path.join(staging,str(zlev)); os.makedirs(zdir,exist_ok=True)
    for y in range(rows):
     for x in range(cols):
      ox=x*tile; oy=y*tile; ow=min(tile,w-ox); oh=min(tile,h-oy)
      sw=Window(win.col_off+ox*scale,win.row_off+oy*scale,min(ow*scale,win.width-ox*scale),min(oh*scale,win.height-oy*scale))
      # Render FAA source to true RGB. Some FAA GeoTIFFs are palette-indexed; writing
      # the index band directly produces a gray/incorrect chart and loses FAA symbology colors.
      data=src.read(window=sw,out_shape=(src.count,oh,ow),resampling=Resampling.nearest)
      from PIL import Image
      import numpy as np
      if src.count==1:
       try: cmap=src.colormap(1)
       except Exception: cmap=None
       band=data[0]
       if cmap:
        lut=np.zeros((256,3),dtype=np.uint8)
        for idx,rgba in cmap.items():
         if 0<=idx<256: lut[idx]=rgba[:3]
        rgb=lut[band.astype(np.uint8)]
       else:
        if band.dtype!=np.uint8:
         lo=float(np.nanmin(band)); hi=float(np.nanmax(band)); band=((band-lo)*255/max(1.0,hi-lo)).clip(0,255).astype(np.uint8)
        rgb=np.repeat(band[:,:,None],3,axis=2)
      else:
       rgb=np.moveaxis(data[:3],0,2)
       if rgb.dtype!=np.uint8:
        rgb=np.clip(rgb,0,255).astype(np.uint8)
      tp=os.path.join(zdir,f'{x}_{y}.png')
      Image.fromarray(rgb,'RGB').save(tp,format='PNG',optimize=True)
    levels.append({'z':zlev,'width':w,'height':h,'cols':cols,'rows':rows})
   from rasterio.warp import transform as rio_transform
   training_features=[]
   # Public charted training anchors. Pixel placement is calculated from the FAA GeoTIFF georeferencing.
   for fid,label,lat,lon,lesson in [
    ('klgb','Long Beach Airport (KLGB)',33.8177,-118.1516,'airports'),
    ('ksli','Los Alamitos AAF (KSLI)',33.7900,-118.0520,'airports'),
    ('sli','Seal Beach VORTAC (SLI)',33.7833,-118.0540,'nav'),
    ('signal','Signal Hill',33.8045,-118.1678,'terrain'),
    ('queenmary','Queen Mary / Long Beach harbor landmark',33.7527,-118.1905,'route')]:
    xs,ys=rio_transform('EPSG:4326',src.crs,[lon],[lat]); rr,cc=src.index(xs[0],ys[0]); nx=(cc-win.col_off)/win.width; ny=(rr-win.row_off)/win.height
    if 0<=nx<=1 and 0<=ny<=1: training_features.append({'id':fid,'label':label,'x':round(nx,6),'y':round(ny,6),'lesson':lesson})
   manifest={'name':meta['name'],'edition':FAA_CHART_EDITION,'next':FAA_CHART_NEXT,'source':'FAA GeoTIFF','tile_size':tile,'levels':levels,'max_zoom':max_z,'bounds':{'west':west,'south':south,'east':east,'north':north},'training_features':training_features}
   json.dump(manifest,open(os.path.join(staging,'manifest.json'),'w',encoding='utf-8'),indent=2)
 if os.path.isdir(final): shutil.rmtree(final)
 os.replace(staging,final)
 check=_verify_chart_tiles(d,kind)
 if not check.get('ok'):
  shutil.rmtree(final,ignore_errors=True); raise RuntimeError('FAA rendered chart verification failed: '+check.get('error','unknown'))
 return {'ok':True,'tiles':sum(x['cols']*x['rows'] for x in levels),'max_zoom':max_z,'verified':check}
def _verify_chart_tiles(d,kind):
 m=_chart_manifest(d,kind)
 if not m: return {'ok':False,'error':'missing or invalid manifest'}
 try:
  from PIL import Image,ImageStat
  expected=0; seen=0; colorful=0; nonblank=0
  for lev in m.get('levels',[]):
   z=int(lev['z']); cols=int(lev['cols']); rows=int(lev['rows']); expected+=cols*rows
   for y in range(rows):
    for x in range(cols):
     path=os.path.join(d,kind,str(z),f'{x}_{y}.png')
     if not _valid_png(path): return {'ok':False,'error':f'missing/invalid tile {z}/{x}/{y}'}
     with Image.open(path) as im:
      rgb=im.convert('RGB'); seen+=1
      stat=ImageStat.Stat(rgb); extrema=rgb.getextrema()
      if any(hi-lo>12 for lo,hi in extrema): nonblank+=1
      # A genuine color chart should have at least some pixels where RGB channels differ.
      sample=rgb.resize((64,64)); px=list(sample.getdata())
      if any(max(v)-min(v)>8 for v in px): colorful+=1
  if seen!=expected or expected<1: return {'ok':False,'error':f'tile count mismatch {seen}/{expected}'}
  if nonblank < max(1,int(expected*.80)): return {'ok':False,'error':'chart tile coverage is mostly blank'}
  if colorful < max(1,int(expected*.20)): return {'ok':False,'error':'chart output failed color-content validation'}
  return {'ok':True,'tiles':seen,'nonblank':nonblank,'color_tiles':colorful}
 except Exception as e: return {'ok':False,'error':str(e)[:300]}

@app.get('/api/faa-charts/status')
def faa_chart_status(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); d=_seed_bundled_faa_charts(_faa_chart_dir()); return {'charts':{k:{'installed':bool(_chart_manifest(d,k)),'name':v['name'],'edition':FAA_CHART_EDITION,'next':FAA_CHART_NEXT,'manifest':_chart_manifest(d,k)} for k,v in FAA_CHARTS.items()}}
@app.post('/api/faa-charts/install')
def faa_chart_install(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); d=_seed_bundled_faa_charts(_faa_chart_dir()); results={}
 for k in FAA_CHARTS:
  try:results[k]=_build_faa_tiles(k,d)
  except Exception as e:results[k]={'ok':False,'error':str(e)[:300]}
 return {'ok':all(x.get('ok') for x in results.values()),'results':results}
@app.get('/faa-chart-manifest/{kind}')
def faa_chart_manifest(kind:str,request:Request,db:Session=Depends(get_db)):
 user_obj(request,db)
 if kind not in FAA_CHARTS:raise HTTPException(404)
 m=_chart_manifest(_seed_bundled_faa_charts(_faa_chart_dir()),kind)
 if not m:raise HTTPException(404,'Official FAA chart tile set is not installed.')
 return m
@app.get('/faa-chart-tile/{kind}/{z}/{x}/{y}.png')
def faa_chart_tile(kind:str,z:int,x:int,y:int,request:Request,db:Session=Depends(get_db)):
 user_obj(request,db)
 if kind not in FAA_CHARTS or min(z,x,y)<0:raise HTTPException(404)
 d=_seed_bundled_faa_charts(_faa_chart_dir()); m=_chart_manifest(d,kind)
 if not m or z>m['max_zoom']:raise HTTPException(404)
 path=os.path.join(d,kind,str(z),f'{x}_{y}.png')
 if not _valid_png(path):raise HTTPException(404)
 return FileResponse(path,media_type='image/png',headers={'Cache-Control':'public, max-age=86400'})
@app.get('/navigation-charts',response_class=HTMLResponse)
def navigation_charts(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); d=_seed_bundled_faa_charts(_faa_chart_dir()); installed={k:bool(_chart_manifest(d,k)) for k in FAA_CHARTS}; return html('navigation_charts.html',request,u,chart_installed=installed)

@app.get('/api/robinson-feed')
def robinson_feed(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db)
 import urllib.request,re as _re,html as _html
 url='https://www.robinsonheli.com/publications'
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'R22FlightSchool/73 publication-status-check'})
  with urllib.request.urlopen(req,timeout=8) as resp:
   raw=resp.read(2_000_001)
  if len(raw)>2_000_000: raise ValueError('Robinson response exceeded safety limit')
  text=_re.sub(r'\\s+',' ',_re.sub(r'<[^>]+>',' ',_html.unescape(raw.decode('utf-8','ignore'))))
  ids=[]
  for pat in (r'R22 SB-\\d+[A-Z]?',r'R22 SL-\\d+[A-Z]?',r'SN-\\d+'):
   ids.extend(_re.findall(pat,text))
  ids=list(dict.fromkeys(ids))[:120]
  return {'ok':True,'source':'Robinson Helicopter Company publications','items':ids}
 except Exception as e:
  return {'ok':False,'source':'cached offline snapshot','error':str(e)[:160],'items':[]}

@app.get('/robinson-safety',response_class=HTMLResponse)
def robinson_safety(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 current=[
  ('R22 POH FAA-approved page log','22 Feb 2024','POH / RFM'),
  ('R22 POH Safety Notice revision file','Jul 2025','Safety notices'),
  ('R22 Maintenance Manual','Aug 2026','Maintenance'),
  ('R22 Illustrated Parts Catalog','Sep 2026','Parts / systems'),
  ('R22 SB-123A','28 Jul 2026','Main rotor teeter/coning hinge bolt storage and inspection'),
  ('R22 SB-122','27 Jun 2024','Clutch assembly retainer replacement'),
  ('R22 SB-120C','28 Jan 2025','Tail rotor blade inspection/replacement; references AD 2024-04-02'),
  ('R22 SL-103','16 Dec 2025','B330 stamped nuts (palnuts) breakage'),
  ('R22 SL-102','09 Oct 2025','Main rotor blade leading-edge refinishing'),
  ('R22 SL-101','30 Sep 2025','Halotron BrX fire extinguisher conversion'),
  ('R22 SL-100','16 Sep 2025','Main rotor blade spindle bearing replacement'),
  ('R22 SL-99','01 Aug 2025','A257-25 lubricant usage'),
  ('Safety Notice SN-41','Jul 2025','Pilot distractions'),
  ('Safety Notice SN-22','Jan 2024','Vortex ring state avoidance, recognition and recovery')]
 return html('robinson_safety.html',request,u,current=current)
@app.get('/visual-training',response_class=HTMLResponse)
def visual_training(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); return html('visual_training.html',request,u)

@app.get('/rotor-controls',response_class=HTMLResponse)
def rotor_controls(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); return html('rotor_controls.html',request,u)

@app.get('/rotor-components',response_class=HTMLResponse)
def rotor_components(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); return html('rotor_components.html',request,u)

@app.get('/flight-planner',response_class=HTMLResponse)
def flight_planner(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); return html('flight_planner.html',request,u)

@app.get('/acs-task/{area}/{task}',response_class=HTMLResponse)
def acs_task(request:Request,area:str,task:str,db:Session=Depends(get_db)):
 u=user_obj(request,db); row=find_task(area.upper(),task.upper())
 if not row: raise HTTPException(404)
 return html('acs_task.html',request,u,task=row)

@app.get('/ground-school-compliance',response_class=HTMLResponse)
def ground_school_compliance(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); rows=coverage_rows()
 return html('ground_school_compliance.html',request,u,modules=GROUND_MODULES,hours=PART141_GROUND_HOURS,knowledge=PART61_KNOWLEDGE,flight_areas=FLIGHT_AREAS,experience=EXPERIENCE_61_109,approval=PART141_APPROVAL_GATES,stages=STAGES,acs_total=len(rows))

@app.get('/acs-coverage',response_class=HTMLResponse)
def acs_coverage(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); rows=coverage_rows(); return html('acs_coverage.html',request,u,areas=ACS_AREAS,rows=rows,total=len(rows),integrated=sum(r['status']=='integrated' for r in rows),partial=sum(r['status']=='partial' for r in rows),na=sum(r['na'] for r in rows))
class WBIn(BaseModel): empty_weight:float; empty_arm:float; pilot:float; passenger:float; left_bag:float; right_bag:float; main_fuel:float; aux_fuel:float; model:str='Beta II'; fuel_burn_gal:float=0; left_door_removed:bool=False; right_door_removed:bool=False; empty_lateral_arm:float=0; left_controls_removed:bool=False; accessory_weight:float=0; accessory_lateral_arm:float=0
class DAIn(BaseModel): elevation:float; altimeter:float; oat_c:float
class WindIn(BaseModel): course:float; tas:float; wind_from:float; wind_speed:float; distance:float
@app.post('/api/wb')
def api_wb(request:Request,p:WBIn,db:Session=Depends(get_db)): user_obj(request,db); return wb(**p.model_dump())
@app.post('/api/performance')
def api_perf(request:Request,p:DAIn,db:Session=Depends(get_db)): user_obj(request,db); return {'pressure_altitude':round(pressure_altitude(p.elevation,p.altimeter)),'density_altitude':density_altitude(p.elevation,p.altimeter,p.oat_c)}
@app.post('/api/wind')
def api_wind(request:Request,p:WindIn,db:Session=Depends(get_db)): user_obj(request,db); return wind_triangle(**p.model_dump())
@app.post('/api/e6b')
def api_e6b(request:Request,p:dict,db:Session=Depends(get_db)):
 user_obj(request,db); return e6b(float(p.get('cas',0)),float(p.get('pressure_altitude_ft',0)),float(p.get('oat_c',15)),float(p.get('true_course',0)),float(p.get('wind_from',0)),float(p.get('wind_speed',0)),float(p.get('distance_nm',0)),float(p.get('variation_deg',0)),float(p.get('deviation_deg',0)))
@app.post('/api/fuel')
def api_fuel(request:Request,p:dict,db:Session=Depends(get_db)):
 user_obj(request,db); return fuel_plan(float(p.get('main_gal',0)),float(p.get('aux_gal',0)),float(p.get('fuel_flow_gph',0)),float(p.get('planned_minutes',0)),float(p.get('reserve_minutes',20)))
@app.get('/poh',response_class=HTMLResponse)
def poh_mastery(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); records=db.query(TrainingRecord).filter_by(user_id=u.id,module='poh_mastery').order_by(TrainingRecord.id).all()
 progress={}
 for r in records:
  x=progress.setdefault(r.item,{'score':0,'complete':False,'attempts':0,'reviewed':[]}); x['attempts']+=1; x['score']=max(x['score'],round(r.score or 0)); x['complete']=x['complete'] or r.status=='complete'
  try:
   note=json.loads(r.notes or '{}'); x['reviewed']=sorted(set(x['reviewed'])|set(note.get('reviewed',[])))
  except Exception: pass
 complete_sections=sum(bool(progress.get(x['key'],{}).get('complete')) for x in POH_MASTERY_SECTIONS)
 final=progress.get('final',{'score':0,'complete':False,'attempts':0})
 return html('poh_mastery.html',request,u,sections=POH_MASTERY_SECTIONS,final_questions=POH_FINAL_QUESTIONS,progress=progress,complete_sections=complete_sections,final=final,total_sections=len(POH_MASTERY_SECTIONS))

@app.get('/poh/reference')
def poh_reference(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return FileResponse('data/R22_POH_reference.pdf',media_type='application/pdf',filename='R22_POH_reference.pdf')

@app.post('/api/poh-mastery/section')
async def poh_mastery_section(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); p=await request.json(); check_csrf(request,str(p.get('csrf','')))
 key=str(p.get('section','')); section=POH_MASTERY_MAP.get(key)
 if not section: raise HTTPException(404,'POH section not found')
 answers=p.get('answers',[]); reviewed={str(x) for x in p.get('reviewed',[]) if isinstance(x,(str,int))}
 if not isinstance(answers,list) or len(answers)!=len(section['questions']): raise HTTPException(400,'Complete every knowledge-check question')
 correct=[]
 for i,q in enumerate(section['questions']):
  try: selected=int(answers[i])
  except (TypeError,ValueError): selected=-1
  correct.append(selected==int(q['a']))
 score=round(100*sum(correct)/len(correct)); required={x['id'] for x in section['lessons']}; lessons_complete=required.issubset(reviewed); complete=lessons_complete and score>=80
 notes=json.dumps({'reviewed':sorted(reviewed & required),'correct':sum(correct),'total':len(correct)})
 db.add(TrainingRecord(user_id=u.id,module='poh_mastery',item=key,status='complete' if complete else 'attempted',score=score,notes=notes)); db.commit()
 feedback=[{'correct':correct[i],'answer':q['a'],'explanation':q['e']} for i,q in enumerate(section['questions'])]
 return {'ok':True,'score':score,'complete':complete,'lessons_complete':lessons_complete,'feedback':feedback}

@app.post('/api/poh-mastery/final')
async def poh_mastery_final(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); p=await request.json(); check_csrf(request,str(p.get('csrf','')))
 completed={r.item for r in db.query(TrainingRecord).filter_by(user_id=u.id,module='poh_mastery',status='complete').all()}
 section_keys={x['key'] for x in POH_MASTERY_SECTIONS}
 if not section_keys.issubset(completed): return JSONResponse({'ok':False,'error':'Complete all 10 POH sections before the final assessment.'},400)
 qs=POH_FINAL_QUESTIONS; answers=p.get('answers',[])
 if not isinstance(answers,list) or len(answers)!=len(qs): raise HTTPException(400,'Complete every final-assessment question')
 correct=[]
 for i,q in enumerate(qs):
  try: selected=int(answers[i])
  except (TypeError,ValueError): selected=-1
  correct.append(selected==int(q['a']))
 score=round(100*sum(correct)/len(correct)); complete=score>=80
 db.add(TrainingRecord(user_id=u.id,module='poh_mastery',item='final',status='complete' if complete else 'attempted',score=score,notes=json.dumps({'correct':sum(correct),'total':len(correct)}))); db.commit()
 return {'ok':True,'score':score,'complete':complete,'feedback':[{'correct':correct[i],'answer':q['a'],'explanation':q['e']} for i,q in enumerate(qs)]}

@app.get('/atc',response_class=HTMLResponse)
def atc(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); return html('atc.html',request,u,scenarios=ATC_SCENARIOS)
@app.post('/api/atc')
def atc_api(request:Request,p:dict,db:Session=Depends(get_db)):
 u=user_obj(request,db); msg=str(p.get('message','')).strip(); scenario=str(p.get('scenario','taxi')); sc=ATC_SCENARIOS.get(scenario,ATC_SCENARIOS['taxi']); lower=msg.lower(); hits=[x for x in sc['need'] if x in lower]; missing=[x for x in sc['need'] if x not in lower]; score=round(100*len(hits)/max(1,len(sc['need'])))
 if not msg: reply='Transmit when ready.'
 elif missing: reply='ATC: Helicopter 22BH, readback incomplete. Verify: '+', '.join(missing)+'.'
 else: reply=sc['next']
 db.add(ATCSession(user_id=u.id,scenario=scenario,transcript=json.dumps({'controller':sc['controller'],'student':msg,'reply':reply,'missing':missing}),score=score)); db.commit(); return {'reply':reply,'score':score,'missing':missing,'controller':sc['controller']}
ORALS=[
('What is the R22 Beta II maximum gross weight?',['1370'],'1370 lb for Alpha/Beta/Beta II; verify the model and aircraft records.','Why must aircraft-specific W&B still be used?'),
('What is the R22 minimum gross weight?',['920'],'920 lb.','Why can being under minimum weight matter even if CG appears acceptable?'),
('What is the maximum weight for one seat including its baggage compartment?',['240'],'240 lb combined seat plus associated baggage compartment.','What is the separate baggage-compartment limit?'),
('What is the maximum operating density altitude?',['14000'],'14,000 ft.','Does that guarantee hover capability at 14,000 ft?'),
('What is the immediate action for a power failure?',['lower','collective'],'Immediately lower collective to enter autorotation.','How does the procedure change with height AGL?'),
('For power failure above 500 ft AGL, what approximate airspeed is established?',['65'],'Approximately 65 KIAS.','What other priorities must be managed simultaneously?'),
('What rotor RPM range applies power-off?',['90','110'],'90-110 percent.','Why is rotor-energy management central to autorotation?'),
('What rotor RPM range normally applies power-on?',['101','104'],'Normally 101-104 percent, subject to the POH O-320 exception.','What systems help the pilot manage RPM?'),
('What is prohibited about low-G maneuvering?',['pushover','prohibited'],'Low-G cyclic pushovers are prohibited.','If low-G occurs and roll starts, which cyclic direction comes first?'),
('What is the low-G recovery sequence concept?',['aft','before','lateral'],'Gentle aft cyclic reloads the rotor before lateral cyclic correction.','Why can immediate lateral cyclic be hazardous?'),
('From which seat is solo flight permitted?',['right'],'Solo flight is from the right seat only.','What does the POH say about an instructor acting as PIC from the left seat?'),
('Is known icing flight approved?',['prohibited'],'No. Flight in known icing is prohibited.','What weather planning choices help avoid icing exposure?'),
('What equipment does the POH require operational for dispatch?',['alternator','governor','warning','oat'],'Alternator, RPM governor, low-rotor-RPM warning system and OAT gauge.','Why are these especially important in the R22?'),
('What is the usable main fuel capacity with bladder tanks?',['16.9'],'16.9 US gal usable.','What is usable auxiliary capacity?'),
('What is the usable auxiliary fuel capacity with bladder tanks?',['9.4'],'9.4 US gal usable.','What is combined usable capacity?'),
('What is the combined usable bladder-tank fuel capacity?',['26.3'],'26.3 US gal usable.','Why should actual fuel still be visually verified?'),
('What is the longitudinal arm for main fuel in the loading instructions?',['108.6'],'108.6 inches.','What is the auxiliary-fuel arm?'),
('What is the longitudinal arm for auxiliary fuel?',['103.8'],'103.8 inches.','How does fuel burn move CG in a sample loading?'),
('What performance penalty can full carb heat cause to hover ceiling?',['2000'],'The POH warns of up to a 2,000-ft reduction.','How should that affect a marginal hover-performance decision?'),
('What does the POH say about performance data conditions?',['ideal'],'Section 5 data were obtained under ideal conditions; actual performance can be substantially less.','How should a pilot build margin into planning?'),
('What are the four major R22 control inputs?',['cyclic','collective','pedal','throttle'],'Cyclic, collective, anti-torque pedals and throttle, with governor assistance as applicable.','Describe how a collective change affects power demand and anti-torque requirement.'),
('What is the purpose of the RPM governor?',['rpm','throttle'],'It assists in maintaining engine/rotor RPM by controlling throttle in its operating range.','What must the pilot do if the governor fails?'),
('What is the first priority in an electrical fire procedure?',['battery','alternator','off'],'The POH calls for battery and alternator switches OFF, followed by the complete procedure.','What capability may be affected when electrical power is removed?'),
('How does tail-rotor-thrust loss in forward flight begin?',['autorotation'],'Immediately enter autorotation.','What minimum forward airspeed is specified if practical?'),
('What does Safety Notice SN-15 emphasize about fuel planning?',['20','fuel'],'Plan fuel so at least 20 minutes remains and do not rely solely on the gauge/low-fuel light.','What preflight fuel checks are emphasized?'),
('What wind limit from FAA AD 95-26-04 applies unless the listed experience/training exception is met?',['25'],'Surface winds over 25 kt, including gusts, are prohibited under the stated conditions.','What gust-spread limit accompanies it?'),
('What gust-spread limit from FAA AD 95-26-04 applies unless the exception is met?',['15'],'Gust spread over 15 kt is prohibited under the stated conditions.','What does the AD say about continued flight in moderate-or-greater turbulence?'),
('Why is the height-velocity diagram part of takeoff planning?',['autorotation','height','airspeed'],'It identifies height/airspeed combinations associated with reduced capability for a successful autorotation after power loss.','How can takeoff technique reduce exposure?'),
('Why must both takeoff and empty-fuel loading be checked?',['cg','fuel'],'Fuel burn changes weight and moment, so loading must remain within applicable limits throughout the flight.','What additional landing condition should be considered?'),
('What is the role of Section 9 supplements?',['equipment','supplement'],'Installed equipment or special configurations can add or change limitations/procedures.','What should you verify before using generic R22 data?')]

@app.get('/oral',response_class=HTMLResponse)
def oral(request:Request,db:Session=Depends(get_db)): return html('oral.html',request,user_obj(request,db),question=ORALS[0][0])
@app.post('/api/oral')
def oral_api(request:Request,p:dict,db:Session=Depends(get_db)):
 u=user_obj(request,db); answer=str(p.get('answer','')); question=str(p.get('question',ORALS[0][0])); item=next((x for x in ORALS if x[0]==question),ORALS[0]); hits=sum(k in answer.lower() for k in item[1]); score=hits/len(item[1]); feedback=('Strong answer. ' if score>=.75 else 'Needs review. ')+item[2]; nxt=ORALS[(ORALS.index(item)+1)%len(ORALS)][0]; db.add(OralSession(user_id=u.id,transcript=json.dumps({'q':question,'a':answer,'feedback':feedback}),score=score)); db.commit(); return {'feedback':feedback,'score':score,'next':nxt}
@app.get('/profile',response_class=HTMLResponse)
def profile(request:Request,db:Session=Depends(get_db)): return html('profile.html',request,user_obj(request,db))
@app.post('/profile/password')
def password_change(request:Request,current_password:str=Form(),new_password:str=Form(),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if not verify(current_password,u.password_hash): return RedirectResponse('/profile?error=1',303)
 try: u.password_hash=hash_password(new_password)
 except ValueError: return RedirectResponse('/profile?weak=1',303)
 u.must_change_password=False; db.add(Audit(user_id=u.id,action='password_change',detail='')); db.commit(); return RedirectResponse('/dashboard',303)
@app.get('/admin',response_class=HTMLResponse)
def admin(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 if u.role not in ('admin','instructor'): raise HTTPException(403)
 users=db.query(User).order_by(User.role,User.username).all(); students=db.query(User).filter(User.role=='student',User.active==True).all(); instructors=db.query(User).filter(User.role.in_(['instructor','admin']),User.active==True).all(); audits=db.query(Audit).order_by(Audit.created_at.desc()).limit(100).all(); chart_path=os.path.abspath('app/static/faa_sectional_long_beach.png'); faa_status={'acs':'FAA-S-ACS-15','chart_edition':'Sep 03 2026','next_chart':'Oct 29 2026','chart_name':'FAA Long Beach / KLGB training excerpt','chart_installed':os.path.exists(chart_path),'chart_bytes':os.path.getsize(chart_path) if os.path.exists(chart_path) else 0}; return html('admin.html',request,u,users=users,students=students,instructors=instructors,audits=audits,faa_status=faa_status)

@app.post('/admin/faa-content/update')
def update_faa_content(request:Request,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 try:
  from .faa_content import install_long_beach_chart
  result=install_long_beach_chart()
  db.add(Audit(user_id=u.id,action='faa_content_update',detail='Official FAA Los Angeles Sectional GeoTIFF installed and KLGB training crop rebuilt: '+result['edition'])); db.commit()
  return RedirectResponse('/admin?faa_updated=1',303)
 except Exception as e:
  db.add(Audit(user_id=u.id,action='faa_content_update_failed',detail=str(e)[:250])); db.commit()
  return RedirectResponse('/admin?faa_update_error=1',303)

@app.post('/admin/users')
def add_user(request:Request,username:str=Form(),full_name:str=Form(),role:str=Form(),password:str=Form(),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 if role not in ('student','instructor','admin') or db.query(User).filter(User.username==username.strip()).first(): raise HTTPException(400,'Invalid/duplicate user')
 db.add(User(username=username.strip(),full_name=full_name.strip(),role=role,password_hash=hash_password(password),must_change_password=True)); db.add(Audit(user_id=u.id,action='create_user',detail=username)); db.commit(); return RedirectResponse('/admin',303)
@app.post('/admin/users/{uid}/toggle')
def toggle_user(request:Request,uid:int,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin' or uid==u.id: raise HTTPException(403)
 x=db.get(User,uid); x.active=not x.active; db.add(Audit(user_id=u.id,action='toggle_user',detail=f'{uid}:{x.active}')); db.commit(); return RedirectResponse('/admin',303)
@app.post('/admin/users/{uid}/reset-password')
def reset_user_password(request:Request,uid:int,password:str=Form(),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 x=db.get(User,uid)
 if not x: raise HTTPException(404)
 x.password_hash=hash_password(password); x.must_change_password=True; db.add(Audit(user_id=u.id,action='reset_password',detail=str(uid))); db.commit(); return RedirectResponse('/admin',303)

@app.post('/admin/users/{uid}/delete')
def delete_user(request:Request,uid:int,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin' or uid==u.id: raise HTTPException(403)
 x=db.get(User,uid)
 if not x: raise HTTPException(404)
 db.add(Audit(user_id=u.id,action='delete_user',detail=f'{x.username}:{uid}')); db.query(Assignment).filter(Assignment.instructor_id==uid).delete(synchronize_session=False); db.delete(x); db.commit(); return RedirectResponse('/admin',303)


@app.get('/question-bank',response_class=HTMLResponse)
def question_bank_page(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 counts={t:db.query(Question).filter(Question.track==t,Question.active==True).count() for t in ('PPL','R22','IFR')}
 sources={k:v for k,v in db.query(Question.source_kind,func.count(Question.id)).filter(Question.active==True).group_by(Question.source_kind).all()}
 areas={t:db.query(Question.area,func.count(Question.id)).filter(Question.track==t,Question.active==True).group_by(Question.area).order_by(Question.area).all() for t in ('PPL','R22','IFR')}
 return html('question_bank.html',request,u,counts=counts,sources=sources,areas=areas)

@app.get('/admin/questions/template.csv')
def question_template(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 path=os.path.abspath('data/question_bank_template.csv')
 return FileResponse(path,media_type='text/csv',filename='r22_question_bank_template.csv')

@app.get('/admin/questions/template.txt')
def question_template_txt(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 path=os.path.abspath('data/question_bank_template.txt')
 return FileResponse(path,media_type='text/plain',filename='r22_question_bank_template.txt')

@app.post('/admin/questions/import')
async def import_questions(request:Request,file:UploadFile=File(),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 raw=await file.read(); textdata=raw.decode('utf-8-sig'); added=0
 required={'track','area','prompt','a','b','c','correct','explanation','reference'}
 name=(file.filename or '').lower()
 if name.endswith('.txt'):
  # Offline TXT format is tab-delimited with the same named columns as CSV.
  rows=list(csv.DictReader(io.StringIO(textdata),delimiter='\t'))
 else:
  rows=list(csv.DictReader(io.StringIO(textdata)))
 for row in rows:
  if not required.issubset(row) or row.get('correct','').upper() not in ('A','B','C'): continue
  db.add(Question(track=row['track'][:20],area=row['area'][:80],prompt=row['prompt'],a=row['a'],b=row['b'],c=row['c'],correct=row['correct'].upper(),explanation=row['explanation'],reference=row['reference'][:200],difficulty=max(1,min(5,int(row.get('difficulty') or 1))),source_kind=(row.get('source_kind') or 'imported')[:30])); added+=1
 db.add(Audit(user_id=u.id,action='question_import',detail=f'{file.filename}:{added}')); db.commit(); return RedirectResponse(f'/admin?imported={added}',303)

@app.post('/admin/training/reset/{uid}')
def reset_training_data(request:Request,uid:int,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 target=db.get(User,uid)
 if not target: raise HTTPException(404)
 # Reset only derived/student training history; preserve account and aircraft profile.
 for model in (ExamItem,Certificate,Exam,Attempt,Mastery,TrainingRecord,ATCSession,OralSession):
  db.query(model).filter(model.user_id==uid).delete(synchronize_session=False)
 db.add(Audit(user_id=u.id,action='reset_training_data',detail=f'{target.username}:{uid}')); db.commit()
 return RedirectResponse('/admin?training_reset=1',303)

@app.post('/admin/assign')
def assign(request:Request,student_id:int=Form(),title:str=Form(),details:str=Form(),instructor_id:int|None=Form(None),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role not in ('admin','instructor'): raise HTTPException(403)
 owner=u.id if u.role=='instructor' else (instructor_id or u.id); inst=db.get(User,owner); st=db.get(User,student_id)
 if not inst or inst.role not in ('admin','instructor') or not st or st.role!='student': raise HTTPException(400,'Invalid instructor/student')
 db.add(Assignment(instructor_id=owner,student_id=student_id,title=title[:160],details=details)); db.commit(); return RedirectResponse('/admin',303)

@app.post('/assignments/{aid}/complete')
def assignment_complete(request:Request,aid:int,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db); a=db.get(Assignment,aid)
 if not a or a.student_id!=u.id: raise HTTPException(404)
 a.completed=True; db.add(Audit(user_id=u.id,action='assignment_complete',detail=str(aid))); db.commit(); return RedirectResponse('/dashboard',303)

def _backup_dir():
 data=os.path.abspath(os.getenv('R22_DATA_DIR','./data')); p=os.path.join(os.path.dirname(data),'backups'); os.makedirs(p,exist_ok=True); return p
def _sqlite_path():
 url=os.getenv('DATABASE_URL');
 if url: return url.replace('sqlite:///','',1) if url.startswith('sqlite:///') else None
 return os.path.join(os.path.abspath(os.getenv('R22_DATA_DIR','./data')),'r22school.db')
def _make_backup():
 stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S'); bdir=_backup_dir(); sp=_sqlite_path()
 if sp:
  dest=os.path.join(bdir,f'r22school_{stamp}.db'); a=sqlite3.connect(sp); b=sqlite3.connect(dest); a.backup(b); b.close(); a.close(); return dest
 if not shutil.which('pg_dump'): raise RuntimeError('PostgreSQL backup requires pg_dump installed on the server.')
 dest=os.path.join(bdir,f'r22school_{stamp}.dump'); subprocess.run(['pg_dump',os.environ['DATABASE_URL'],'-Fc','-f',dest],check=True); return dest
def _backup_files():
 out=[]
 for n in os.listdir(_backup_dir()):
  if n.startswith('r22school_') and (n.endswith('.db') or n.endswith('.dump')):
   p=os.path.join(_backup_dir(),n); out.append((n,os.path.getsize(p),datetime.datetime.fromtimestamp(os.path.getmtime(p))))
 return sorted(out,key=lambda x:x[2],reverse=True)
@app.get('/admin/backups',response_class=HTMLResponse)
def backups_page(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 return html('backups.html',request,u,backups=_backup_files(),dbtype='SQLite' if _sqlite_path() else 'PostgreSQL')
@app.post('/admin/backups/create')
def backup_create(request:Request,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 try: p=_make_backup()
 except Exception as e: raise HTTPException(500,str(e))
 db.add(Audit(user_id=u.id,action='backup_create',detail=os.path.basename(p))); db.commit(); return RedirectResponse('/admin/backups?created=1',303)
@app.get('/admin/backups/{name}/download')
def backup_download(request:Request,name:str,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 if u.role!='admin': raise HTTPException(403)
 if '/' in name or '\\' in name or not name.startswith('r22school_'): raise HTTPException(400)
 p=os.path.join(_backup_dir(),name)
 if not os.path.isfile(p): raise HTTPException(404)
 return FileResponse(p,filename=name,media_type='application/octet-stream')
@app.post('/admin/backups/{name}/restore')
def backup_restore(request:Request,name:str,confirm:str=Form(),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if u.role!='admin' or confirm!='RESTORE': raise HTTPException(400,'Type RESTORE to confirm.')
 if '/' in name or '\\' in name or not name.startswith('r22school_'): raise HTTPException(400)
 src=os.path.join(_backup_dir(),name)
 if not os.path.isfile(src): raise HTTPException(404)
 sp=_sqlite_path()
 if not sp or not name.endswith('.db'): raise HTTPException(409,'In-app restore is supported for the default SQLite deployment. Use the supplied PostgreSQL restore procedure for PostgreSQL.')
 c=sqlite3.connect(src); chk=c.execute('PRAGMA integrity_check').fetchone()[0]; c.close()
 if chk!='ok': raise HTTPException(400,'Selected backup failed SQLite integrity check.')
 _make_backup(); db.close(); engine.dispose(); shutil.copy2(src,sp); r=RedirectResponse('/?restored=1',303); r.delete_cookie('session'); return r

@app.get('/instructor',response_class=HTMLResponse)
def instructor_dashboard(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 if u.role not in ('admin','instructor'): raise HTTPException(403)
 students=db.query(User).filter(User.role=='student',User.active==True).order_by(User.full_name,User.username).all() if u.role=='admin' else db.query(User).join(Assignment,Assignment.student_id==User.id).filter(User.role=='student',User.active==True,Assignment.instructor_id==u.id).distinct().order_by(User.full_name,User.username).all(); rows=[]
 for st in students:
  ats=db.query(Attempt).filter(Attempt.user_id==st.id).all(); exams=db.query(Exam).filter(Exam.user_id==st.id).order_by(Exam.created_at.desc()).all(); atcs=db.query(ATCSession).filter(ATCSession.user_id==st.id).order_by(ATCSession.created_at.desc()).all(); orals=db.query(OralSession).filter(OralSession.user_id==st.id).order_by(OralSession.created_at.desc()).all(); done=db.query(TrainingRecord).filter_by(user_id=st.id,module='syllabus').count()
  rows.append({'student':st,'accuracy':round(100*sum(x.correct for x in ats)/len(ats)) if ats else 0,'roadmap':round(100*done/len(SYLLABUS)),'exam':round(exams[0].score) if exams else 0,'atc':round(atcs[0].score) if atcs else 0,'oral':round(orals[0].score*100) if orals else 0,'assignments':db.query(Assignment).filter_by(student_id=st.id,completed=False).count()})
 return html('instructor.html',request,u,rows=rows)

@app.get('/instructor/student/{uid}',response_class=HTMLResponse)
def instructor_student(request:Request,uid:int,db:Session=Depends(get_db)):
 u=user_obj(request,db)
 if u.role not in ('admin','instructor'): raise HTTPException(403)
 st=db.get(User,uid)
 if not st or st.role!='student': raise HTTPException(404)
 if u.role=='instructor' and not db.query(Assignment).filter_by(instructor_id=u.id,student_id=uid).first(): raise HTTPException(403)
 return html('student_detail.html',request,u,student=st,mastery=db.query(Mastery).filter_by(user_id=uid).order_by(Mastery.score).all(),exams=db.query(Exam).filter_by(user_id=uid).order_by(Exam.created_at.desc()).limit(20).all(),atc=db.query(ATCSession).filter_by(user_id=uid).order_by(ATCSession.created_at.desc()).limit(20).all(),oral=db.query(OralSession).filter_by(user_id=uid).order_by(OralSession.created_at.desc()).limit(20).all(),logs=db.query(FlightLog).filter_by(user_id=uid).order_by(FlightLog.id.desc()).limit(20).all(),assignments=db.query(Assignment).filter_by(student_id=uid).order_by(Assignment.created_at.desc()).all())

@app.get('/syllabus',response_class=HTMLResponse)
def syllabus(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); done={r.item for r in db.query(TrainingRecord).filter(TrainingRecord.user_id==u.id,TrainingRecord.module=='syllabus',TrainingRecord.status=='complete').all()}; return html('syllabus.html',request,u,syllabus=SYLLABUS,done=done,roadmap_links=ROADMAP_LINKS)
@app.post('/syllabus/{key}/complete')
def syllabus_complete(request:Request,key:str,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db); item=next((x for x in SYLLABUS if x[0]==key),None)
 if not item: raise HTTPException(404)
 # v25: roadmap completion is earned, never granted by simply pressing a button.
 lesson=db.query(LessonProgress).filter_by(user_id=u.id,lesson_key=key,completed=True).first()
 qualified=bool(lesson)
 if key=='written': qualified=qualified and db.query(Exam).filter(Exam.user_id==u.id,Exam.track=='PPL',Exam.total>=60,Exam.score>=70).first() is not None
 if key=='preflight':
  qualified=qualified and db.query(TrainingRecord).filter(TrainingRecord.user_id==u.id,TrainingRecord.module.in_(['startup','cockpit_flow']),TrainingRecord.status=='complete',TrainingRecord.score>=70).first() is not None
 if key=='emergency': qualified=qualified and db.query(TrainingRecord).filter_by(user_id=u.id,module='emergency',status='complete').count()>=3
 if key=='atc': qualified=qualified and db.query(ATCSession).filter(ATCSession.user_id==u.id,ATCSession.score>=70).count()>=3
 if key=='oral': qualified=qualified and db.query(OralSession).filter(OralSession.user_id==u.id,OralSession.score>=.7).count()>=3
 if qualified:
  rec=db.query(TrainingRecord).filter_by(user_id=u.id,module='syllabus',item=key).first()
  if not rec: db.add(TrainingRecord(user_id=u.id,module='syllabus',item=key,status='complete',score=100,notes='v25 verified completion criteria'))
  else: rec.status='complete'; rec.score=100
  db.commit(); return RedirectResponse('/syllabus?verified=1',303)
 return RedirectResponse(f'/syllabus?incomplete={key}',303)
@app.get('/emergency',response_class=HTMLResponse)
def emergency(request:Request,scenario:str='power_high',db:Session=Depends(get_db)):
 u=user_obj(request,db); return html('emergency.html',request,u,scenario=scenario,item=EMERGENCIES.get(scenario,EMERGENCIES['power_high']),scenarios=EMERGENCIES)
@app.post('/api/emergency')
def emergency_api(request:Request,p:dict,db:Session=Depends(get_db)):
 u=user_obj(request,db); key=str(p.get('scenario','power_high')); ans=str(p.get('answer','')).lower(); item=EMERGENCIES.get(key,EMERGENCIES['power_high']); missing=[k for k in item['keys'] if k not in ans]; score=round(100*(len(item['keys'])-len(missing))/len(item['keys'])); db.add(TrainingRecord(user_id=u.id,module='emergency',item=key,status='complete' if score>=70 else 'attempted',score=score,notes=ans[:2000])); db.commit(); return {'score':score,'missing':missing,'feedback':item['feedback']}
CHECKRIDE_MODULES=[
 ('21-day','21-Day Checkride Countdown','Start early: build a three-week plan that alternates ACS knowledge, R22 POH mastery, flight proficiency, oral practice, and mock evaluations.'),
 ('acs','Master the Current ACS','Work FAA-S-ACS-15 by Area of Operation and Task. Demonstrate knowledge, risk management, and flight proficiency; opening a lesson does not count as mastery.'),
 ('eligibility','Eligibility & Pilot Logbook Audit','Verify certificate/medical applicability, knowledge-test report, aeronautical experience, instructor endorsements, IACRA/application readiness, and logbook totals.'),
 ('airworthiness','Aircraft Records & Airworthiness','Practice locating registration, airworthiness certificate, operating limitations/approved flight manual, equipment list, maintenance records, inspections and applicable AD compliance.'),
 ('repetition','Repetition & Weak-Area Drill','Use missed questions, flashcards, oral sessions and ACS weak areas until performance is repeatable rather than memorized for one attempt.'),
 ('arrival','Checkride-Day Timeline','Plan an early arrival, aircraft preparation, weather and performance review, records staging, personal needs, and contingency time.'),
 ('documents','Document Staging','Stage photo ID, pilot certificate, medical when required, knowledge-test report, application/IACRA information, logbook/endorsements, aircraft documents, records, charts and required equipment.'),
 ('process','What the Checkride Actually Does','Understand the administrative/pretest phase, oral questioning, preflight and flight evaluation, ACS standards, evaluator plan of action, outcomes, discontinuance and unsatisfactory performance.'),
 ('oral','Disciplined Oral Answers','Answer the question asked; state the answer and important qualifier; cite or locate the controlling source when appropriate; do not guess.'),
 ('retest','Unsatisfactory Result & Retest','Treat a failed task as actionable training data. Review the notice, receive required additional training/endorsement, correct the deficiency, and prepare for retest.'),
 ('final','Final R22 Review','Recheck limitations, systems, normal/emergency procedures, performance, weight and balance, weather, airspace, navigation, regulations and scenario risk management.'),
 ('mock','Examiner-Style Mock Checkride','Run mixed scenarios without hints. Require source-based oral answers, risk decisions and ACS-level flight-task preparation before marking readiness.')]
from app.flashcard_deck import FLASHCARD_DECK

@app.get('/checkride-center',response_class=HTMLResponse)
def checkride_center(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); done={r.item for r in db.query(TrainingRecord).filter_by(user_id=u.id,module='checkride_center',status='complete').all()}
 return html('checkride_center.html',request,u,modules=CHECKRIDE_MODULES,done=done)
@app.post('/checkride-center/{key}/complete')
def checkride_complete(request:Request,key:str,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if key not in {x[0] for x in CHECKRIDE_MODULES}: raise HTTPException(404)
 r=db.query(TrainingRecord).filter_by(user_id=u.id,module='checkride_center',item=key).first()
 if not r: db.add(TrainingRecord(user_id=u.id,module='checkride_center',item=key,status='complete',score=100))
 else: r.status='complete'; r.score=100
 db.commit(); return RedirectResponse('/checkride-center',303)
@app.get('/flashcards',response_class=HTMLResponse)
def flashcards(request:Request,db:Session=Depends(get_db)): return html('flashcards.html',request,user_obj(request,db),cards=FLASHCARD_DECK)
@app.get('/vfr-reference',response_class=HTMLResponse)
def vfr_reference(request:Request,db:Session=Depends(get_db)): return html('vfr_reference.html',request,user_obj(request,db))
@app.get('/checklist-reference',response_class=HTMLResponse)
def checklist_reference(request:Request,db:Session=Depends(get_db)): return html('checklist_reference.html',request,user_obj(request,db))
@app.get('/checklist-reference/print',response_class=HTMLResponse)
def checklist_reference_print(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return tpl.TemplateResponse(request,'checklist_reference_print.html',{'request':request,'app_version':APP_VERSION})

@app.get('/flight-plan/print',response_class=HTMLResponse)
def flight_plan_print(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return tpl.TemplateResponse(request,'flight_plan_print.html',{'request':request,'app_version':APP_VERSION})

@app.get('/startup-reference',response_class=HTMLResponse)
def startup_reference(request:Request,db:Session=Depends(get_db)): return html('startup_reference.html',request,user_obj(request,db))

@app.get('/logbook',response_class=HTMLResponse)
def logbook(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); logs=db.query(FlightLog).filter(FlightLog.user_id==u.id).order_by(FlightLog.id.desc()).all()
 keys=['dual_hours','solo_hours','ground_trainer_hours','day_hours','night_hours','cross_country_hours','actual_instrument_hours','simulated_instrument_hours','day_landings','night_landings','total_duration']
 totals={k:sum((getattr(x,k,0) or 0) for x in logs) for k in keys}; totals['landings']=sum((x.landings or 0) for x in logs)
 return html('logbook.html',request,u,logs=logs,totals=totals)
@app.post('/logbook')
def logbook_add(request:Request,flight_date:str=Form(),aircraft:str=Form('R22'),tail_number:str=Form(''),dual_hours:float=Form(0),solo_hours:float=Form(0),ground_trainer_hours:float=Form(0),day_hours:float=Form(0),night_hours:float=Form(0),cross_country_hours:float=Form(0),actual_instrument_hours:float=Form(0),simulated_instrument_hours:float=Form(0),day_landings:int=Form(0),night_landings:int=Form(0),total_duration:float=Form(0),instructor_approval:str=Form(''),maneuvers:str=Form(''),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 inst=actual_instrument_hours+simulated_instrument_hours; landings=day_landings+night_landings
 db.add(FlightLog(user_id=u.id,flight_date=flight_date,aircraft=aircraft[:80],tail_number=tail_number[:20],dual_hours=dual_hours,solo_hours=solo_hours,ground_trainer_hours=ground_trainer_hours,day_hours=day_hours,night_hours=night_hours,cross_country_hours=cross_country_hours,actual_instrument_hours=actual_instrument_hours,simulated_instrument_hours=simulated_instrument_hours,instrument_hours=inst,day_landings=day_landings,night_landings=night_landings,landings=landings,total_duration=total_duration,instructor_approval=instructor_approval[:120],maneuvers=maneuvers[:3000])); db.commit(); return RedirectResponse('/logbook',303)
@app.get('/checklists',response_class=HTMLResponse)
def checklists(request:Request,db:Session=Depends(get_db)):
 return html('checklists.html',request,user_obj(request,db))

@app.get('/knowledge')
def knowledge(request:Request,db:Session=Depends(get_db)):
 user_obj(request,db); return RedirectResponse('/poh',303)
@app.get('/charts',response_class=HTMLResponse)
def charts(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); labels=[(70,'Airspeed calibration'),(71,'Density altitude'),(72,'IGE - R22 Standard'),(73,'IGE - R22 HP/Alpha/Beta'),(74,'IGE - R22 Beta II'),(75,'OGE - R22 Standard'),(76,'OGE - R22 HP/Alpha'),(77,'OGE - R22 Beta'),(78,'OGE - R22 Beta II'),(79,'Height-velocity diagram')]; return html('charts.html',request,u,charts=labels)
@app.get('/aircraft',response_class=HTMLResponse)
def aircraft_page(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); return html('aircraft.html',request,u,aircraft=db.query(AircraftProfile).filter_by(user_id=u.id).all())
@app.post('/aircraft')
def aircraft_add(request:Request,name:str=Form(),model:str=Form(),tail_number:str=Form(''),empty_weight:float=Form(),empty_arm:float=Form(),notes:str=Form(''),csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db)
 if empty_weight<=0 or empty_arm<=0 or model not in ('Beta II','Beta','Alpha','Standard','HP'): raise HTTPException(400,'Invalid aircraft data')
 db.add(AircraftProfile(user_id=u.id,name=name[:80],model=model,tail_number=tail_number[:20],empty_weight=empty_weight,empty_arm=empty_arm,notes=notes[:2000])); db.commit(); return RedirectResponse('/aircraft',303)
@app.get('/tracker',response_class=HTMLResponse)
def tracker(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); tracks=db.query(FlightTrack).filter_by(user_id=u.id).order_by(FlightTrack.created_at.desc()).limit(30).all(); return html('tracker.html',request,u,tracks=tracks)
def _nm(a,b):
 import math
 la1,lo1,la2,lo2=map(math.radians,[a['lat'],a['lon'],b['lat'],b['lon']]); h=math.sin((la2-la1)/2)**2+math.cos(la1)*math.cos(la2)*math.sin((lo2-lo1)/2)**2; return 3440.065*2*math.asin(min(1,math.sqrt(h)))
@app.post('/api/track')
def save_track(request:Request,p:dict,db:Session=Depends(get_db)):
 u=user_obj(request,db); pts=p.get('points',[])
 if not isinstance(pts,list) or len(pts)<2 or len(pts)>20000: raise HTTPException(400,'Invalid track')
 clean=[]
 for x in pts:
  try: lat=float(x['lat']); lon=float(x['lon'])
  except: raise HTTPException(400,'Invalid GPS fix')
  if not (-90<=lat<=90 and -180<=lon<=180): raise HTTPException(400,'Invalid GPS fix')
  clean.append({'lat':round(lat,6),'lon':round(lon,6),'alt':x.get('alt'),'t':x.get('t'),'acc':x.get('acc')})
 dist=sum(_nm(a,b) for a,b in zip(clean,clean[1:])); dur=max(0,min(int(p.get('duration_seconds',0)),86400)); row=FlightTrack(user_id=u.id,title=str(p.get('title','Training flight'))[:120],points=json.dumps(clean),duration_seconds=dur,distance_nm=dist); db.add(row); db.commit(); return {'saved':True,'points':len(clean),'distance_nm':round(dist,2)}
@app.post('/aircraft/{pid}/delete')
def aircraft_delete(request:Request,pid:int,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db); x=db.get(AircraftProfile,pid)
 if not x or x.user_id!=u.id: raise HTTPException(404)
 db.delete(x); db.commit(); return RedirectResponse('/aircraft',303)
@app.post('/logbook/{lid}/delete')
def logbook_delete(request:Request,lid:int,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db); x=db.get(FlightLog,lid)
 if not x or x.user_id!=u.id: raise HTTPException(404)
 db.delete(x); db.commit(); return RedirectResponse('/logbook',303)
@app.post('/tracker/{tid}/delete')
def tracker_delete(request:Request,tid:int,csrf:str=Form(),db:Session=Depends(get_db)):
 check_csrf(request,csrf); u=user_obj(request,db); x=db.get(FlightTrack,tid)
 if not x or x.user_id!=u.id: raise HTTPException(404)
 db.delete(x); db.commit(); return RedirectResponse('/tracker',303)

@app.get('/readiness',response_class=HTMLResponse)
def readiness(request:Request,db:Session=Depends(get_db)):
 u=user_obj(request,db); done={r.item for r in db.query(TrainingRecord).filter_by(user_id=u.id,module='syllabus',status='complete').all()}; exams=db.query(Exam).filter_by(user_id=u.id).all(); atc=db.query(ATCSession).filter_by(user_id=u.id).all(); oral=db.query(OralSession).filter_by(user_id=u.id).all(); emergency=db.query(TrainingRecord).filter_by(user_id=u.id,module='emergency').all()
 qual_exams=[x for x in exams if (x.total or 0)>=10]
 qual_em=[]
 for x in emergency:
  try:
   meta=json.loads(x.notes or '{}')
  except Exception:
   meta={}
  if x.status=='complete' and int(meta.get('completed',0) or 0)>0: qual_em.append(x)
 metrics={'Roadmap':round(100*len(done)/len(SYLLABUS)),'Written':round(sum(x.score for x in qual_exams[-3:])/len(qual_exams[-3:])) if qual_exams else 0,'ATC':round(sum(x.score for x in atc[-5:])/len(atc[-5:])) if len(atc)>=3 else 0,'Oral':round(100*sum(x.score for x in oral[-5:])/len(oral[-5:])) if len(oral)>=3 else 0,'Emergencies':round(sum(x.score for x in qual_em[-5:])/len(qual_em[-5:])) if len(qual_em)>=3 else 0}; return html('readiness.html',request,u,metrics=metrics,areas=CHECKRIDE_AREAS)
@app.get('/manifest.webmanifest')
def manifest(): return FileResponse('app/manifest.webmanifest',media_type='application/manifest+json')
