#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
echo 'Installing R22 Flight School for Linux...'
install_apt(){ sudo apt-get update; sudo apt-get install -y python3 python3-venv python3-pip curl; }
install_dnf(){ sudo dnf install -y python3 python3-pip python3-devel curl; }
if ! command -v python3 >/dev/null; then
  if command -v apt-get >/dev/null; then install_apt; elif command -v dnf >/dev/null; then install_dnf; else echo 'Install Python 3.11+ and rerun.'; exit 1; fi
fi
python3 - <<'PY' || { echo 'Python 3.11+ is required.'; exit 1; }
import sys; assert sys.version_info >= (3,11), sys.version
PY
if ! python3 -m venv .venv 2>/dev/null; then
  if command -v apt-get >/dev/null; then install_apt; python3 -m venv .venv; else echo 'python3 venv support is required.'; exit 1; fi
fi
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
mkdir -p data backups "$HOME/.local/share/applications"
PERSIST_ROOT="$HOME/.local/share/r22-flight-school"; PERSIST_DATA="$PERSIST_ROOT/data"; PERSIST_BACKUPS="$PERSIST_ROOT/backups"; mkdir -p "$PERSIST_DATA" "$PERSIST_BACKUPS"
if [ -f "$ROOT/data/r22school.db" ] && [ ! -f "$PERSIST_DATA/r22school.db" ]; then cp "$ROOT/data/r22school.db" "$PERSIST_DATA/r22school.db"; echo "Migrated existing R22 user database to persistent storage."; fi
if [ ! -f .env ]; then
  cp .env.example .env
  SECRET="$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')"
  sed -i "s#^SECRET_KEY=.*#SECRET_KEY=$SECRET#" .env
fi
if grep -q '^R22_DATA_DIR=' .env; then sed -i "s#^R22_DATA_DIR=.*#R22_DATA_DIR=$PERSIST_DATA#" .env; else echo "R22_DATA_DIR=$PERSIST_DATA" >> .env; fi
if grep -q '^DATABASE_URL=sqlite' .env; then sed -i "s#^DATABASE_URL=.*#DATABASE_URL=sqlite:///$PERSIST_DATA/r22school.db#" .env; fi
set -a; . ./.env; set +a
echo 'Installing required FAA Los Angeles Sectional, TAC, and Helicopter Route charts...'
python deploy/install_faa_charts.py 2>&1 | tee FAA_CHART_INSTALL.log || { echo 'ERROR: required FAA chart installation failed. Installation cannot complete without the offline chart lab. See FAA_CHART_INSTALL.log.'; exit 1; }
echo 'FAA offline chart payload verified.'
python -c 'from app.main import startup; startup(); print("Database initialized")'
# Native application-menu launcher and optional desktop launcher.
ICON="$ROOT/app/static/icons/icon-512.png"
DESKTOP_FILE="$HOME/.local/share/applications/r22-flight-school.desktop"
cat > "$DESKTOP_FILE" <<EOF
[Desktop Entry]
Type=Application
Name=R22 Flight School
Comment=Start R22 Flight School
Exec="$ROOT/deploy/start_linux.sh"
Icon=$ICON
Terminal=false
Categories=Education;Utility;
StartupNotify=true
EOF
chmod +x "$DESKTOP_FILE"
if [ -d "$HOME/Desktop" ]; then cp "$DESKTOP_FILE" "$HOME/Desktop/R22 Flight School.desktop"; chmod +x "$HOME/Desktop/R22 Flight School.desktop"; fi
# User-level systemd service when available: starts on login and restarts after failure.
if command -v systemctl >/dev/null; then
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$HOME/.config/systemd/user/r22-flight-school.service" <<EOF
[Unit]
Description=R22 Flight School
After=network.target
[Service]
Type=simple
WorkingDirectory="$ROOT"
EnvironmentFile="$ROOT/.env"
ExecStart="$ROOT/.venv/bin/python" "$ROOT/run.py"
Restart=on-failure
RestartSec=3
[Install]
WantedBy=default.target
EOF
  systemctl --user daemon-reload >/dev/null 2>&1 || true
fi
chmod +x deploy/*.sh
python -m pytest -q
PORT="${PORT:-8086}"
echo 'Installation complete. Application-menu launcher created.'
[ -d "$HOME/Desktop" ] && echo "Desktop launcher created: $HOME/Desktop/R22 Flight School.desktop"
echo "Start with the R22 Flight School icon or: $ROOT/deploy/start_linux.sh"
echo "Server binds to 0.0.0.0:${PORT} for LAN access. Configure your Linux firewall if needed."
