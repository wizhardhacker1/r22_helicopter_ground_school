#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
[ -x .venv/bin/python ] || { echo 'Not installed. Run bash deploy/install_linux.sh first.'; exit 1; }
set -a; . ./.env; set +a
PORT="${PORT:-8086}"
if ! (command -v ss >/dev/null && ss -ltn | awk '{print $4}' | grep -Eq ":${PORT}$"); then
  nohup .venv/bin/python run.py >> data/server.log 2>> data/server-error.log & echo $! > data/server.pid
  ok=0
  for _ in $(seq 1 30); do sleep 1; if command -v curl >/dev/null && curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then ok=1; break; fi; done
  [ "$ok" = 1 ] || { echo 'Server did not become ready. See data/server-error.log'; exit 1; }
fi
URL="http://127.0.0.1:${PORT}/login"
if command -v xdg-open >/dev/null && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then xdg-open "$URL" >/dev/null 2>&1 || true; fi
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo "R22 Flight School: $URL"
[ -n "$IP" ] && echo "LAN: http://${IP}:${PORT}"
