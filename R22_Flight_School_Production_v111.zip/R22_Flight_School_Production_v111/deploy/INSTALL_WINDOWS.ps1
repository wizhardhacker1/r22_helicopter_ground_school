$ErrorActionPreference='Stop'
$Root = Split-Path $PSScriptRoot -Parent
Set-Location $Root
Write-Host 'Installing R22 Flight School for Windows...'
$py=$null
if(Get-Command py -ErrorAction SilentlyContinue){
  foreach($v in @('-3.13','-3.12','-3.11')){ try { & py $v -c "import sys; assert sys.version_info >= (3,11)" 2>$null; if($LASTEXITCODE -eq 0){$py="py $v";break} } catch {} }
}
if(-not $py -and (Get-Command python -ErrorAction SilentlyContinue)){ try { python -c "import sys; assert sys.version_info >= (3,11)"; if($LASTEXITCODE -eq 0){$py='python'} } catch {} }
if(-not $py){
  if(Get-Command winget -ErrorAction SilentlyContinue){ winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements; $py='py -3.12' }
  else { throw 'Python 3.11+ is required. Install Python from python.org, then rerun this installer.' }
}
if(Test-Path .venv){ Remove-Item -Recurse -Force .venv }
if($py -like 'py *'){ $a=$py.Split(' '); & $a[0] $a[1] -m venv .venv } else { & $py -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
New-Item -ItemType Directory -Force data,backups | Out-Null
$PersistRoot = Join-Path $env:LOCALAPPDATA 'R22FlightSchool'
$PersistData = Join-Path $PersistRoot 'data'; $PersistBackups = Join-Path $PersistRoot 'backups'
New-Item -ItemType Directory -Force $PersistData,$PersistBackups | Out-Null
$LegacyDb = Join-Path $Root 'data\r22school.db'; $PersistDb = Join-Path $PersistData 'r22school.db'
if((Test-Path $LegacyDb) -and -not (Test-Path $PersistDb)){ Copy-Item $LegacyDb $PersistDb; Write-Host 'Migrated existing R22 user database to persistent storage.' }
if(-not (Test-Path .env)){ Copy-Item .env.example .env
  $secret=-join ((48..57)+(65..90)+(97..122) | Get-Random -Count 48 | ForEach-Object {[char]$_})
  (Get-Content .env) -replace '^SECRET_KEY=.*$', "SECRET_KEY=$secret" | Set-Content .env
}
$escapedData=$PersistData.Replace('\','/')
$envLines=Get-Content .env
if($envLines -match '^R22_DATA_DIR='){ $envLines=$envLines -replace '^R22_DATA_DIR=.*$', "R22_DATA_DIR=$escapedData" } else { $envLines += "R22_DATA_DIR=$escapedData" }
$dbUrl='sqlite:///'+$escapedData+'/r22school.db'
if($envLines -match '^DATABASE_URL=sqlite'){ $envLines=$envLines -replace '^DATABASE_URL=.*$', "DATABASE_URL=$dbUrl" }
$envLines | Set-Content .env
Get-Content .env | ForEach-Object { if($_ -match '^([^#=]+)=(.*)$'){[Environment]::SetEnvironmentVariable($matches[1].Trim(),$matches[2].Trim(),'Process')} }
Write-Host 'Installing required FAA Los Angeles Sectional, TAC, and Helicopter Route charts...'
# Windows PowerShell 5.x can convert a native program's stderr into a terminating
# NativeCommandError when stderr is piped while ErrorActionPreference=Stop.
# Run Python as a child process with redirected files instead, then inspect the
# process exit code ourselves so the BAT installer always exposes the real error.
$faaLog = Join-Path $Root 'FAA_CHART_INSTALL.log'
$faaOut = Join-Path $env:TEMP ('r22_faa_stdout_' + [guid]::NewGuid().ToString('N') + '.log')
$faaErr = Join-Path $env:TEMP ('r22_faa_stderr_' + [guid]::NewGuid().ToString('N') + '.log')
try {
  $faaProc = Start-Process -FilePath (Join-Path $Root '.venv\Scripts\python.exe') `
    -ArgumentList @('-u','deploy\install_faa_charts.py') -WorkingDirectory $Root `
    -RedirectStandardOutput $faaOut -RedirectStandardError $faaErr -NoNewWindow -Wait -PassThru
  $outText = if(Test-Path $faaOut){ Get-Content $faaOut -Raw } else { '' }
  $errText = if(Test-Path $faaErr){ Get-Content $faaErr -Raw } else { '' }
  @($outText,$errText) | Set-Content -Path $faaLog -Encoding UTF8
  if($outText){ Write-Host $outText }
  if($errText){ Write-Host $errText -ForegroundColor Red }
  $faaExit = $faaProc.ExitCode
} finally {
  Remove-Item $faaOut,$faaErr -Force -ErrorAction SilentlyContinue
}
if($faaExit -ne 0){
  Write-Host ''
  Write-Host "FAA chart installation failed with Python exit code $faaExit." -ForegroundColor Red
  Write-Host "Complete Python output was saved to: $faaLog" -ForegroundColor Yellow
  throw "Required FAA chart installation failed (Python exit code $faaExit). Installation cannot complete without the offline chart lab. See FAA_CHART_INSTALL.log for the complete Python traceback."
}
Write-Host 'FAA offline chart payload verified.'
& .\.venv\Scripts\python.exe -c "from app.main import startup; startup(); print('Database initialized')"
$port=if($env:PORT){$env:PORT}else{'8086'}
try { if(-not (Get-NetFirewallRule -DisplayName 'R22 Flight School' -ErrorAction SilentlyContinue)){ New-NetFirewallRule -DisplayName 'R22 Flight School' -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow | Out-Null } } catch { Write-Warning "Could not add Windows Firewall rule for TCP $port. Run installer as Administrator if LAN clients cannot connect." }
# Desktop and Start Menu shortcuts using native Windows COM; no extra dependency.
$ws=New-Object -ComObject WScript.Shell
$icon=Join-Path $Root 'app\static\icons\r22-flight-school.ico'
$desktop=[Environment]::GetFolderPath('Desktop')
$startMenu=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
foreach($dir in @($desktop,$startMenu)){
  $lnk=$ws.CreateShortcut((Join-Path $dir 'R22 Flight School.lnk')); $lnk.TargetPath='powershell.exe'; $lnk.Arguments="-NoProfile -ExecutionPolicy Bypass -File `"$Root\deploy\START_WINDOWS.ps1`""; $lnk.WorkingDirectory=$Root; $lnk.IconLocation=$icon; $lnk.Description='Start R22 Flight School'; $lnk.Save()
}
# Stop shortcut on desktop for local/server operators.
$lnk=$ws.CreateShortcut((Join-Path $desktop 'Stop R22 Flight School.lnk')); $lnk.TargetPath='powershell.exe'; $lnk.Arguments="-NoProfile -ExecutionPolicy Bypass -File `"$Root\deploy\STOP_WINDOWS.ps1`""; $lnk.WorkingDirectory=$Root; $lnk.IconLocation=$icon; $lnk.Save()
Write-Host 'Verifying application...'
& .\.venv\Scripts\python.exe -m pytest -q
if($LASTEXITCODE -ne 0){ throw "Application verification failed (pytest exit code $LASTEXITCODE). Installation was NOT verified." }
Write-Host 'Installation complete. Desktop and Start Menu shortcuts were created.'
Write-Host "Start with the 'R22 Flight School' desktop icon or deploy\START_WINDOWS.ps1. LAN port: $port"
