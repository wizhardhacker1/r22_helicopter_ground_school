from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding='utf-8')
def test_v87_version(): assert t('VERSION').strip()=='111' and "APP_VERSION='111'" in t('app/main.py')
def test_motion_actual_aircraft_and_live_mechanism():
 h=t('app/templates/rotor_controls.html'); j=t('app/static/rotor_motion_v87.js')
 for x in ['r22_side_profile_v88.jpg','sideSwash','sideMainRotor','sideTailRotor','sideLinkA','sideLinkB','collective','cyclicPitch','cyclicRoll','pedals']: assert x in h
 for x in ['sw.style.transform','l.style.transform','rr.style.transform','disc.style.transform','tail.style.transform']: assert x in j
def test_component_real_reference_and_interaction():
 h=t('app/templates/rotor_components.html'); j=t('app/static/rotor_components_v87.js')
 assert 'rotor_trainer_v82.png?v=111' in h
 for x in ['data-part="blade"','data-part="link"','data-part="swash"','data-part="mast"','data-part="controls"']: assert x in h
 assert 'show-motion' in j and 'setInterval' in j and 'partQuiz' in j
def test_emergency_real_panel_and_scenario_controls():
 h=t('app/templates/emergency.html'); j=t('app/static/emergency_v87.js')
 assert 'emergency-original-cockpit' in h and 'em87-actions' in h and 'data-emmode' in h
 assert 'filterControls' in j and 'cfg.seq' in j and 'function effect(id)' in j
