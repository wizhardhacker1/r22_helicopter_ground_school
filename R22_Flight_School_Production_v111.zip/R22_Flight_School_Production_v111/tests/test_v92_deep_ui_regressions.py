from pathlib import Path
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding="utf-8")
def test_dashboard_does_not_render_python_unicode_escape_text():
 h=t("app/templates/dashboard.html")
 assert "\\U0001" not in h and "\\u26a" not in h
def test_component_lab_uses_direct_manipulation_controls():
 h=t("app/templates/rotor_components.html")
 assert 'data-labcmd=' not in h
 assert 'id="labCollective" type="range"' in h
 assert 'id="labCyclic" type="range"' in h
 assert 'id="labPedals" type="range"' in h
def test_component_pedals_animate_tail_rotor_not_main_swash():
 j=t("app/static/rotor_components_v91.js")
 assert "--lab-pedal-left" in j and "--tail-feather" in j
def test_emergency_reuses_original_interactive_cockpit():
 h=t("app/templates/emergency.html")
 assert "emergency-original-cockpit" in h
 assert "emergency-cockpit-control" in h
 assert "r22-panel-live" not in h
def test_version_92():
 assert (R/"VERSION").read_text(encoding='utf-8').strip()=="111"
