from pathlib import Path
import re
R=Path(__file__).resolve().parents[1]
def t(p): return (R/p).read_text(encoding="utf-8")
def test_no_visible_python_unicode_escape_artifacts():
 for p in (R/"app/templates").glob("*.html"):
  s=p.read_text(encoding="utf-8")
  assert not re.search(r"\\U[0-9a-fA-F]{8}|\\u(?:2502|2571|26a0|203a)",s),p.name
def test_emergency_live_cockpit_has_runtime_targets():
 h=t("app/templates/emergency.html");j=t("app/static/emergency_v87.js")
 for x in ["em_engineNeedle","em_rotorNeedlePanel","em_tachRead"]: assert x in h
 assert "normalFlight();injectFault()" in j and "setControl('Airspeed'" in j
 assert "#rotorValue" not in j and "#asiNeedle" not in j and "#vsiNeedle" not in j
def test_component_lab_pedals_have_real_handlers():
 h=t("app/templates/rotor_components.html");j=t("app/static/rotor_components_v91.js")
 assert 'id="labPedals" type="range"' in h
 for x in ["--lab-pedal-left","--lab-pedal-right","--tail-feather"]: assert x in j
def test_component_lab_has_no_old_button_commands():
 h=t("app/templates/rotor_components.html")
 assert 'data-labcmd=' not in h
 assert 'id="labCollective" type="range"' in h
def test_version_93():
 assert (R/"VERSION").read_text(encoding='utf-8').strip()=="111"
 assert "APP_VERSION='111'" in t("app/main.py")
