from pathlib import Path
R=Path(__file__).resolve().parents[1]
def txt(p): return (R/p).read_text(encoding='utf-8')
def test_motion_is_side_profile_and_animated():
 h=txt("app/templates/rotor_controls.html"); j=txt("app/static/rotor_motion_v88.js")
 assert "r22_side_profile_v88.jpg?v=111" in h
 for x in ["sideSwash","sideLinkA","sideMainRotor","sideTailRotor"]: assert x in h
 assert "ss.style.transform" in j and "str.style.setProperty" in j
def test_component_lab_is_learning_tool_not_static_picture():
 h=txt("app/templates/rotor_components.html"); j=txt("app/static/rotor_components_v88.js")
 for x in ["labCollective","labCyclic","labGuided","labLesson"]: assert x in h
 assert "function labMove" in j and 'data-cmode="quiz"' in h
def test_startup_and_flow_use_live_r22_panel():
 a=txt("app/templates/startup.html"); b=txt("app/templates/checklists.html")
 for x in ["r22_panel_reference.png?v=111","startupPhotoRpm","startupPhotoEngine","startupPhotoOil","startupPhotoLow"]: assert x in a
 for x in ["r22_panel_reference.png?v=111","flowPhotoRpm","flowPhotoEngine","flowPhotoLow"]: assert x in b
 j=txt("app/static/startup.js"); f=txt("app/static/checklists.js")
 assert "startupPhotoRpm" in j and "startupPhotoLow" in j
 assert "flowPhotoRpm" in f and "flowPhotoLow" in f
