from pathlib import Path
R=Path(__file__).resolve().parents[1]
def read(p): return (R/p).read_text(encoding='utf-8')
def test_roadmap_launches_training_for_every_stage():
 from app.training import SYLLABUS
 from app.roadmap import ROADMAP_LINKS
 assert set(k for k,_,_ in SYLLABUS)==set(ROADMAP_LINKS)
 assert all(len(ROADMAP_LINKS[k])>=4 for k,_,_ in SYLLABUS)
 h=read('app/templates/syllabus.html')
 assert 'Open training' in h and 'Check earned completion' in h
def test_printable_checklist_is_standalone_visible_document():
 h=read('app/templates/checklist_reference_print.html')
 assert "extends 'base.html'" not in h
 assert 'BEFORE STARTING ENGINE' in h and 'STARTING ENGINE' in h and 'SHUTDOWN' in h
 assert 'visibility:hidden' not in h
 assert '/checklist-reference/print' in read('app/templates/checklist_reference.html')
def test_flight_plan_print_copies_populated_controls_to_text():
 js=read('app/static/flight_planner.js'); h=read('app/templates/flight_plan_print.html')
 assert "r22-flight-plan-print-v76" in js and "window.open('/flight-plan/print'" in js
 assert "localStorage.getItem('r22-flight-plan-print-v76')" in h
 for x in ['7 AIRCRAFT IDENTIFICATION','15 ROUTE','19 ENDURANCE','PILOT IN COMMAND / CONTACT']: assert x in h
def test_visual_training_is_interactive_and_linked():
 h=read('app/templates/visual_training.html'); js=read('app/static/visual_training.js')
 for x in ['R22 Rotor & Flight Controls','Density-altitude decision','Weather decision','Airspace / chart workflow','Emergency priorities','Checkride answer builder']: assert x in h
 assert 'data-weather' in h and 'data-step' in h and 'data-order' in h
 assert 'visual_training.js?v=111' in h and 'data-weather' in js
def test_every_applicable_acs_task_has_complete_training_package():
 from app.acs import coverage_rows
 rows=coverage_rows(); assert len(rows)==49
 applicable=[r for r in rows if not r['na']]
 assert applicable and all(r['status']=='integrated' and r['curriculum_complete'] for r in applicable)
 assert all(r['lesson'] and r['risk_prompt'] and r['practice'] and r['refs'] and r['resources'] for r in applicable)
def test_current_source_baseline_visible():
 h=read('app/templates/academy.html')
 assert 'FAA-S-ACS-15' in h and '2026 FAA Aviation Weather Handbook' in h and 'July 9, 2026' in h
def test_print_documents_do_not_inherit_application_print_css():
 for f in ('checklist_reference_print.html','flight_plan_print.html'):
  h=read('app/templates/'+f)
  assert "extends 'base.html'" not in h
  assert '<!doctype html>' in h.lower()
  assert 'visibility:hidden' not in h
