# Windows installation verification dependency fix

## Failure corrected

The Windows installer creates a new virtual environment and installs `requirements.txt` before invoking `python -m pytest -q`. The test `tests/test_v129_source_grounded_labs.py` imports `fitz`, which is provided by the **PyMuPDF** package. Prior builds did not declare that package in requirements; pytest therefore stopped during collection with `ModuleNotFoundError: No module named 'fitz'`.

## Change

Added `PyMuPDF==1.26.7` to `requirements.txt`. The existing Windows installer installs that requirements file before running the verification suite. The existing POH-page text assertions and source-grounding checks remain intact.

## Tests executed in this environment

- Focused source-grounded tests: 8 passed.
- Entire Python suite: 392 passed.
- ZIP integrity: verified after packaging.

## Validation boundary

These tests ran under Linux/Python 3.13 with PyMuPDF installed; an actual Windows PowerShell installation was not run in this environment. Windows installation still needs to be retested on the target machine. This change does not constitute FAA or Robinson content approval.
