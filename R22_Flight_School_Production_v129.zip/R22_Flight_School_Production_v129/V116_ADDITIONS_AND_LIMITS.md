# v116 — Integrated student pathways

Adds 18 linked conceptual learning areas, self-checks, persisted individual student knowledge-check progress, source pointers, and connections to existing ATC, flight planning, checklist, emergency, instructor and logbook tools. Does not erase v115 data.

**Validation boundary:** New knowledge checks are elementary conceptual checks, not R22 flight procedure approval or a substitute for authorized SFAR 73 training. Every operational numeric limit, checklist, maneuver and applicable aircraft revision remains subject to source-by-source validation and qualified instructor review. Do not claim FAA or Robinson approval for this application. Existing bank/POH/emergency/other modules have NOT received exhaustive fact checking in this release.

2026-10-12 reference sources: https://www.robinsonheli.com/publications ; https://www.law.cornell.edu/cfr/text/14/appendix-Special_Federal_Aviation_Regulation_No_73 ; https://www.faa.gov/training_testing/testing/acs
