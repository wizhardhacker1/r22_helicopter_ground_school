# R22 Flight School v118 — verified changes, unresolved certification gaps

**Release basis:** v117; no database migration, user-data reset, or intentional feature removals.

## Implemented and functionally verified
- Offline, server-side US METAR field decoder: handles METAR/SPECI report type, station, day/time UTC, wind and gusts, prevailing visibility where supported, cloud groups, vertical visibility, Celsius temperature/dewpoint, and altimeter in inches Hg.
- Unrecognized/remark groups are displayed as unparsed rather than silently discarded or interpreted incorrectly. It does NOT decode every report group, forecasts, or flight category.
- Authenticated `/weather-decoder` GET/POST added, with CSRF enforcement and local-only parsing; reachable from aviation-weather student pathway.
- Fresh v118 cache version references. Source version set to 118.
- Automated regression: 346 tests passed; includes eight new parser tests.

## Critical NOT VERIFIED; must not be represented as approved or production-validated flight instruction
- The 162 authored questions and generated flashcards have **not** each been compared against the exact publication passage, correct response and explanation by an independent aviation reviewer.
- 19 emergency procedures, startup/checklist actions, control animations, specific airframe and flight-instrument indications, and performance/weight-and-balance envelopes have **not** been independently verified against applicable approved R22 pages, revisions and aircraft configuration.
- The 18 student pathways retain structured study worksheets; these are not fully realized flight simulators or instructor-certified curricula.
- Complete bundled official FAA geospatial chart tiles, chart currency/coverage, and all chart overlays remain unvalidated.
- This build was not run on real Windows/Debian installations, through real microphone/speakers, or through successful desktop/mobile browser visual interaction.
- No external CFI, FAA or Robinson review/approval has been obtained.

## Source check for this release
- FAA AIM 7-1-29, Weather Formats: US METAR uses UTC time, degrees C, statute-mile visibility, knot wind, inches Hg altimeter: https://www.faa.gov/Air_traffic/publications/atpubs/aim_html/chap7_section_1.html
- FAA Aviation Weather Handbook FAA-H-8083-28B (FAA page updated Apr 13, 2026): https://www.faa.gov/regulationspolicies/handbooksmanuals/aviation/faa-h-8083-28b-aviation-weather-handbook
- Robinson R22 POH/RFM (aircraft-specific approved pages and supplements): https://www.robinsonheli.com/publications
- Robinson R22 Service Letter SL-89D revision Dec 12, 2025: newer safety/POH revisions are distributed digitally; verify current revision per aircraft.

**Release gate remains CLOSED for any claim of FAA/Robinson approval or complete validated R22 training.** Passing automated tests is not safety certification.
