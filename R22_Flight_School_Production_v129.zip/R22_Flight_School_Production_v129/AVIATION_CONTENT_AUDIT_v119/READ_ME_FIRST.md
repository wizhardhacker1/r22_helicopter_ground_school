# R22 Aviation Content Audit — v119 (2026-10-12)

## Scope and status
This release inventories **every built-in question bank and POH Mastery assessment question** (212 items: 162 seeded question-bank items and 50 POH Mastery items) into `all_assessment_items.csv` with prompt, options, expected answer, explanation, reference, automated flags, and separate source-verification and instructor-review fields.

**Do not use this ledger as proof of FAA or Robinson approval.** No question is marked independently fact-verified because no item-by-item corroboration with a page of the controlling primary publication and qualified independent instructor sign-off has occurred. Automated format checks and regression tests cannot provide either.

## Findings requiring release action
1. **HIGH — Unspecified R22 model silently assumed Beta II CG envelope.** Fixed: unknown variants raise ValueError instead of using an inappropriate aircraft envelope. Non-finite W&B values also rejected. The actual aircraft's equipment and W&B record are still mandatory.
2. **HIGH — Emergency knowledge API grades action *keywords* and writes `status=complete` at >=70%.** This does NOT establish the correct action sequence, accuracy, or flight proficiency. Must not be represented as a POH procedural qualification.
3. **HIGH — Offline official chart tiles absent.** `app/static/faa_charts` contains only a README (no packaged FAA chart tiles). The complete no-network chart lesson requirement is not met.
4. **HIGH — Aviation questions lack individual definitive verification.** CSV contains 212 assessment entries; **38 weak reference strings** and **15 references not detected as item-specific** (these categories can overlap). A weak-reference flag does NOT prove an answer wrong, and a passing check does NOT prove it correct.
5. **HIGH — Aircraft-specific POH + supplements vs app configuration:** the package includes a POH reference PDF, but aircraft-specific supplements, installed equipment, and current controlling pages are not mapped exhaustively to the content.
6. **HIGH — Simulated controls and emergency outcomes:** static/source-level checks are not a substitute for CFI confirmation of action priority, state transitions and flight physics. Audio/browser/device testing incomplete.
7. **MEDIUM — Navigation/weather operational currency:** examples are not automatically equivalent to current official weather, NOTAMs, or unexpired chart datasets on offline installations.

## Verified official publication landing pages
- Robinson R22 source index: https://www.robinsonheli.com/publications (R22 POH 22-Feb-2024 log; July 2025 notices revision; 2026 maintenance/parts revisions separately listed).
- FAA private helicopter ACS: https://www.faa.gov/training_testing/testing/acs/private_helicopter_acs_15.pdf
- FAA Helicopter Flying Handbook: https://www.faa.gov/regulations_policies/handbooks_manuals/aviation/helicopter_flying_handbook
- FAA AIM: https://www.faa.gov/air_traffic/publications/atpubs/aim_html/index.html

These references confirm source availability; they are NOT citations verifying each individual answer.

## Quality gates
- Automated regression test outcome recorded separately in release notes.
- Source-to-answer verification: INCOMPLETE; all 212 entries pending review.
- Operational aviation accuracy approval: NOT CLAIMED.
- Helicopter CFI independent procedural and instructional review: NOT PERFORMED.
- Windows/Debian installers and actual browser interaction test: NOT PERFORMED in this environment.
- Aircraft variant / supplement mapping: INCOMPLETE.

## Next required evidence for a genuinely complete audit
For every individual item: source document identifier + revision + exact page/paragraph, approved aircraft model/supplements, answer justification, reviewer identity/date, and outcome from semantic/grading test. Any wrong content should be corrected and regression-tested before use. Repeat the same discipline for the actual dynamic emergency, POH, performance, weather, ATC, navigation and checkride modules.
