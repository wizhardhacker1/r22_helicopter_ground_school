# Aviation source and end-to-end release verification — 12 October 2026

## Result: RELEASE BLOCKED

Baseline: R22 Flight School v129. Independent automation executed locally: **392 pytest tests passed**, including a release-gate regression test. These are software tests and do not constitute aviation factual certification.

### Specific release-gate findings

- 212 assessment entries inventoried (162 question bank; 50 POH Mastery); **0 of 212** carry independent item-by-item primary-source factual verification in the packaged assessment ledger.
- 0 of 212 have recorded independent instructor sign-off.
- 38 entries have weak references and 15 lack item-specific references as flagged by the previous inventory. These categories sum to 53 flagged entries.
- `app/static/faa_charts/` contains a README but no offline chart imagery or tiles.
- A Robinson POH reference PDF is bundled; its presence and integrity do **not** establish that questions/procedures match its applicable approved pages or aircraft configuration.
- No accepted end-to-end evidence was found for full emergency scenario verification, independent performance and weight-balance cases, native Windows/Linux installs, physical browser layouts/microphone behavior, and full 18-module acceptance.

### External primary-source comparison

- FAA's ACS listing continues to identify FAA-S-ACS-15, Private Pilot Rotorcraft Category Helicopter Rating, with April 2024 publication and May 31, 2024 effective date: https://www.faa.gov/training_testing/testing/acs
- FAA handbook library explicitly warns that the older Rotorcraft Flying Handbook is for gyroplane material only; current helicopter instruction should use the Helicopter Flying Handbook: https://www.faa.gov/regulations_policies/handbooks_manuals/aviation
- Robinson's live publication page includes newer service bulletins/updates, including R22 SB-123A dated July 28, 2026. Aircraft-specific applicability must be confirmed, not inferred: https://www.robinsonheli.com/publications

### What changed in this working copy

`tools/aviation_release_gate.py` now runs a reproducible, **fail-closed** release decision. It deliberately exits status 1 if the source checks or evidence required to support a production claim have not passed. The new `tests/test_aviation_release_gate.py` confirms that the unverified content and missing charts cannot accidentally be treated as a passed release. `AVIATION_RELEASE_GATE_RESULTS.json` contains the machine-readable results.

This record is a scoped, reproducible audit of release evidence; it is **not** 212 individual source checks, an R22 CFI review, a chart currency audit, or native Windows/Linux acceptance. Do not use it as any such claim.
