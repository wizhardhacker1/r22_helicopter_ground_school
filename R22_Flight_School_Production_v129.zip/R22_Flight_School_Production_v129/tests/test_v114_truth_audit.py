from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R))
from app.builtin_bank import PPL,R22_EXTRA,IFR
from app.poh_mastery import POH_MASTERY_SECTIONS,POH_FINAL_QUESTIONS
from app.training import ATC_SCENARIOS
from app.main import _atc_norm,_atc_element_ok

def chosen(q):
    return q[q['correct'].lower()]

def test_all_authored_question_keys_are_structurally_valid():
    for bank in (PPL,R22_EXTRA,IFR):
        prompts=set()
        for q in bank:
            assert q['correct'] in {'A','B','C'}
            assert q['prompt'].strip() and q['explanation'].strip() and q['reference'].strip()
            assert q['prompt'] not in prompts
            prompts.add(q['prompt'])

def test_all_poh_mastery_answer_indexes_are_valid():
    for sec in POH_MASTERY_SECTIONS:
        assert sec['lessons'] and sec['questions'] and sec['ref']
        for q in sec['questions']:
            assert isinstance(q['a'],int) and 0 <= q['a'] < len(q['o'])
            assert q['e'].strip()
    for q in POH_FINAL_QUESTIONS:
        assert isinstance(q['a'],int) and 0 <= q['a'] < len(q['o'])
        assert q['e'].strip()

def test_r22_poh_numeric_anchor_answers_match_bundled_poh_audit():
    expected={
      'Usable fuel in the R22 bladder main tank is:':'16.9 gal',
      'Usable fuel in the R22 bladder auxiliary tank is:':'9.4 gal',
      'R22 main-fuel longitudinal arm is:':'108.6 in',
      'R22 auxiliary-fuel longitudinal arm is:':'103.8 in',
      'Maximum weight in either R22 baggage compartment is:':'50 lb',
      'Maximum per seat including baggage is:':'240 lb',
      'Maximum operating density altitude is:':'14,000 ft',
      'Normal power-on rotor RPM range for the applicable Beta II configuration is:':'101-104%',
      'Power-off rotor RPM range is:':'90-110%',
      'For power failure above 500 ft AGL, the POH calls for approximately:':'65 KIAS',
      'Maximum-glide airspeed is approximately:':'75 KIAS',
      'Below about 500 ft during maximum-glide autorotation, rotor RPM should be increased to at least:':'97%',
      'Recommended takeoff/climb airspeed is:':'60 KIAS',
      'Best rate-of-climb speed is:':'53 KIAS',
      'Recommended maximum-range airspeed is:':'83 KIAS',
      'Before takeoff, rotor RPM should be verified at:':'102-104%',
      'Solo flight is permitted from:':'Right seat only',
      'Low-G cyclic pushovers are:':'Prohibited',
    }
    by_prompt={q['prompt']:chosen(q) for q in R22_EXTRA}
    for prompt,answer in expected.items():
        assert by_prompt[prompt] == answer

def test_every_atc_model_example_satisfies_its_own_required_elements():
    for key,sc in ATC_SCENARIOS.items():
        text=_atc_norm(sc['example'])
        failed=[e['label'] for e in sc['elements'] if not _atc_element_ok(text,e)]
        assert not failed,(key,failed,sc['example'])

def test_non_towered_example_is_self_announce_not_controller_readback():
    sc=ATC_SCENARIOS['non-towered']
    assert sc['kind']=='self_announce'
    assert 'No controller response is expected' in sc['example_reply']
    assert 'airport name at end' in [e['label'] for e in sc['elements']]

def test_spoken_callsign_and_runway_forms_are_accepted():
    sc=ATC_SCENARIOS['non-towered']
    text=_atc_norm('Bishop traffic helicopter two two bravo hotel ten miles west three thousand five hundred landing runway three zero Bishop')
    assert all(_atc_element_ok(text,e) for e in sc['elements'])
