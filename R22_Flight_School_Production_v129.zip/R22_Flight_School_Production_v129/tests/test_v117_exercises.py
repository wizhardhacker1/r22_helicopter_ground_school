from app.pathway_activities import ACTIVITIES,FIRST_TEN,fuel_example
from app.student_pathways import PATHWAYS
import pytest

def test_every_topic_has_structured_workflow():
 assert len(FIRST_TEN)==10
 assert {p['slug'] for p in PATHWAYS}==set(ACTIVITIES)
 for k,fields in ACTIVITIES.items():
  assert len(fields)>=3,k
  assert len({f[0] for f in fields})==len(fields)

def test_fuel_math_uses_only_entered_values():
 assert fuel_example(1,10,20,30,2)==dict(planned=10,reserve=5,required=17,surplus=3,sufficient_for_entered_assumptions=True)
 assert fuel_example(2,10,20,30,2)['sufficient_for_entered_assumptions'] is False
 with pytest.raises(ValueError):fuel_example(1,-2,20,30,2)

def test_no_pretend_credentials_or_flight_credit():
 src=open('app/main.py').read()
 assert "module='pathway_exercise'" in src
 assert "status='submitted',score=0" in src
 assert "check_csrf(request,str(form.get('csrf','')))" in src

def test_all_18_pathway_pages_render_and_save_workflows():
 from tests.test_app_smoke import auth_client
 c=auth_client()
 for course in PATHWAYS:
  slug=course['slug']
  r=c.get('/student-pathways/'+slug)
  assert r.status_code==200,(slug,r.status_code,r.text[:200])
  assert 'Save Preparation Exercise' in r.text
  fields=ACTIVITIES[slug]
  data={'csrf':c.cookies['csrf']}
  for f in fields:
   data[f[0]]= f[3][0] if f[2]=='select' else '2' if f[2]=='number' else 'Student practice response grounded in official source.'
  r=c.post('/student-pathways/'+slug+'/exercise',data=data,follow_redirects=False)
  assert r.status_code==303,(slug,r.status_code,r.text[:300])
 r=c.get('/student-pathways/evidence/report')
 assert r.status_code==200 and 'Preparation Worksheets' in r.text

def test_exercises_require_csrf_and_reject_missing_or_invalid_inputs():
 from tests.test_app_smoke import auth_client
 c=auth_client(); c.get('/student-pathways/sfar73')
 assert c.post('/student-pathways/sfar73/exercise',data={'csrf':'bad'}).status_code==403
 assert c.post('/student-pathways/sfar73/exercise',data={'csrf':c.cookies['csrf']}).status_code==422
 assert c.get('/student-pathways/unknown').status_code==404
