from app.main import _atc_norm,_atc_has,_atc_element_ok
from app.training import ATC_SCENARIOS

def grade(name,msg):
    return {e['key']: _atc_element_ok(_atc_norm(msg),e) for e in ATC_SCENARIOS[name]['elements']}

def test_all_ten_example_transmissions_remain_accepted():
    for name,scenario in ATC_SCENARIOS.items():
        assert all(grade(name,scenario['example']).values()),name

def test_ctaf_variations_and_missing_elements():
    base='Bishop traffic, N22BH, ten miles west, three thousand five hundred, inbound landing runway three zero, Bishop'
    assert all(grade('non-towered',base).values())
    missing=grade('non-towered','Bishop traffic helicopter two two bravo hotel ten miles west three thousand five hundred inbound runway three zero')
    assert not missing['airport_close']
    assert missing['callsign']
    assert not grade('non-towered','helicopter 22BH west of bishop traffic ten miles west three thousand five hundred landing runway 30 bishop')['airport_open']

def test_word_boundaries_prevent_substring_false_passes():
    assert not _atc_has(_atc_norm('please misinformation'),['information'])
    assert not _atc_has(_atc_norm('disidentification'),['ident'])
    assert not _atc_has(_atc_norm('runway 300'),['runway 30'])
    assert not _atc_has(_atc_norm('1235000'),['3500'])
    assert _atc_has(_atc_norm('hold short runway 30'),['hold short'])

def test_expected_registration_variants():
    for call in ('N22BH','N 22 BH','22 BH','22BH','Helicopter Two Two Bravo Hotel'):
        assert grade('non-towered','Bishop traffic '+call+' ten miles west 3500 inbound landing runway 30 Bishop')['callsign'],call
