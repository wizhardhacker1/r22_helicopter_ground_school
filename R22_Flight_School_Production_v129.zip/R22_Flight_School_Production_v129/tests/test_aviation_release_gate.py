from tools.aviation_release_gate import inspect

def test_release_gate_requires_individual_source_evidence():
    result=inspect()
    assert result['overall_pass'] is False
    items={x['id']:x for x in result['checks']}
    assert items['assessment_source_verification']['total']==212
    assert items['assessment_source_verification']['verified']==0
    assert not items['offline_faa_charts_present']['pass_check']
    assert items['bundled_poh_present']['pass_check']
