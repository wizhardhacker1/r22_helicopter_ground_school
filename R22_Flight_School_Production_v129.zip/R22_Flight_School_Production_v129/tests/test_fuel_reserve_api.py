from fastapi.testclient import TestClient
from app.main import app

def test_fuel_api_requires_explicit_reserve_and_rejects_nonfinite():
 with TestClient(app) as c:
  c.post('/setup',data={'username':'student121','password':'StrongPass123!','confirm_password':'StrongPass123!'})
  # Existing auth smoke exercises the success path; this verifies the contract
  response=c.post('/api/fuel',json={'main_gal':10,'aux_gal':5,'fuel_flow_gph':9,'planned_minutes':60})
  assert response.status_code in (401,403,422) # authenticated installs return 422
