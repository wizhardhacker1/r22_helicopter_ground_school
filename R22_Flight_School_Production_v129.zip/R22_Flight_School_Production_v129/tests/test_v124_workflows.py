from app.main import AIRCRAFT_FIELDS, BRIEF_FIELDS, FIRST_TEN

def test_structured_workflows_are_not_empty():
 assert len(AIRCRAFT_FIELDS)>=7
 assert len(BRIEF_FIELDS)>=12
 assert len(FIRST_TEN)==10
 assert len({key for key,label in AIRCRAFT_FIELDS})==len(AIRCRAFT_FIELDS)
 assert len({key for key,label in BRIEF_FIELDS})==len(BRIEF_FIELDS)

def test_all_three_workflows_are_in_pathway_navigation():
 from pathlib import Path
 s=Path('app/templates/student_pathways.html').read_text(encoding='utf-8')
 for route in ('/student-first-ten','/student-flight-briefing','/student-aircraft-profiles'):
  assert route in s


def test_authenticated_new_workflow_pages_and_saves():
 from fastapi.testclient import TestClient
 from app.main import app, startup
 from app.db import SessionLocal
 from app.models import User, TrainingRecord
 from app.auth import token
 startup()
 db=SessionLocal();user=db.query(User).filter(User.username=='admin').first()
 uid=user.id; role=user.role; db.close()
 c=TestClient(app);c.cookies.set('session',token(uid,role))
 for url in ('/student-first-ten','/student-flight-briefing','/student-aircraft-profiles'):
  response=c.get(url)
  assert response.status_code==200,(url,response.status_code,response.text[:300])
 csrf=c.cookies.get('csrf')
 data={k:'Reviewed against applicable aircraft documentation' for k,v in AIRCRAFT_FIELDS}
 data['csrf']=csrf
 assert c.post('/student-tools/aircraft/save',data=data,follow_redirects=False).status_code==303
 invalid=dict(data);invalid['variant']=''
 assert c.post('/student-tools/aircraft/save',data=invalid,follow_redirects=False).status_code==422
 data={k:'Current source checked by student; not dispatch authority' for k,v in BRIEF_FIELDS}
 data['csrf']=csrf
 assert c.post('/student-tools/brief/save',data=data,follow_redirects=False).status_code==303
 data=dict(reference_studied='FAA HFH Chapter 3',knowledge_questions='Flight controls',instructor_questions='Confirm cockpit differences',risk_briefing='Wind and density altitude',csrf=csrf)
 assert c.post('/student-first-ten/1/save',data=data,follow_redirects=False).status_code==303
 assert c.post('/student-first-ten/11/save',data=data,follow_redirects=False).status_code==404
 db=SessionLocal()
 for module in ('aircraft_profile','flight_briefing','first_ten_prep'):
  assert db.query(TrainingRecord).filter_by(user_id=uid,module=module).count()>=1
 db.close()
