import pytest
from app.taf_decoder import decode_taf

def test_taf_segments_and_windows():
 t=decode_taf('TAF KPIT 091730Z 0918/1024 15005KT 5SM HZ FEW020 FM091930 30015G25KT 3SM SHRA OVC015 TEMPO 0920/0922 1SM +TSRA OVC008CB PROB30 1004/1007 1SM -RA BR BECMG 1013/1015 P6SM NSW SKC')
 assert t['station']=='KPIT' and t['validity_utc']=='0918/1024'
 assert [x['kind'] for x in t['periods']]==['BASE','FM','TEMPO','PROB30','BECMG']
 assert t['periods'][1]['window']=='091930'
 assert t['periods'][2]['window']=='0920/0922'
 assert '+TSRA' in t['periods'][2]['unparsed']

def test_taf_rejects_invalid():
 for value in ('','TAF','TAF KZZZ 091730Z','TAF KZZZ 091730Z 0918/1018 TEMPO 4SM'):
  with pytest.raises(ValueError): decode_taf(value)

def test_taf_page_integration():
 from pathlib import Path
 from app.main import app
 assert '/weather-decoder' in {x.path for x in app.routes}
 page=Path('app/templates/weather_decoder.html').read_text(encoding='utf-8')
 assert 'decoded.periods' in page and 'csrf' in page
