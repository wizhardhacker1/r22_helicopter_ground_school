from app.main import app, WORKBENCH_LINKS, BY_SLUG, SCENARIOS, ACTIVITIES
from pathlib import Path

def test_all_18_workbench_configs():
 assert len(WORKBENCH_LINKS)==18
 assert set(WORKBENCH_LINKS)==set(BY_SLUG)
 for slug,links in WORKBENCH_LINKS.items():
  assert len(links)>=2 and slug in SCENARIOS and slug in ACTIVITIES
  assert all(x[0].startswith('/') for x in links)

def test_workbench_routes_and_template():
 paths={r.path for r in app.routes}
 assert '/student-workbench/{slug}' in paths
 s=Path('app/templates/student_workbench.html').read_text(encoding='utf-8')
 assert 'csrf' in s and 'results' in s and 'fields' in s
