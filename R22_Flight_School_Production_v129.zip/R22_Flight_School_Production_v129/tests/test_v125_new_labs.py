from app.main import SFAR73_TOPICS, app

def test_sfar73_course_is_graded_with_source_evidence():
 assert len(SFAR73_TOPICS)>=8
 for topic in SFAR73_TOPICS:
  assert topic['source'].startswith('14 CFR Part 61, SFAR No. 73')
  assert topic['answer'] in [c[0] for c in topic['choices']]
  assert topic['explanation']

def test_new_student_course_routes_registered():
 paths={r.path for r in app.routes}
 assert '/sfar73-awareness-course' in paths
 assert '/sfar73-awareness-course/check' in paths
 assert '/hover-coordination-lab' in paths

def test_hover_module_has_real_controls():
 from pathlib import Path
 js=Path('app/static/hover_coordination.js').read_text(encoding='utf-8')
 for control in ['hoverReset','hoverPause','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','requestAnimationFrame']:
  assert control in js

def test_authenticated_pages_and_sfar_submissions():
 from fastapi.testclient import TestClient
 from app.main import startup
 from app.db import SessionLocal
 from app.models import User, TrainingRecord
 from app.auth import token
 startup()
 db=SessionLocal()
 u=db.query(User).filter_by(username='admin').first()
 uid,role=u.id,u.role
 db.close()
 client=TestClient(app)
 client.cookies.set('session',token(uid,role))
 for path in ('/sfar73-awareness-course','/hover-coordination-lab'):
  response=client.get(path)
  assert response.status_code==200, (path,response.text[:250])
  assert '<html' in response.text
 token_value=client.cookies.get('csrf')
 answers={t['id']:t['answer'] for t in SFAR73_TOPICS}
 response=client.post('/sfar73-awareness-course/check',data={'csrf':token_value,**answers})
 assert response.status_code==200
 assert '100%' in response.text
 assert 'NOT a required logbook endorsement' in response.text
 bad=dict(answers); bad[SFAR73_TOPICS[0]['id']]='unexpected'
 assert client.post('/sfar73-awareness-course/check',data={'csrf':token_value,**bad}).status_code==422
 assert client.post('/sfar73-awareness-course/check',data={'csrf':'bad',**answers}).status_code in (400,403)
 db=SessionLocal()
 assert db.query(TrainingRecord).filter_by(user_id=uid,module='sfar73_awareness').count()>=1
 db.close()
