import pytest
from app.weather_decoder import decode_metar

def test_normal_metar_fields():
 d=decode_metar('METAR KLGB 121653Z 24012G19KT 10SM FEW020 BKN045 22/14 A2992 RMK AO2')
 assert d['station']=='KLGB' and 'gust 19' in d['wind']
 assert d['altimeter_inhg']=='29.92' and d['temperature_c']==22
 assert '4500' in d['clouds'][1] and 'AO2' in d['unparsed']

def test_negative_temperature_and_variable_wind():
 d=decode_metar('SPECI KBIH 121700Z VRB03KT 3/4SM OVC008 M02/M07 A3010')
 assert d['temperature_c']==-2 and d['visibility']=='3/4SM'
 assert 'variable' in d['wind']

@pytest.mark.parametrize('bad',['','KLGB 121653Z 10SM','METAR','METAR K 121653Z','X'*1201])
def test_reject_malformed(bad):
 with pytest.raises(ValueError): decode_metar(bad)

def test_less_than_quarter_visibility_is_recognized():
 d=decode_metar('METAR KABC 121653Z 00000KT M1/4SM VV002 08/08 A3000')
 assert d['visibility'] == 'M1/4SM' and 'M1/4SM' not in d['unparsed']
