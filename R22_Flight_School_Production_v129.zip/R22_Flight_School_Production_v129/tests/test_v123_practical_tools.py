from app.practical_tools import rotorcraft_vfr_fuel,r22_solo_prerequisite_screen
import pytest

def test_rotorcraft_fuel_reserve_and_math():
 r=rotorcraft_vfr_fuel(1,8,12,1,20)
 assert r['destination_gallons']==8
 assert r['reserve_gallons']==round(8/3,3)
 assert r['margin_gallons']==round(12-8-8/3-1,3)
 assert r['meets_entered_arithmetic']

def test_rejects_bad_fuel():
 for args in [(-1,8,20,0,20),(1,0,20,0,20),(1,8,20,0,19),(1,float('nan'),20,0,20),(1,float('inf'),20,0,20)]:
  with pytest.raises(ValueError):rotorcraft_vfr_fuel(*args)

def test_solo_never_authorizes_and_flags_missing():
 r=r22_solo_prerequisite_screen(False,19,False,False,100)
 assert not r['authorized_to_solo']
 assert len(r['identified_issues'])>=4
 r2=r22_solo_prerequisite_screen(False,20,True,True,25)
 assert not r2['authorized_to_solo']
 assert any('61.87' in x for x in r2['identified_issues'])
