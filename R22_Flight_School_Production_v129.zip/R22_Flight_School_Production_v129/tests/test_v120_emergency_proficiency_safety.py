from pathlib import Path

def test_keyword_recall_is_not_proficiency():
    src=(Path(__file__).parents[1]/'app/main.py').read_text(encoding='utf-8')
    assert "status='practice_only'" in src
    assert "'proficiency_verified':False" in src
    assert "if key=='emergency': qualified=False" in src
    assert "if key not in EMERGENCIES:" in src
