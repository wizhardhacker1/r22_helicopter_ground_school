from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from app.student_pathways import PATHWAYS
from app.main import app

ROOT=Path(__file__).resolve().parents[1]/'app'/'templates'

def test_compact_index_has_all_eighteen_once_and_no_old_action_clutter():
    env=Environment(loader=FileSystemLoader(str(ROOT)))
    template=env.get_template('student_pathways.html')
    html=template.render(pathways=PATHWAYS, passed=set())
    assert html.count('class="pathway-tile"') == 18
    assert 'Practical Workbench</a>' not in html
    assert 'Interactive mission</a>' not in html
    assert '/weather-decoder' in html

def test_hover_has_single_sidebar_location():
    base=(ROOT/'base.html').read_text(encoding='utf-8')
    assert base.count('href=/hover-coordination-lab')==1
    assert base.index('href=/hover-coordination-lab') > base.index('R22 AIRCRAFT')

def test_overview_internal_destinations_exist():
    env=Environment(loader=FileSystemLoader(str(ROOT)))
    html=env.get_template('student_pathways.html').render(pathways=PATHWAYS, passed=set())
    from html.parser import HTMLParser
    class Anchors(HTMLParser):
        def __init__(self): super().__init__(); self.urls=[]
        def handle_starttag(self,tag,attrs):
            if tag=='a':self.urls.extend(v for k,v in attrs if k=='href')
    a=Anchors();a.feed(html)
    routes=[r.path for r in app.routes]
    for url in a.urls:
        if url in routes:continue
        parts=url.strip('/').split('/')
        assert any(len(parts)==len(r.strip('/').split('/')) and all(x==y or x.startswith('{') for x,y in zip(r.strip('/').split('/'),parts)) for r in routes),url
