import math
import pytest
from app.calculators import wb, cg_limits

def test_unknown_model_rejected_not_mapped_to_beta_ii():
    with pytest.raises(ValueError, match="Unknown R22 model"):
        wb(880, 104, 170, 160, 0, 0, 10, 5, model="R44")
    with pytest.raises(ValueError, match="Unknown R22 model"):
        cg_limits("Unspecified", 1200)

@pytest.mark.parametrize("bad", [float('nan'), float('inf'), float('-inf')])
def test_nonfinite_wb_inputs_rejected(bad):
    with pytest.raises(ValueError, match="finite"):
        wb(880, 104, 170, 160, 0, 0, 10, bad)
