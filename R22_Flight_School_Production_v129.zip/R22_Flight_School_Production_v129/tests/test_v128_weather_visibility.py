"""FAA AIM weather visibility formatting regression tests."""
from app.weather_decoder import decode_metar
from app.taf_decoder import decode_taf

def test_metar_more_than_six_miles():
    r = decode_metar('METAR KLGB 121853Z 26007KT P6SM FEW025 22/14 A2996')
    assert r['visibility'] == 'P6SM'
    assert 'P6SM' not in r['unparsed']

def test_metar_less_than_quarter_mile():
    r = decode_metar('METAR KLGB 121853Z 00000KT M1/4SM FG VV002 12/12 A3001')
    assert r['visibility'] == 'M1/4SM'

def test_metar_mixed_visibility():
    r = decode_metar('METAR KLGB 121853Z 00000KT 1 1/2SM BR OVC010 13/12 A3001')
    assert r['visibility'] == '1 1/2SM'
    assert '1' not in r['unparsed']
    assert '1/2SM' not in r['unparsed']

def test_taf_mixed_visibility():
    r = decode_taf('TAF KLGB 121720Z 1218/1324 25008KT P6SM SCT030 TEMPO 1220/1223 1 1/2SM BR BKN014')
    assert any('Visibility 1 1/2SM' in item for item in r['periods'][1]['interpreted'])

def test_taf_less_than_quarter_visibility():
    r = decode_taf('TAF KLGB 121720Z 1218/1324 25008KT P6SM SCT030 TEMPO 1220/1223 M1/4SM FG VV002')
    assert any('Visibility M1/4SM' in item for item in r['periods'][1]['interpreted'])

def test_unknown_weather_stays_unparsed():
    r = decode_metar('METAR KLGB 121853Z 26007KT P6SM UNKNOWN FEW025 22/14 A2996')
    assert 'UNKNOWN' in r['unparsed']
