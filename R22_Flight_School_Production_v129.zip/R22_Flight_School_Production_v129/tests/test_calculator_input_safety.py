import math
import pytest
from app.calculators import fuel_plan,wind_triangle,e6b,pressure_altitude,density_altitude

@pytest.mark.parametrize('bad',[float('nan'),float('inf'),-float('inf')])
def test_fuel_calculation_rejects_nonfinite(bad):
 for args in ((bad,4,8,60,20),(10,bad,8,60,20),(10,4,bad,60,20),(10,4,8,bad,20),(10,4,8,60,bad)):
  with pytest.raises(ValueError): fuel_plan(*args)

@pytest.mark.parametrize('bad',[float('nan'),float('inf'),-float('inf')])
def test_wind_and_e6b_reject_nonfinite(bad):
 with pytest.raises(ValueError): wind_triangle(90,100,bad,10,50)
 with pytest.raises(ValueError): e6b(70,1000,20,90,270,bad,50)
 with pytest.raises(ValueError): pressure_altitude(1000,bad)
 with pytest.raises(ValueError): density_altitude(1000,29.92,bad)

def test_fuel_reserve_is_not_claimed_as_regulatory_check():
 result=fuel_plan(10,5,9,60,20)
 assert result['meets_selected_reserve'] is True
 assert result['regulatory_compliance_verified'] is False
 assert result['reserve_check_scope']=='USER_SELECTED_ONLY_NOT_REGULATORY_COMPLIANCE'
