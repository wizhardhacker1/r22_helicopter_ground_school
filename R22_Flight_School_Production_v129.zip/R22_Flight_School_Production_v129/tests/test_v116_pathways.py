from app.student_pathways import PATHWAYS, QUESTIONS, BY_SLUG
from pathlib import Path

def test_every_course_has_unique_scored_quiz_and_source():
 assert len(PATHWAYS)==18
 assert len({p['slug'] for p in PATHWAYS})==len(PATHWAYS)
 for p in PATHWAYS:
  q=QUESTIONS[p['slug']]
  assert p['source'] and len(p['lesson'])>45 and len(q[1])==2
  assert 0<=q[2]<len(q[1])
  assert BY_SLUG[p['slug']] is p

def test_pathways_are_in_real_navigation_and_persist_to_training_record():
 main=Path('app/main.py').read_text(encoding="utf-8")
 base=Path('app/templates/base.html').read_text(encoding="utf-8")
 assert 'href=/student-pathways' in base
 assert "module='pathway'" in main
 assert "check_csrf(request,csrf)" in main
 assert 'student_pathways.html' in main
