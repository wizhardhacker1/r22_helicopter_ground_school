from pathlib import Path
from app.scenario_missions import SCENARIOS
from app.student_pathways import BY_SLUG
from app.main import app
from jinja2 import Environment, FileSystemLoader


def test_every_student_feature_has_assessed_mission():
    assert set(SCENARIOS) == set(BY_SLUG)
    for slug, scenes in SCENARIOS.items():
        assert len(scenes) >= 2, slug
        for prompt, options, correct, explanation, source in scenes:
            assert len(prompt) > 15 and len(options) >= 2
            assert len(set(options)) == len(options)
            assert 0 <= correct < len(options)
            assert len(explanation) > 25 and len(source) > 7


def test_mission_get_post_routes_registered():
    routes={(path.path,method) for path in app.routes if hasattr(path,'methods') for method in path.methods}
    assert ('/student-pathways/{slug}/missions','GET') in routes
    assert ('/student-pathways/{slug}/missions','POST') in routes


def test_mission_template_valid_and_nav_visible():
    root=Path(__file__).resolve().parents[1]/'app'/'templates'
    env=Environment(loader=FileSystemLoader(str(root)))
    env.get_template('student_missions.html')
    detail=(root/'student_pathway_detail.html').read_text(encoding='utf-8')
    assert '/student-pathways/{{course.slug}}/missions' in detail
    index=(root/'student_pathways.html').read_text(encoding='utf-8')
    assert 'pathway-tiles' in index
    assert '/hover-coordination-lab' in index
    assert '/student-pathways/{{c.slug}}/missions' not in index
