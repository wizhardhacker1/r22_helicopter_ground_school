from pathlib import Path
from jinja2 import Environment

ROOT = Path(__file__).resolve().parents[1]

def test_instrument_key_embedded_with_actual_poh_numbers():
    content = (ROOT/'app/templates/student_instruments.html').read_text(encoding='utf8')
    assert "(1,'Vertical speed indicator')" in content
    assert "(3,'Airspeed indicator')" in content
    assert "(4,'Engine and rotor tachometers')" in content
    assert "(37,'Carburetor heat')" in content
    assert 'id="instrument-reference"' in content
    assert "target=\"_blank\"" not in content

def test_hover_four_lessons_have_controls_and_feedback():
    content = (ROOT/'app/templates/student_hover_lab.html').read_text(encoding='utf8')
    for v in ('station','crosswind','heading','combined'):
        assert 'value="'+v+'"' in content
    for id in ('hoverStart','hoverReset','hoverPause','hoverScore','hoverReadout','hoverCyclicNeutral'):
        assert 'id="'+id+'"' in content
    js = (ROOT/'app/static/hover_coordination.js').read_text(encoding='utf8')
    assert 'pointerdown' in js and 'pointercancel' in js
    assert 'inside>=30' in js

def test_new_templates_parse():
    from jinja2 import Environment
    e=Environment()
    for name in ('student_instruments.html','student_hover_lab.html'):
        e.parse((ROOT/'app/templates'/name).read_text(encoding='utf8'))
