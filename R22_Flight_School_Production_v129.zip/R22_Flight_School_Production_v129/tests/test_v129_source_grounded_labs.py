from pathlib import Path
import fitz
import pytest
from app.main import app, SFAR73_TOPICS
from app.practical_tools import r22_solo_prerequisite_screen

ROOT=Path(__file__).resolve().parents[1]

def test_hv_uses_rendered_authoritative_poh_page():
    src=fitz.open(ROOT/'data/R22_POH_reference.pdf')
    assert '5-11' in src[78].get_text()
    assert (ROOT/'app/static/img/r22_poh_height_velocity_section5_11.png').stat().st_size>100_000
    assert 'ROBINSON' in src[78].get_text().upper()

def test_hv_is_actual_route_not_dead_link():
    assert any(getattr(route,'path',None)=='/r22-height-velocity-lab' for route in app.routes)
    template=(ROOT/'app/templates/student_hv_lab.html').read_text(encoding='utf-8')
    assert '/poh/reference' in template
    assert 'r22_hv_chart.js' in template

def test_sfar_question_sources_use_subsections():
    assert len(SFAR73_TOPICS)>=12
    for question in SFAR73_TOPICS:
        assert question['answer'] in dict(question['choices'])
        assert 'SFAR No. 73' in question['source']
        assert question['explanation']

def test_solo_screen_evidence_includes_actual_maneuvers_and_cfi_authorization():
    case=r22_solo_prerequisite_screen(False,20,True,True,30)
    joined=' '.join(case['identified_issues']).lower()
    for term in ('maximum-glide','autorotation','governor','low-rpm','authorized'):
        assert term in joined
    assert case['authorized_to_solo'] is False

def test_chart_interaction_stays_read_only_for_flight_clearance():
    html=(ROOT/'app/templates/student_hv_lab.html').read_text(encoding='utf-8')
    javascript=(ROOT/'app/static/js/r22_hv_chart.js').read_text(encoding='utf-8')
    assert 'do not auto' in javascript.lower() or 'does not auto' in javascript.lower()
    assert 'AVOID OPERATION' in html
    assert 'fetch(' not in javascript

def test_instructor_debrief_roles_and_persistence():
    from fastapi.testclient import TestClient
    from app.main import startup
    from app.db import SessionLocal
    from app.models import User, TrainingRecord
    from app.auth import token
    startup()
    db=SessionLocal()
    admin=db.query(User).filter_by(username='admin').first()
    student=db.query(User).filter_by(role='student').first()
    if student is None:
        student=User(username='v129_debrief_student',password_hash='not-used',full_name='Student',role='student',active=True)
        db.add(student); db.commit(); db.refresh(student)
    admin_id,student_id=admin.id,student.id
    db.close()
    c=TestClient(app)
    c.cookies.set('session',token(admin_id,'admin'))
    page=c.get(f'/instructor/student/{student_id}')
    assert page.status_code==200
    assert 'Instructor flight debrief' in page.text
    csrf=c.cookies.get('csrf')
    payload={k:'Ground instructor observed this directly' for k in ('aircraft','lesson_objective','observed_tasks','strengths','corrections','next_objectives')}
    payload.update(flight_date='2026-10-12',observed_standard='developing',csrf=csrf)
    assert c.post(f'/instructor/student/{student_id}/debrief',data=payload,follow_redirects=False).status_code==303
    assert c.post(f'/instructor/student/{student_id}/debrief',data={**payload,'csrf':'wrong'},follow_redirects=False).status_code in (400,403)
    assert c.post(f'/instructor/student/{student_id}/debrief',data={**payload,'observed_standard':'solo_approved'},follow_redirects=False).status_code==422
    db=SessionLocal()
    record=db.query(TrainingRecord).filter_by(user_id=student_id,module='instructor_debrief').order_by(TrainingRecord.id.desc()).first()
    assert record and record.score==0 and record.status=='review'
    assert 'instructor-observation' in record.notes
    db.close()
    student_client=TestClient(app)
    student_client.cookies.set('session',token(student_id,'student'))
    assert student_client.get(f'/instructor/student/{student_id}').status_code==403

def test_instrument_quiz_server_scoring_and_account_persistence():
    from fastapi.testclient import TestClient
    from app.main import startup
    from app.db import SessionLocal
    from app.models import User, TrainingRecord
    from app.auth import token
    from app.instrument_training import INSTRUMENTS,score_clicks
    startup()
    db=SessionLocal()
    u=db.query(User).filter_by(username='admin').first()
    uid,role=u.id,u.role
    db.close()
    points={key:[x,y] for key,name,x,y in INSTRUMENTS}
    assert all(x['correct'] for x in score_clicks(points))
    bad=dict(points);bad[INSTRUMENTS[0][0]]=[0.99,0.99]
    assert sum(x['correct'] for x in score_clicks(bad))==len(INSTRUMENTS)-1
    c=TestClient(app)
    c.cookies.set('session',token(uid,role))
    page=c.get('/r22-instrument-academy')
    assert page.status_code==200
    assert 'r22_poh_instruments_7_19_quiz.png' in page.text
    csrf=c.cookies.get('csrf')
    response=c.post('/api/student-instrument-score',json={'csrf':csrf,'answers':points})
    assert response.status_code==200,response.text
    assert response.json()['correct']==5
    response=c.post('/api/student-instrument-score',json={'csrf':csrf,'answers':{INSTRUMENTS[0][0]:[0,0]}})
    assert response.status_code==422
    assert c.post('/api/student-instrument-score',json={'csrf':'wrong','answers':points}).status_code in (400,403)
    db=SessionLocal()
    row=db.query(TrainingRecord).filter_by(user_id=uid,module='r22_instrument_academy').order_by(TrainingRecord.id.desc()).first()
    assert row and row.status=='practice' and row.score==100
    db.close()

def test_new_routes_render_html_authentically_without_jinja_errors():
    from fastapi.testclient import TestClient
    from app.main import startup
    from app.db import SessionLocal
    from app.models import User
    from app.auth import token
    startup()
    db=SessionLocal()
    admin=db.query(User).filter_by(username='admin').first()
    uid,role=admin.id,admin.role
    db.close()
    c=TestClient(app)
    c.cookies.set('session',token(uid,role))
    for url in ('/r22-height-velocity-lab','/r22-instrument-academy','/student-pathways'):
        result=c.get(url)
        assert result.status_code==200,(url,result.text[:400])
        assert '<html' in result.text
    for asset in ('/static/js/r22_hv_chart.js','/static/js/r22_instrument_academy.js','/static/img/r22_poh_instruments_7_19_quiz.png','/static/img/r22_poh_height_velocity_section5_11.png'):
        result=c.get(asset)
        assert result.status_code==200,(asset,result.status_code)
