# v126 Implementation and verification

Base: production v125. Preserves existing database schema, Windows/Linux scripts, user records, installers, and modules.

## Added
- All 18 Student Pilot Pathways now offer a dedicated workbench page reachable from both the directory and each pathway's detail page.
- Each page combines linked existing operational trainers, the source reference, scenario choices with item-by-item post-submit explanations, and the relevant validated preparation input schema.
- Every submission is authenticated, protected by the existing CSRF token, validated on the server and stored as a personal `student_workbench` record without granting flight hours, proficiency, solo eligibility or instructor signoff.
- Existing standalone R22 SFAR 73 and hover training activities remain available and are linked from appropriate workbenches.

## Tests
- Entire included Python test suite: 374 passed.
- Python compilation and existing JS hover module syntax pass.
- Workbench configuration count and registered routes covered by regression tests.
- ZIP integrity is checked during packaging.

## Restrictions
This update is an integration of existing aviation labs plus persistent workbenches, not a claim of 18 newly built high-fidelity simulation engines. A full aircraft-specific, source-page-by-source-page verification of every legacy lesson, question, procedure, numeric limitation, and performance chart has not been established. The workbenches are practice content, not FAA/Robinson-approved training, an R22 flight simulator, or a CFI endorsement. No native Windows/Debian installation test or independent qualified instructor review is claimed.
