# SFAR 73 verification record — 12 October 2026

Source: 14 CFR Part 61, SFAR No. 73, Amendment 61-154 (89 FR 59608, July 23, 2024), checked against eCFR current text via https://ecfr.io/Title-14/Part-61/Appendix-special-federal-aviation-regulation-no-73 and official rule https://www.govinfo.gov/content/pkg/FR-2024-07-23/pdf/2024-15924.pdf.

Verified text-to-question mapping:
- §2(a)(3)(i)-(v): ground subject headings (energy management, mast bumping, low RPM and rotor stall, low-G conditions/effects/proper recovery, RPM decay).
- §2(b)(3): for a person without rotorcraft category and helicopter class rating, 20 hours R22 training by an instructor authorized under §2(b)(5)(iv), specified flight maneuvers, instructor solo proficiency endorsement valid 90 days.
- §2(b)(3)(i)-(iv): autorotation and energy management; maximum-glide configuration autorotations; governor-off RPM control; low RPM recognition and recovery.
- §2(b)(5): special experience, training and authorization of instructor.
- §2(b)(1): R22 PIC experience and flight-training alternative.
- §2(c): R22 flight review.

This record covers only the indicated SFAR 73 questions/eligibility text. It is not an FAA approval, independent CFI review or full validation of other application content.
