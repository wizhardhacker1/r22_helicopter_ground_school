"""Fail-closed, reproducible gate for source verification and offline content.
Run: python tools/aviation_release_gate.py --output <json-path>
The gate does not equate automated test success with factual aviation review.
"""
import argparse, csv, json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def inspect():
    ledger=ROOT/'AVIATION_CONTENT_AUDIT_v119/all_assessment_items.csv'
    checks=[]
    rows=list(csv.DictReader(ledger.open(encoding='utf-8-sig',newline='')))
    verified=[r for r in rows if r['factual_verification'].strip().upper() in {'VERIFIED','SOURCE_VERIFIED'}]
    signed=[r for r in rows if r['instructor_review'].strip().upper() in {'APPROVED','SIGNED_OFF'}]
    weak=[r for r in rows if r['automatic_findings'].strip()]
    checks.append(dict(id='assessment_source_verification',pass_check=len(rows)>0 and len(verified)==len(rows),total=len(rows),verified=len(verified),flagged=len(weak)))
    checks.append(dict(id='instructor_item_review',pass_check=len(rows)>0 and len(signed)==len(rows),total=len(rows),signed_off=len(signed)))
    chart_dir=ROOT/'app/static/faa_charts'
    chart_files=[p for p in chart_dir.rglob('*') if p.is_file() and p.name.lower()!='readme.txt']
    checks.append(dict(id='offline_faa_charts_present',pass_check=bool(chart_files),bundled_files=len(chart_files)))
    poh=ROOT/'data/R22_POH_reference.pdf'
    checks.append(dict(id='bundled_poh_present',pass_check=poh.exists() and poh.stat().st_size>100_000,sha256=hashlib.sha256(poh.read_bytes()).hexdigest() if poh.exists() else None))
    # These operational checks demand independent evidence, not a test count.
    for ident in ['all_19_emergency_procedures_independently_checked','r22_performance_and_wb_independent_cases','native_windows_install_accepted','native_linux_install_accepted','desktop_and_mobile_browser_interactions','microphone_atc_runtime','all_18_modules_full_acceptance']:
        checks.append(dict(id=ident,pass_check=False,reason='No accepted individual end-to-end evidence packaged'))
    return dict(source_build='v129',overall_pass=all(c['pass_check'] for c in checks),checks=checks)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output');args=p.parse_args()
    report=inspect(); raw=json.dumps(report,indent=2)
    if args.output: Path(args.output).write_text(raw+'\n',encoding='utf-8')
    else: print(raw)
    raise SystemExit(0 if report['overall_pass'] else 1)
