# v127 verified scope (October 12, 2026)

Adds offline TAF decoding to the existing METAR weather-practice page. Recognizes issue and validity windows, FM, TEMPO, BECMG, and PROB30/40 changes; preserves unsupported code groups for manual interpretation. FAA AIM 7-1-28 and FAA-H-8083-28B are format references. No automatic flight category or dispatch determination.

Test suite: 377 passed (local Linux/Python environment). Python compilation and Jinja parsing passed.

NOT a complete delivery of all 18 full training feature specifications. No native Windows installer execution or independent R22 CFI signoff is implied. Existing student-training procedures have not all been individually source verified.
