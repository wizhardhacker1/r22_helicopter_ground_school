# R22 v120 safety audit and evidence boundaries

## Confirmed against controlling public regulation
- FAA SFAR No. 73 requires specified ground-training subject areas and instructor endorsement. Study software cannot grant an endorsement. Source: https://www.ecfr.gov/current/title-14/part-61/appendix-Special%20Federal%20Aviation%20Regulation%20No.%2073
- FAA private helicopter ACS FAA-S-ACS-15 is a testing standard and does not approve this application: https://www.faa.gov/training_testing/testing/acs/private_helicopter_acs_15.pdf
- Robinson's published R22 POH log (22 Feb 2024) and later 2025 Safety Notice revisions are independent revision-controlled sources: https://www.robinsonheli.com/publications

## Corrected safety-critical misleading behavior
1. Emergency API cannot mark a keyword-based response as completed proficiency. It saves as `practice_only`.
2. Unknown emergency scenario identifiers return HTTP 422 rather than silently grading a different scenario.
3. Emergency syllabus completion cannot be awarded from keyword-based emergency records, including historical ones.
4. API explicitly declares its result is unverified keyword recall, not a sequence-validated emergency assessment.

## Unresolved blocking items
- 212 assessment questions have not been individually corroborated to exact governing source pages. Inventory alone is NOT verification.
- 19 emergency procedures and simulator controls need step-by-step POH/variant/source correlation.
- Official FAA offline chart tiles are not present.
- Flight calculations need independently verified applicable R22 variant and airframe data.
- Full browser/device/installer trials and qualified R22 instructor review are not documented.

**NOT APPROVED AS A FULLY VERIFIED FLIGHT TRAINING CURRICULUM.**
