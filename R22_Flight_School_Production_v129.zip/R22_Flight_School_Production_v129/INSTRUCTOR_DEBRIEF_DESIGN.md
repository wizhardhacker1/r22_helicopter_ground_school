# Instructor observation and debrief

Route: POST /instructor/student/{uid}/debrief. Requires authenticated `admin` or `instructor`. Instructors must have an existing assignment to the student. CSRF validation, required seven fields, field length maximum 3000, enumerated observation category, audit of author user ID, per-student record history. Stored separately from regulatory endorsements and logged flight hours.

No code path awards student flight proficiency, FAA endorsement, or hours based on this record.
