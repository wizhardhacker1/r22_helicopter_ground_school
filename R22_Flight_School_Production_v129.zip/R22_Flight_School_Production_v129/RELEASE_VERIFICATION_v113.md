# R22 Flight School v113 — Training Asset Integration & Full Audit

## New interactive training
- Added **R22 Drive System Learning Lab** under **R22 Aircraft**.
- Added **R22 Autorotation Learning Lab** under **Safety & Flight Labs**.
- Integrated four reference images into appropriate training contexts.
- The R44 autorotation poster is used **only** for a source-discipline exercise and is clearly marked **NOT AN R22 PROCEDURE SOURCE**.
- R22 autorotation instruction is grounded in the bundled current R22 POH Section 4, not the R44 poster.
- Drive-system instruction is grounded in R22 POH Section 7, Section 4 run-up caution, Robinson Safety Notice SN-36, and the current R22 Maintenance Manual publication baseline.

## Drive System Lab
- Learn mode: component explanations and source notes.
- Power Flow mode: interactive engine-to-main/tail-rotor torque path.
- Image Quiz: direct component identification on the reference images; six unique items required for pass.
- Uses the reference images for orientation without treating non-authoritative image text/numbers as operating limitations.
- Completion can be recorded through the existing training-record API.

## Autorotation Lab
- Learn mode: R22-specific entry, glide, flare, and level/cushion sequence.
- Practice mode: student assembles the R22 power-recovery sequence in order.
- Source Check mode: teaches why R44 material cannot be copied into R22 procedures.
- Quiz mode: five R22-specific knowledge questions; 80% required for recorded completion.
- Browser interaction audit completed at 5/5 and practice-sequence completion.

## Source accuracy decisions
- R22 POH Section 4 supports the 60–70 KIAS practice-autorotation target, flare at about 40 ft AGL, and level/cushion action at about 8 ft AGL.
- R22 POH Section 4 supports the caution to avoid continuous rotor operation at 60–70% to minimize tail resonance.
- R22 POH Section 7 describes the long tail-rotor drive shaft as having no support bearings but a lightly-loaded damper bearing.
- SN-36 explains that the damper controls tail-rotor shaft vibration through the normal RPM range.
- Current Robinson publication-status baseline checked for this build: R22 POH approved-page log 22 Feb 2024; R22 Maintenance Manual Aug 2026.

## Application-wide audit
- **321/321 pytest tests passed**.
- **63/63 concrete GET routes** returned expected HTTP 200/302/303 responses.
- **19/19 Emergency Procedures scenario routes** returned HTTP 200.
- **44/44 Student Pilot Training Roadmap links** returned HTTP 200.
- **56/56 literal internal template links** returned valid responses with HTTPS/TLS initialized.
- **51/51 Jinja templates** parsed successfully.
- All JavaScript files passed `node --check`.
- Python `compileall` passed.
- Linux installer/trust/start helper scripts passed `bash -n`.
- No missing literal static assets found.
- No duplicate literal DOM IDs found.
- No known baked-in `&#x...;`, `u2502`, `u2571`, or replacement-character text artifacts found.
- Major-page render audit found **no horizontal overflow** at 1600 px or 390 px widths.
- Corrected text contrast/washout surfaces in startup engine mini-readouts, Performance/W&B loading labels, Flight Planner result panel, Oral feedback panel, Rotor Motion control outputs, compact page headers, POH status, and footer text.
- New training scripts and all four new training images are explicitly included in the service-worker offline core cache.

## HTTPS / local network regression
- Actual Uvicorn HTTPS server launched with generated installation-specific TLS certificate.
- `https://127.0.0.1:18086/health` returned `{"ok":true,...}` during verification.
- CA/private-key security tests remain enabled; no private CA/server keys are bundled in this release.

## Important training limitation
This application is a training aid. It does not replace the current approved R22 POH/RFM, applicable supplements, aircraft records, current Robinson publications, required instructor training, or actual flight proficiency.
