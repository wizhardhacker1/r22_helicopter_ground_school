"""Offline student-only calculators; never authorizes operation."""
import math

def rotorcraft_vfr_fuel(hours, gallons_per_hour, usable_gallons, contingency_gallons=0, reserve_minutes=20):
    """14 CFR 91.151(b) baseline is 20 minutes at normal cruise for rotorcraft VFR.
    Inputs must be verified for actual aircraft and conditions by the pilot.
    """
    values=(hours,gallons_per_hour,usable_gallons,contingency_gallons,reserve_minutes)
    if any(type(v) not in (int,float) or not math.isfinite(v) or v<0 for v in values):
        raise ValueError('All entries must be nonnegative finite numbers')
    if hours>48 or gallons_per_hour>100 or usable_gallons>200 or contingency_gallons>200 or reserve_minutes>1440:
        raise ValueError('Entry out of bounds; recheck units')
    if gallons_per_hour==0: raise ValueError('Verified consumption must be greater than zero')
    if reserve_minutes<20: raise ValueError('VFR rotorcraft baseline reserve is at least 20 minutes per 14 CFR 91.151(b)')
    destination=hours*gallons_per_hour
    reserve=(reserve_minutes/60)*gallons_per_hour
    required=destination+reserve+contingency_gallons
    return {'destination_gallons':round(destination,3),'reserve_gallons':round(reserve,3),'total_gallons':round(required,3),'margin_gallons':round(usable_gallons-required,3),'meets_entered_arithmetic':usable_gallons>=required,'source':'14 CFR 91.151(b); aircraft-specific usable fuel and normal cruise burn must be verified'}

def r22_solo_prerequisite_screen(has_helicopter_rating, verified_r22_instruction_hours, awareness_endorsement, solo_endorsement, endorsement_days_old=None):
    """Conservative, non-authorizing checklist: not a regulatory eligibility determination."""
    if type(has_helicopter_rating) is not bool or type(awareness_endorsement) is not bool or type(solo_endorsement) is not bool:
        raise ValueError('Provide explicit yes/no evidence flags')
    if not isinstance(verified_r22_instruction_hours,(int,float)) or isinstance(verified_r22_instruction_hours,bool) or not math.isfinite(verified_r22_instruction_hours) or not 0<=verified_r22_instruction_hours<=100000:
        raise ValueError('Invalid verified flight hours')
    if endorsement_days_old is not None and (not isinstance(endorsement_days_old,(int,float)) or isinstance(endorsement_days_old,bool) or not math.isfinite(endorsement_days_old) or endorsement_days_old<0):
        raise ValueError('Invalid endorsement age')
    missing=[]
    if not awareness_endorsement:missing.append('Authorized instructor SFAR 73 awareness training and logbook endorsement requires confirmation')
    if not has_helicopter_rating and verified_r22_instruction_hours<20:
        missing.append('SFAR 73 R22 solo prerequisite: at least 20 hours verified instructor flight training for a pilot without rotorcraft-helicopter rating')
    if not solo_endorsement:missing.append('Current authorized instructor SFAR 73 R22 solo endorsement requires confirmation')
    if endorsement_days_old is None: missing.append('Date/validity of the SFAR 73 solo endorsement not established')
    elif endorsement_days_old>90:missing.append('SFAR 73 solo endorsement older than 90 days')
    missing.append('Verify SFAR 73 section 2(b)(3) training in autorotation and energy management, maximum-glide autorotations, RPM control without governor, and low-RPM recognition/recovery')
    missing.append('Confirm the providing instructor is specifically authorized under SFAR 73 section 2(b)(5)(iv)')
    missing.append('Other 14 CFR 61.87 prerequisites, applicable experience, instructor authorization and aircraft records must be independently verified')
    return {'identified_issues':missing, 'authorized_to_solo':False,'source':'SFAR 73 §2(a), §2(b)(3); 14 CFR 61.87'}
