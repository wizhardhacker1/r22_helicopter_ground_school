"use strict";
(() => {
 const stage = document.getElementById('hv-stage');
 const overlay = document.getElementById('hv-overlay');
 const marker = document.getElementById('hv-marker');
 const output = document.getElementById('hv-output');
 if (!stage || !overlay || !marker || !output) return;
 // Calibration of the original unaltered POH page image: axis endpoints, not the figure's printed page borders.
 const AXES = {left: 0.247, right: 0.908, top: 0.234, bottom: 0.760};
 const report = (event) => {
   const rect = stage.getBoundingClientRect();
   const x = (event.clientX-rect.left)/rect.width;
   const y = (event.clientY-rect.top)/rect.height;
   if(x < AXES.left || x > AXES.right || y < AXES.top || y > AXES.bottom) {
     output.textContent = 'Select a point inside the original graph axes.';
     return;
   }
   const speed = Math.max(0, Math.min(100, 100*(x-AXES.left)/(AXES.right-AXES.left)));
   const height = Math.max(0, Math.min(700,700*(AXES.bottom-y)/(AXES.bottom-AXES.top)));
   marker.setAttribute('transform', `translate(${(x*1000).toFixed(2)} ${(y*1000).toFixed(2)})`);
   marker.setAttribute('visibility','visible');
   output.textContent = `Approximate plotted reading: ${speed.toFixed(0)} KIAS, ${height.toFixed(0)} ft AGL. Interpret the shading and correct condition envelope directly from the original POH chart with an instructor; the app does not auto-authorize this point.`;
 };
 stage.addEventListener('click', report);
 document.getElementById('hv-reset')?.addEventListener('click',()=>{marker.setAttribute('visibility','hidden');output.textContent='Selection cleared. Select a point on the chart.';});
})();
