"use strict";
(function(){
 const el=id=>document.getElementById(id);
 const number=id=>{const node=el(id), n=Number(node.value);if(!node.value.trim()||!Number.isFinite(n)||n<0)throw Error('Enter a valid nonnegative number for '+id);return n;};
 el('fuel-tool')?.addEventListener('submit',()=>{let out=el('ft-result');try{
 const time=number('ft-time'),rate=number('ft-rate'),usable=number('ft-usable'),reserve=number('ft-reserve'),cont=number('ft-cont');
 if(time>48||rate<=0||rate>100||usable>200||reserve<20||reserve>1440||cont>200)throw Error('Value outside permitted bounds or reserve below the 20-minute VFR rotorcraft baseline');
 const enroute=time*rate,buffer=reserve/60*rate,total=enroute+buffer+cont,margin=usable-total;
 out.textContent=`Estimated en route: ${enroute.toFixed(2)} US gal; reserve: ${buffer.toFixed(2)} US gal; contingency: ${cont.toFixed(2)} US gal; total: ${total.toFixed(2)} US gal; entered-fuel margin: ${margin.toFixed(2)} US gal. ${margin<0?'INSUFFICIENT under entered assumptions.':'Sufficient only under entered arithmetic assumptions.'} Confirm fuel, actual conditions, usable quantity and regulatory applicability before any flight.`;
 }catch(e){out.textContent='Cannot calculate: '+e.message;}});
 el('solo-tool')?.addEventListener('submit',()=>{let out=el('solo-result');try{
 const hrs=number('solo-hours'),rated=el('solo-rated').value==='yes',awareness=el('solo-awareness').value==='yes',endorsed=el('solo-endorsement').value==='yes',daysRaw=el('solo-days').value.trim();
 const days=daysRaw?number('solo-days'):null;
 const issues=[];
 if(!awareness)issues.push('SFAR 73 awareness ground training and endorsement not confirmed');
 if(!rated&&hrs<20)issues.push('For a pilot without rotorcraft-helicopter rating, the 20-hour R22 flight-training prerequisite has not been met in the recorded evidence');
 if(!endorsed)issues.push('SFAR 73 R22 solo endorsement not confirmed');
 if(days===null)issues.push('Endorsement date not established');else if(days>90)issues.push('Solo endorsement exceeds 90-day SFAR 73 validity');
 issues.push('Verify instructor authorization under SFAR 73 2(b)(5)(iv) and documented training in autorotation/energy management, maximum-glide autorotations, RPM control without governor, and low-RPM recognition/recovery under 2(b)(3)');
 issues.push('Instructor must independently verify remaining 14 CFR 61.87 requirements, SFAR 73 flight maneuvers, endorsements, and aircraft readiness');
 out.replaceChildren();const p=document.createElement('p');p.textContent='Not a solo authorization. Items for instructor review:';out.append(p);const ul=document.createElement('ul');for(const issue of issues){const li=document.createElement('li');li.textContent=issue;ul.append(li);}out.append(ul);
 }catch(e){out.textContent='Cannot review: '+e.message;}});
})();