"use strict";
(() => {
 const items = [
 ['vertical-speed','Vertical speed indicator'],
 ['airspeed','Airspeed indicator'],
 ['tachometer','Engine and rotor tachometers'],
 ['altimeter','Altimeter'],
 ['manifold','Manifold pressure gage'],
 ];
 const byId=id=>document.getElementById(id), stage=byId('instrument-stage'), prompt=byId('instrument-prompt'),feedback=byId('instrument-feedback'),svg=byId('instrument-overlay'),submit=byId('instrument-submit');
 if(!stage||!prompt||!feedback||!svg||!submit)return;
 let answers={}, i=-1;
 const reset=()=>{i=0;answers={};svg.replaceChildren();feedback.textContent='';submit.disabled=true;prompt.textContent=`Question 1/${items.length}: Click the ${items[0][1]}.`;};
 byId('instrument-start').addEventListener('click',reset);
 stage.addEventListener('click',e=>{
   if(i<0||i>=items.length)return;
   const rect=stage.getBoundingClientRect();
   const x=Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width)), y=Math.max(0,Math.min(1,(e.clientY-rect.top)/rect.height));
   answers[items[i][0]]=[x,y];
   const circle=document.createElementNS('http://www.w3.org/2000/svg','circle');
   circle.setAttribute('cx',String(x*1000));circle.setAttribute('cy',String(y*1000));circle.setAttribute('r','14');circle.setAttribute('fill','#0cbd87');circle.setAttribute('fill-opacity','0.2');circle.setAttribute('stroke','#0d9');circle.setAttribute('stroke-width','4');svg.append(circle);
   i++;
   if(i<items.length){prompt.textContent=`Question ${i+1}/${items.length}: Click the ${items[i][1]}.`;}
   else{prompt.textContent='All five locations selected. Submit to see verified results.';submit.disabled=false;}
 });
 submit.addEventListener('click',async()=>{
  try{
   const response=await fetch('/api/student-instrument-score',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({csrf:window.r22QuizToken,answers})});
   if(!response.ok)throw Error(`Server returned ${response.status}`);
   const result=await response.json();
   feedback.textContent=`Saved ${result.correct}/${result.total} correct — ${result.items.map(r=>r.label+': '+(r.correct?'correct':'review location')).join('; ')}. Instructor review is required for actual aircraft familiarity.`;
   submit.disabled=true;
  }catch(e){feedback.textContent='Could not save instrument quiz: '+e.message;}
 });
})();
