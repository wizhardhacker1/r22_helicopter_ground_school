"""Conservative offline US METAR decoding for student practice.

Only recognizes known fields. Unknown/variable or missing tokens remain visible;
never infer flight category, operating permission, or conditions from partial text.
FAA AIM 7-1-29 and FAA-H-8083-28B are the format references.
"""
import re

def decode_metar(raw: str):
    if not isinstance(raw,str) or len(raw)>1200:
        raise ValueError('METAR must be text of at most 1200 characters')
    tokens=raw.strip().upper().replace('=',' ').split()
    if not tokens or tokens[0] not in ('METAR','SPECI'):
        raise ValueError('Begin with METAR or SPECI; do not omit the report type')
    if len(tokens)<3 or not re.fullmatch(r'[A-Z0-9]{4}', tokens[1]):
        raise ValueError('Four-character station identifier required')
    result={'type':tokens[0], 'station':tokens[1], 'observation_utc':None,
            'wind':None, 'visibility':None, 'clouds':[], 'temperature_c':None,
            'dewpoint_c':None, 'altimeter_inhg':None, 'unparsed':[],
            'advisory':'Training decode only; NOT a current weather briefing or flight release.'}
    in_remarks=False
    remaining = tokens[2:]
    index = 0
    while index < len(remaining):
        tok = remaining[index]
        index += 1
        # U.S. METAR visibility may be two tokens, e.g. 1 1/2SM.
        if re.fullmatch(r'\d+', tok) and index < len(remaining) and re.fullmatch(r'\d+/\d+SM', remaining[index]):
            tok += ' ' + remaining[index]
            index += 1
        if tok=='RMK':
            in_remarks=True
        if in_remarks:
            result['unparsed'].append(tok)
            continue
        if re.fullmatch(r'\d{6}Z',tok):
            result['observation_utc']=tok[:2]+' day '+tok[2:4]+':'+tok[4:6]+' UTC (month/year not encoded)'
        elif re.fullmatch(r'(\d{3}|VRB)\d{2,3}(G\d{2,3})?KT',tok):
            m=re.fullmatch(r'(\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?KT',tok)
            direction='variable' if m[1]=='VRB' else f'{int(m[1])}° true'
            result['wind']=f'{direction}, {int(m[2])} kt'+(f', gust {int(m[3])} kt' if m[3] else '')
        elif re.fullmatch(r'(?:P\d+|M\d+/\d+|\d+|\d+/\d+|\d+ \d+/\d+)SM',tok):
            result['visibility']=tok
        elif tok in ('CAVOK','SKC','CLR','NSC','NCD'):
            result['clouds'].append(tok+' (see report convention for meaning)')
        elif re.fullmatch(r'(FEW|SCT|BKN|OVC)\d{3}(CB|TCU)?',tok):
            result['clouds'].append(tok[:3]+' '+str(int(tok[3:6])*100)+' ft above station'+(' '+tok[6:] if len(tok)>6 else ''))
        elif re.fullmatch(r'VV\d{3}',tok):
            result['clouds'].append('vertical visibility '+str(int(tok[2:])*100)+' ft')
        elif re.fullmatch(r'M?\d{2}/M?\d{2}',tok):
            t,d=tok.split('/')
            result['temperature_c']=-int(t[1:]) if t.startswith('M') else int(t)
            result['dewpoint_c']=-int(d[1:]) if d.startswith('M') else int(d)
        elif re.fullmatch(r'A\d{4}',tok):
            result['altimeter_inhg']=f'{int(tok[1:])/100:.2f}'
        else:
            result['unparsed'].append(tok)
    return result
