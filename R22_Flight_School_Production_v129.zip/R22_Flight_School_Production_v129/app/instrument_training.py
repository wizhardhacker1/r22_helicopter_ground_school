"""Learning coordinates tied to the R22 POH Section 7-19 diagram, typical earlier-aircraft configuration."""
INSTRUMENTS = [('vertical-speed', 'Vertical speed indicator', 0.43434343434343436, 0.3236903763566828), ('airspeed', 'Airspeed indicator', 0.5669191919191919, 0.3236903763566828), ('tachometer', 'Engine and rotor tachometers', 0.6325757575757576, 0.3236903763566828), ('altimeter', 'Altimeter', 0.4734848484848485, 0.40691823899371067), ('manifold', 'Manifold pressure gage', 0.6047979797979798, 0.40691823899371067)]

def score_clicks(answer_positions):
    if not isinstance(answer_positions,dict) or set(answer_positions)!={x[0] for x in INSTRUMENTS}:
        raise ValueError('All instrument identifications are required')
    out=[]
    for key,title,center_x,center_y in INSTRUMENTS:
        value=answer_positions[key]
        if not isinstance(value,(list,tuple)) or len(value)!=2:
            raise ValueError('Invalid coordinate')
        from math import isfinite
        x,y=value
        if type(x) not in (float,int) or type(y) not in (float,int) or not all(map(isfinite,(x,y))) or not 0<=x<=1 or not 0<=y<=1:
            raise ValueError('Invalid coordinate')
        good=abs(x-center_x)<=0.055 and abs(y-center_y)<=0.055
        out.append({'key':key,'label':title,'correct':good})
    return out
