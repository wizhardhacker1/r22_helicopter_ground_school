"""Conservative offline TAF teaching parser.

AIM 7-1-28: forecast times in UTC; FM starts a new prevailing period;
TEMPO and PROB groups are contingent, not guaranteed prevailing conditions.
Unsupported fields remain visible and undecoded. This is not a flight briefing.
"""
import re

CHANGE=re.compile(r'FM\d{6}|TEMPO|BECMG|PROB(?:30|40)')
PERIOD=re.compile(r'\d{4}/\d{4}')

def decode_taf(raw: str) -> dict:
    if not isinstance(raw,str) or len(raw)>3000:
        raise ValueError('TAF must be text no longer than 3000 characters')
    tokens=raw.upper().replace('=', ' ').split()
    if not tokens or tokens[0]!='TAF':
        raise ValueError('Forecast must begin with TAF')
    idx=1; modifiers=[]
    while idx<len(tokens) and tokens[idx] in ('AMD','COR'):
        modifiers.append(tokens[idx]);idx+=1
    if idx>=len(tokens) or not re.fullmatch(r'[A-Z][A-Z0-9]{3}',tokens[idx]):
        raise ValueError('TAF requires a four-character station identifier')
    station=tokens[idx];idx+=1
    if idx>=len(tokens) or not re.fullmatch(r'\d{6}Z',tokens[idx]):
        raise ValueError('TAF requires issue date/time DDHHMMZ')
    issued=tokens[idx];idx+=1
    if idx>=len(tokens) or not PERIOD.fullmatch(tokens[idx]):
        raise ValueError('TAF requires validity period DDHH/DDHH')
    validity=tokens[idx];idx+=1
    periods=[]
    current={'kind':'BASE','window':validity,'tokens':[],'interpreted':[],'unparsed':[]}
    periods.append(current)
    while idx<len(tokens):
        tok=tokens[idx]
        # Mixed-number statute-mile visibility is transmitted as separate groups.
        if re.fullmatch(r'\d+', tok) and idx + 1 < len(tokens) and re.fullmatch(r'\d+/\d+SM', tokens[idx + 1]):
            tok += ' ' + tokens[idx + 1]
            idx += 1
        if CHANGE.fullmatch(tok):
            kind='FM' if tok.startswith('FM') else tok
            current={'kind':kind,'window':tok[2:] if kind=='FM' else '', 'tokens':[], 'interpreted':[], 'unparsed':[]}
            periods.append(current)
            idx+=1
            if kind in ('TEMPO','BECMG','PROB30','PROB40'):
                if idx>=len(tokens) or not PERIOD.fullmatch(tokens[idx]):
                    raise ValueError(kind+' requires a valid DDHH/DDHH interval')
                current['window']=tokens[idx];idx+=1
            continue
        current['tokens'].append(tok)
        if re.fullmatch(r'(?:\d{3}|VRB)\d{2,3}(?:G\d{2,3})?KT',tok):
            current['interpreted'].append('Wind '+tok+' (knots)')
        elif re.fullmatch(r'(?:P\d+|M\d+/\d+|\d+|\d+/\d+|\d+ \d+/\d+)SM',tok):
            current['interpreted'].append('Visibility '+tok)
        elif re.fullmatch(r'(?:FEW|SCT|BKN|OVC)\d{3}(?:CB|TCU)?',tok):
            current['interpreted'].append('Cloud layer '+tok+' (base hundreds of feet above station)')
        elif tok in ('SKC','CLR','NSC','NSW','CAVOK'):
            current['interpreted'].append(tok+' (confirm report convention)')
        else:
            current['unparsed'].append(tok)
        idx+=1
    return {'type':'TAF','station':station,'issue_utc':issued,'validity_utc':validity,
            'modifiers':modifiers,'periods':periods,
            'advisory':'Offline training interpretation only. Check complete current official TAF, METAR, NOTAMs and weather briefing; no go/no-go or VFR determination.'}
