SYLLABUS=[
('orientation','Course Orientation & R22 Documents','POH/RFM use, aircraft records, limitations, required documents, checklist discipline'),
('aero','Helicopter Aerodynamics','translating tendency, dissymmetry, ETL, retreating blade stall, settling with power, LTE, ground effect, low-G hazards'),
('controls','R22 Controls & Systems','cyclic, collective, pedals, throttle/governor, drivetrain, rotor, fuel, electrical, warning systems'),
('preflight','Preflight & Ground Operations','POH preflight, cockpit setup, starting, rotor engagement, run-up, shutdown, rotor safety'),
('hover','Hover & Taxi','hover control, hover taxi, pedal turns, slope/wind awareness, dynamic rollover avoidance'),
('takeoff','Takeoffs & Landings','normal takeoff, approach, landing, traffic pattern, confined/pinnacle concepts, H/V awareness'),
('maneuvers','Flight Maneuvers','straight/level, climbs, descents, turns, steep approaches, quick stops, ground reference'),
('emergency','Emergencies & Autorotation','power failure, autorotation concepts, tail rotor failures, fires, governor/tach failures, warning lights'),
('performance','Performance & W&B','CG, loading, fuel, density altitude, IGE/OGE, power limits, Vne, performance planning'),
('weather','Weather & ADM','weather theory/services, risk management, personal minimums, go/no-go, aeromedical factors'),
('nav','Navigation & Airspace','charts, airspace, airports, navigation, flight planning, NOTAM/TFR awareness'),
('atc','ATC Communications','non-towered/towered calls, taxi, hold short, pattern, departure, arrival, flight following, emergencies'),
('night','Night Operations','night illusions, lighting, planning, emergency considerations'),
('written','FAA Knowledge Test Readiness','ACS-mapped knowledge review, weak-area remediation, full practice tests'),
('oral','Oral & Practical Test Preparation','scenario oral, aircraft systems/limitations, risk management, practical-test task review')]
EMERGENCIES={
'power_high':{'title':'Power Failure Above 500 ft AGL','prompt':'You hear the low-RPM horn and lose power at 900 ft AGL. A restart will not be attempted. Perform the published power-failure sequence.','keys':['lower collective','65'],'feedback':'POH: immediately lower collective to enter autorotation; above 500 ft AGL establish approximately 65 KIAS, manage rotor RPM, select a landing area and continue the published procedure.'},
'tail_forward':{'title':'Loss of Tail Rotor Thrust - Forward Flight','prompt':'In forward flight the nose yaws right and left pedal cannot correct it. What is the first action?','keys':['autorotation'],'feedback':'POH: immediately enter autorotation. Maintain at least 70 KIAS if practical, then follow the published landing procedure.'},
'electrical_fire':{'title':'Electrical Fire in Flight','prompt':'Smoke/electrical fire develops in flight. State the first switch action.','keys':['battery','alternator','off'],'feedback':'POH: battery and alternator switches OFF, then follow the complete electrical-fire procedure. Low-RPM warning/governor implications must be understood.'},
'low_g':{'title':'Low-G / Mast-Bumping Avoidance','prompt':'A low-G condition occurs. What cyclic response comes first?','keys':['aft','cyclic'],'feedback':'POH limitation/safety guidance: use gentle aft cyclic to reload the rotor before lateral cyclic correction if a roll develops. This is recognition training, not a maneuver to practice solo.'}}
ATC_SCENARIOS={
'non-towered':{
 'kind':'self_announce',
 'controller':'You are 10 miles west of Bishop Airport at 3,500 feet. Make the recommended inbound CTAF self-announcement for landing Runway 30.',
 'elements':[
  {'key':'airport_open','label':'airport name at beginning','special':'airport_start'},
  {'key':'callsign','label':'aircraft identification','aliases':['helicopter 22bh','helicopter two two bravo hotel','two two bravo hotel','22 bravo hotel','22bh']},
  {'key':'position','label':'10 miles west','aliases':['10 miles west','ten miles west']},
  {'key':'altitude','label':'3,500 feet','aliases':['3500','3 500','three thousand five hundred','three thousand five hundred feet']},
  {'key':'landing','label':'landing intention / Runway 30','all_of':[['landing','inbound','full stop'],['runway 30','runway three zero','runway 3 0']]},
  {'key':'airport_close','label':'airport name at end','special':'airport_end'}],
 'next':'No controller reply is expected. Continue to monitor CTAF and make the appropriate pattern/position reports.',
 'lesson':'CTAF self-announcement',
 'pattern':'Airport name -> aircraft type/call sign -> position -> altitude -> landing intention/runway -> airport name',
 'example':'Bishop traffic, Helicopter Two Two Bravo Hotel, ten miles west, three thousand five hundred, landing Runway Three Zero, Bishop.',
 'example_reply':'No controller response is expected. Listen for other traffic and continue appropriate position reports.',
 'why':'This is a self-announcement on CTAF, not an ATC clearance or readback. FAA guidance recommends the correct airport name, aircraft identification/type, position, altitude, intentions, and the airport name again at the end.'},
'taxi':{
 'kind':'readback','controller':'Ground: Helicopter 22BH, taxi to Runway 30 via Alpha, hold short Runway 30.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'runway','label':'Runway 30','aliases':['runway 30','runway three zero','runway 3 0']},
  {'key':'route','label':'taxiway Alpha','aliases':['alpha','taxiway alpha']},
  {'key':'hold','label':'hold short Runway 30','all_of':[['hold short'],['runway 30','runway three zero','runway 3 0']]}],
 'next':'Ground: Helicopter Two Two Bravo Hotel, readback correct.',
 'lesson':'Taxi / hold-short readback','pattern':'Call sign -> runway -> taxi route -> hold-short restriction',
 'example':'Helicopter Two Two Bravo Hotel, Runway Three Zero via Alpha, hold short Runway Three Zero.',
 'example_reply':'Ground: Helicopter Two Two Bravo Hotel, readback correct.',
 'why':'Runway assignments and hold-short instructions are safety-critical readback items.'},
'pattern':{
 'kind':'readback','controller':'Tower: Helicopter 22BH, enter right downwind Runway 30, report midfield downwind.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'direction','label':'right downwind','aliases':['right downwind','right traffic']},
  {'key':'runway','label':'Runway 30','aliases':['runway 30','runway three zero','runway 3 0']},
  {'key':'report','label':'report midfield downwind','all_of':[['report','will report'],['midfield'],['downwind']]}],
 'next':'Tower: Helicopter Two Two Bravo Hotel, traffic pattern readback correct.',
 'lesson':'Pattern entry','pattern':'Call sign -> traffic direction -> runway -> requested reporting point',
 'example':'Helicopter Two Two Bravo Hotel, right downwind Runway Three Zero, will report midfield downwind.',
 'example_reply':'Tower: Helicopter Two Two Bravo Hotel, traffic pattern readback correct.',
 'why':'Repeat the runway, pattern direction, and requested report so both sides share the same plan.'},
'departure':{
 'kind':'readback','controller':'Tower: Helicopter 22BH, Runway 30 cleared for takeoff, right turnout approved.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'runway','label':'Runway 30','aliases':['runway 30','runway three zero','runway 3 0']},
  {'key':'clearance','label':'cleared for takeoff','aliases':['cleared for takeoff','clear for takeoff']},
  {'key':'turnout','label':'right turnout','aliases':['right turnout','turn right','right turn'] }],
 'next':'Tower: Helicopter Two Two Bravo Hotel, readback correct.',
 'lesson':'Takeoff clearance','pattern':'Call sign -> runway -> cleared-for-takeoff acknowledgement -> turnout',
 'example':'Helicopter Two Two Bravo Hotel, Runway Three Zero cleared for takeoff, right turnout.',
 'example_reply':'Tower: Helicopter Two Two Bravo Hotel, readback correct.',
 'why':'A takeoff clearance contains the runway and the words cleared for takeoff; read back the runway and clearance.'},
'arrival':{
 'kind':'readback','controller':'Tower: Helicopter 22BH, enter right base Runway 30, report two miles.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'entry','label':'right base','aliases':['right base']},
  {'key':'runway','label':'Runway 30','aliases':['runway 30','runway three zero','runway 3 0']},
  {'key':'report','label':'report two miles','all_of':[['report','will report'],['two miles','2 miles']]}],
 'next':'Tower: Helicopter Two Two Bravo Hotel, report two miles.',
 'lesson':'Arrival instruction','pattern':'Call sign -> entry/base -> runway -> requested report',
 'example':'Helicopter Two Two Bravo Hotel, right base Runway Three Zero, will report two miles.',
 'example_reply':'Tower: Helicopter Two Two Bravo Hotel, report two miles.',
 'why':'Read back the assigned pattern/approach instruction and any reporting point.'},
'flight-following':{
 'kind':'readback','controller':'Approach: Helicopter 22BH, squawk 4261 and ident.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'squawk','label':'squawk 4261','aliases':['4261','four two six one','squawk four two six one']},
  {'key':'ident','label':'IDENT acknowledgement','aliases':['ident']}],
 'next':'Approach: Helicopter Two Two Bravo Hotel, radar contact.',
 'lesson':'Transponder instruction','pattern':'Call sign -> assigned squawk code -> IDENT if instructed',
 'example':'Helicopter Two Two Bravo Hotel, squawk Four Two Six One, ident.',
 'example_reply':'Approach: Helicopter Two Two Bravo Hotel, radar contact.',
 'why':'Read back a discrete transponder code digit by digit and comply with IDENT only when instructed.'},
'emergency':{
 'kind':'request','controller':'ATC: Helicopter 22BH, say nature of emergency, intentions, persons aboard, and fuel remaining.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'nature','label':'nature of emergency','aliases':['engine problem','engine failure','power loss','emergency','engine fire','electrical fire']},
  {'key':'intentions','label':'intentions','aliases':['landing','land','autorotating','diverting']},
  {'key':'persons','label':'persons aboard','aliases':['person aboard','persons aboard','souls aboard','people aboard','two persons','2 persons']},
  {'key':'fuel','label':'fuel remaining','aliases':['fuel remaining','hour fuel','minutes fuel','gallons fuel'] }],
 'next':'ATC: Helicopter Two Two Bravo Hotel, roger. Emergency information received.',
 'lesson':'Emergency information','pattern':'Call sign -> nature of emergency -> intentions -> persons aboard -> fuel remaining',
 'example':'Helicopter Two Two Bravo Hotel, engine problem, landing immediately, two persons aboard, one hour fuel remaining.',
 'example_reply':'ATC: Helicopter Two Two Bravo Hotel, roger. Emergency information received.',
 'why':'Aviate first. Give ATC the information you can provide without interfering with aircraft control.'},
'initial-tower':{
 'kind':'request','controller':'You are 8 miles west of Bishop Airport at 3,500 feet, have the current weather, and want a full-stop landing. Make your initial call to Bishop Tower.',
 'elements':[
  {'key':'facility','label':'Bishop Tower','aliases':['bishop tower']},
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'position','label':'8 miles west','aliases':['8 miles west','eight miles west']},
  {'key':'altitude','label':'3,500 feet','aliases':['3500','3 500','three thousand five hundred']},
  {'key':'weather','label':'current weather information','aliases':['with the weather','with current weather','have the weather','with information']},
  {'key':'request','label':'full-stop landing request','aliases':['full stop','landing'] }],
 'next':'Tower: Helicopter Two Two Bravo Hotel, enter right downwind Runway Three Zero, report midfield.',
 'lesson':'Initial tower call','pattern':'Facility -> aircraft type/call sign -> position -> altitude -> weather information -> request',
 'example':'Bishop Tower, Helicopter Two Two Bravo Hotel, eight miles west, three thousand five hundred, with current weather, full-stop landing.',
 'example_reply':'Tower: Helicopter Two Two Bravo Hotel, enter right downwind Runway Three Zero, report midfield.',
 'why':'The first call tells the controller who you are, where you are, and what you want.'},
'frequency-change':{
 'kind':'readback','controller':'Approach: Helicopter 22BH, contact Tower 118.3.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'frequency','label':'118.3','aliases':['118.3','118 point 3','one one eight point three','one eighteen point three'] }],
 'next':'Approach: Helicopter Two Two Bravo Hotel, frequency readback correct.',
 'lesson':'Frequency change','pattern':'Call sign -> new frequency',
 'example':'Helicopter Two Two Bravo Hotel, One One Eight Point Three.',
 'example_reply':'Approach: Helicopter Two Two Bravo Hotel, frequency readback correct.',
 'why':'A short readback confirms you heard the frequency correctly before changing radios.'},
'altitude-heading':{
 'kind':'readback','controller':'Approach: Helicopter 22BH, fly heading 090, maintain 3,500.',
 'elements':[
  {'key':'callsign','label':'aircraft identification','aliases':['22bh','two two bravo hotel','22 bravo hotel','helicopter two two bravo hotel']},
  {'key':'heading','label':'heading 090','aliases':['090','0 9 0','zero niner zero','zero nine zero','heading zero niner zero']},
  {'key':'altitude','label':'3,500','aliases':['3500','3 500','three thousand five hundred'] }],
 'next':'Approach: Helicopter Two Two Bravo Hotel, readback correct.',
 'lesson':'Heading / altitude','pattern':'Call sign -> assigned heading -> assigned altitude',
 'example':'Helicopter Two Two Bravo Hotel, heading Zero Niner Zero, maintain Three Thousand Five Hundred.',
 'example_reply':'Approach: Helicopter Two Two Bravo Hotel, readback correct.',
 'why':'Headings and altitude assignments should be read back accurately; do not paraphrase the numbers.'}
}
EMERGENCIES.update({
'power_mid':{'title':'Power Failure - 8 to 500 ft AGL','prompt':'Power is lost between 8 and 500 ft AGL. What is the first control action and rotor-RPM objective?','keys':['lower collective','97','110'],'feedback':'POH: lower collective immediately and adjust collective to keep rotor RPM 97-110%, then maintain airspeed until the flare and complete the published sequence.'},
'power_low':{'title':'Power Failure - Below 8 ft AGL','prompt':'Power is lost below 8 ft AGL. State the immediate sequence.','keys':['right pedal','settle','collective'],'feedback':'POH: apply right pedal as required to prevent yaw, allow the aircraft to settle, and raise collective just before touchdown to cushion landing.'},
'engine_fire':{'title':'Engine Fire in Flight','prompt':'An engine fire occurs in flight and the engine continues running. Perform the published in-flight fire procedure.','keys':['autorotation'],'feedback':'POH: enter autorotation, then follow the complete engine-fire procedure appropriate to whether the engine continues running.'},
'governor':{'title':'Governor Failure','prompt':'The RPM governor malfunctions. How does the POH direct you to take control?','keys':['throttle','governor','off'],'feedback':'POH: grip throttle firmly to override the governor, switch governor off, and complete the flight using manual throttle control.'},
'audio':{'title':'Headset Audio Failure','prompt':'Your headset audio fails. What landing urgency does the POH specify?','keys':['soon as practical'],'feedback':'POH: land as soon as practical. Remember that some aircraft provide the low-RPM horn through the audio system.'}
})
# Structured lesson briefs. These are study guides; the bundled current POH remains controlling for aircraft operation.
LESSONS={
'orientation':{'title':'R22 Documents & Airworthiness','objectives':['Know what the POH/RFM is and is not','Identify aircraft-specific records and supplements','Use limitations, placards and current data before flight'],'sections':['POH \xa71 General','POH \xa78 Required Documents/Inspections','POH \xa79 Supplements'],'brief':'Use the current approved POH/RFM for the specific helicopter. Confirm applicable supplements, weight-and-balance data, inspections and aircraft status. The POH explicitly is not a substitute for competent instruction.'},
'aero':{'title':'Helicopter Aerodynamics & R22 Hazards','objectives':['Explain translating tendency, ETL and dissymmetry','Recognize vortex ring state and dynamic rollover','Explain why low-G pushover is prohibited'],'sections':['POH \xa72 Flight/Maneuver Limitations','POH \xa710 Safety Tips'],'brief':'Connect aerodynamic concepts to R22 limitations and accident-prevention guidance. Low-G recognition/recovery knowledge, low rotor RPM, dynamic rollover and vortex-ring-state awareness are core R22 risk topics.'},
'controls':{'title':'Controls, Governor & Systems','objectives':['Trace cyclic/collective/pedal/throttle effects','Explain governor and clutch system','Identify warning/caution indications'],'sections':['POH \xa77 Systems Description'],'brief':'Study the rotor, drive, powerplant, flight controls, governor, clutch, fuel, electrical, pitot-static, dual tachometer and warning systems as an integrated aircraft.'},
'preflight':{'title':'Preflight, Start, Run-up & Shutdown','objectives':['Use the complete POH preflight sequence','Understand start/run-up checks','Explain rotor and passenger ground safety'],'sections':['POH \xa74 Normal Procedures','POH \xa710 Safety Notices'],'brief':'Practice checklist discipline and cockpit flow without replacing the aircraft checklist. Include fuel contamination checks, loose-object control, rotor-area safety and shutdown.'},
'hover':{'title':'Hover, Taxi & Ground Risk','objectives':['Explain hover control relationships','Recognize dynamic rollover risk','Manage wind/obstacle/rotor hazards'],'sections':['POH \xa710 Safety Tips'],'brief':'Hovering requires small coordinated inputs and disciplined visual reference. Ground resonance is not the central R22 issue; dynamic rollover, tail-rotor hazards and obstacle clearance deserve emphasis.'},
'takeoff':{'title':'Takeoff, Approach & Landing','objectives':['Explain normal takeoff and approach flow','Use the height-velocity diagram','Apply performance planning before liftoff'],'sections':['POH \xa74 Takeoff/Approach/Landing','POH \xa75 Performance'],'brief':'Tie takeoff technique to available power, gross weight, density altitude, wind, obstacles and the height-velocity diagram.'},
'maneuvers':{'title':'Flight Maneuvers & Energy Management','objectives':['Maintain rotor RPM awareness','Plan climbs/descents/turns','Recognize conditions that erode margins'],'sections':['POH \xa72 Limitations','POH \xa74 Normal Procedures'],'brief':'Use recommended airspeeds and limitations while understanding how control inputs, power and rotor energy interact.'},
'emergency':{'title':'Emergency Procedures Mastery','objectives':['Recall immediate actions without delay','Differentiate power-failure height regimes','Recognize system failures and warning lights'],'sections':['POH \xa73 Emergency Procedures'],'brief':'Memory items must be distinguished from follow-on checklist actions. Train recognition and sequence recall; flight execution belongs with a qualified instructor.'},
'performance':{'title':'Performance, Weight & Balance','objectives':['Calculate takeoff/landing/zero-fuel loading','Use IGE/OGE and density-altitude charts','Understand carb-heat performance penalty'],'sections':['POH \xa75 Performance','POH \xa76 Weight & Balance'],'brief':'Use aircraft-specific empty weight/arm and applicable model charts. Check both gross weight and CG across fuel burn, and do not treat ideal chart performance as guaranteed real-world performance.'},
'weather':{'title':'Weather, Carb Ice & ADM','objectives':['Interpret weather for helicopter operations','Recognize carb-ice risk','Build conservative personal minimums'],'sections':['POH \xa74 Carburetor Heat','POH \xa710 Safety Notices'],'brief':'R22 weather decision-making should include winds/gust spread, turbulence, visibility, night conditions, density altitude and carburetor icing risk.'},
'nav':{'title':'Navigation, Airspace & Preflight Planning','objectives':['Plan route/altitudes/fuel','Interpret airspace and chart data','Check current NOTAM/TFR information'],'sections':['FAA current charts/AIM','POH \xa72/\xa75 as applicable'],'brief':'Navigation study must use current aeronautical data. Practice course, wind correction, groundspeed, time and fuel calculations in the Performance Pad.'},
'atc':{'title':'ATC & CTAF Communications','objectives':['Make concise initial calls','Read back runway/altitude/heading/squawk items','Handle frequency changes and emergencies'],'sections':['Current FAA AIM','Current Pilot/Controller Glossary'],'brief':'Listen first, know what you need to say, use standard terminology, and read back safety-critical clearances accurately.'},
'night':{'title':'Night Operations','objectives':['Understand R22 night limitations','Recognize visual illusions and visibility risk','Plan lighting and emergency options'],'sections':['POH \xa72 Kinds of Operation','POH \xa710 Safety Notices'],'brief':'Night VFR approval does not remove the need for adequate outside visual references, required lighting, conservative weather and suitable emergency options.'},
'written':{'title':'Knowledge Test Readiness','objectives':['Reach stable scores across knowledge areas','Remediate weak/missed questions','Explain why answers are correct'],'sections':['FAA-S-ACS-15 knowledge/risk elements'],'brief':'Use Study, Weak Areas, Missed and Bookmarked modes. Do not rely on memorizing repeated synthetic prompts; focus on concepts and authoritative references.'},
'oral':{'title':'Oral & Practical Test Readiness','objectives':['Explain R22 systems and limitations aloud','Apply risk management to scenarios','Connect knowledge to practical decisions'],'sections':['FAA-S-ACS-15','R22 POH all applicable sections'],'brief':'Practice concise explanations, then handle examiner-style follow-ups that require application rather than recall alone.'}
}
EMERGENCIES.update({
'max_glide':{'title':'Maximum Glide Distance Configuration','prompt':'For maximum glide after power loss, what configuration does the POH call for?','keys':['75','90','collective'],'feedback':'Study the POH \xa73 maximum-glide configuration: airspeed, rotor RPM/collective setting and configuration must be recalled together.'},
'air_restart':{'title':'Air Restart','prompt':'When is an air restart appropriate and what major conditions/checks precede the attempt?','keys':['time','altitude'],'feedback':'Use the complete POH \xa73 Air Restart Procedure. Do not sacrifice autorotation, landing-area selection or rotor RPM to attempt a restart.'},
'water_off':{'title':'Emergency Water Landing - Power Off','prompt':'Describe the major priorities for a power-off water landing.','keys':['autorotation','contact'],'feedback':'Use the complete POH \xa73 power-off water-landing sequence, including autorotation and actions associated with water contact/egress.'},
'water_on':{'title':'Emergency Water Landing - Power On','prompt':'Describe the major priorities for a power-on water landing.','keys':['hover','collective'],'feedback':'Use the complete POH \xa73 power-on water-landing procedure and egress sequence.'},
'tail_hover':{'title':'Loss of Tail Rotor Thrust - Hover','prompt':'Tail-rotor thrust is lost in a hover. What is the POH-directed control strategy?','keys':['throttle','collective'],'feedback':'Study the complete POH \xa73 hover tail-rotor-thrust-loss procedure; response differs from forward flight.'},
'fire_start':{'title':'Engine Fire During Start','prompt':'An engine fire occurs during start on the ground. What is the objective of the immediate procedure?','keys':['continue','cranking'],'feedback':'Use POH \xa73 Engine Fire During Start on Ground. The procedure is designed to draw fire/flames into the engine while securing fuel as specified.'},
'tach':{'title':'Tachometer Failure','prompt':'The tach indications disagree and it is not clear which tach is malfunctioning. Perform the published response.','keys':['audio','land'],'feedback':'Use POH \xa73 Tachometer Failure and cross-check available indications/audio cues; land as directed by the POH.'},
'warning':{'title':'Warning/Caution Lights','prompt':'A warning/caution light illuminates. What is the correct study approach?','keys':['identify','procedure'],'feedback':'Identify the exact light and execute its specific POH \xa73 response; do not use a generic response for all lights.'},
'audio_alert':{'title':'Audio Alerts','prompt':'An R22 audio alert sounds. What should you do first?','keys':['identify','alert'],'feedback':'Identify the alert and correlate it with indications and the POH \xa73 Audio Alerts guidance.'},
'ad_wind':{'title':'FAA AD 95-26-04 Wind/Turbulence Limits','prompt':'Moderate turbulence is encountered in flight. Apply the POH/AD turbulence response and leave the area if isolated.','keys':['25','15','turbulence'],'feedback':'POH \xa72/\xa73 reproduces FAA AD 95-26-04 limitations: surface wind, gust spread and continued flight in moderate-or-greater turbulence require specific attention.'}
})
