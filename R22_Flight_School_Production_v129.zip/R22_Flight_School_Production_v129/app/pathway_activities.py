"""Offline student preparation exercises. Records are study evidence, NOT flight authorizations."""
FIRST_TEN = [
 ('Cockpit and safety orientation','Identify aircraft configuration, occupant restraints, cockpit layout and the appropriate publications.'),
 ('Preflight observation','Walk through the actual approved inspection checklist with an instructor; distinguish observation from a maintenance decision.'),
 ('Flight controls and aerodynamics','Explain cyclic, collective and pedals, and how control inputs affect rotor thrust and yaw.'),
 ('Hover awareness','Describe hover visual references, drift recognition and why initial hover practice requires dual instruction.'),
 ('Departure and arrival briefing','Explain wind, departure routes, traffic-pattern awareness and landing-zone risk.'),
 ('Basic flight maneuvers','Prepare for climbs, descents, turns and aircraft energy management during dual instruction.'),
 ('Radio and airspace','Rehearse airport-specific communications, airspace entry requirements and chart interpretation.'),
 ('Navigation and weather','Practice pilotage, weather interpretation, terrain clearance and alternate selection.'),
 ('Abnormal indications','Identify indications that call for the current aircraft-specific emergency procedures and instructor involvement.'),
 ('Consolidation and postflight debrief','Identify remaining weaknesses with the instructor; do not infer solo eligibility from lesson count.'),
]
# Structured exercises require a concrete student response before being recorded.
ACTIVITIES = {
 'first-flight': [('flight_number','Flight preparation lesson (1–10)','select',[str(x) for x in range(1,11)]),('learning_objective','What must you demonstrate or explain?','text'),('review_questions','Questions to discuss with your instructor','textarea'),('postflight_observation','What did you actually observe? (optional; no proficiency signoff)','textarea')],
 'sfar73': [('topic','Required Robinson safety topic','select',['Energy management','Mast bumping','Low rotor RPM and rotor stall','Low-G effects and proper recovery','Rotor RPM decay']),('scenario','Explain the hazard and your source reference','textarea'),('instructor_question','Question for authorized instructor / endorsement verification','textarea')],
 'cockpit-instruments': [('aircraft','R22 aircraft identification / variant','text'),('instrument','Instrument and indication selected','text'),('meaning','Explain its function and the applicable reference','textarea')],
 'hover-coordination': [('control','Control selected','select',['Cyclic','Collective','Antitorque pedals']),('prediction','Predict the response and associated coordination requirement','textarea'),('visual_reference','Select visual references to detect unwanted movement','textarea')],
 'height-velocity': [('publication','Applicable R22 POH edition/section and aircraft','text'),('diagram_region','Identify the area on the actual diagram and explain its meaning','textarea'),('limitation_check','What operational decision follows from this chart?','textarea')],
 'aerodynamics': [('concept','Rotorcraft concept','select',['Effective translational lift','Translating tendency','Dissymmetry of lift','Induced flow','Retreating blade stall','Low-G / mast-bumping hazard']),('prediction','Predict the aerodynamic effect','textarea'),('explanation','Compare your prediction with the FAA source','textarea')],
 'go-no-go': [('pilot','PILOT: readiness, experience and human factors','textarea'),('aircraft','AIRCRAFT: condition, limitations and equipment','textarea'),('environment','ENVIRONMENT: weather, terrain, density altitude and airspace','textarea'),('pressure','EXTERNAL PRESSURES: commitments and alternatives','textarea'),('decision','Proposed decision and risk mitigations','textarea')],
 'emergency-recognition': [('scenario','Abnormal indication or scenario','text'),('recognition','Which instrument/cue would alert you?','textarea'),('poh_source','Exact applicable R22 POH emergency section (verify in aircraft)','text'),('instructor_review','Questions for instructor before any practical emergency training','textarea')],
 'preflight-inspection': [('station','Inspection area from applicable Robinson checklist','text'),('reference','Exact applicable approved checklist reference','text'),('observation','Condition noticed and why it matters','textarea'),('disposition','Who must evaluate an uncertain or potentially unsafe condition?','textarea')],
 'flight-briefing': [('route','Departure, destination and proposed route','text'),('weather','Time-stamped official weather checked / briefing notes','textarea'),('notams','NOTAM and airspace review with retrieval time','textarea'),('aircraft','Aircraft status, applicable supplements and W&B','textarea'),('fuel','Fuel estimate / source / reserve / alternatives','textarea'),('risk','Risk, decisions, and contingency actions','textarea')],
 'aviation-weather': [('raw','Paste a METAR or TAF training sample','textarea'),('station_time','Station, issue and validity times (UTC)','text'),('wind','Wind including gusts and operational significance','text'),('conditions','Visibility, clouds, ceiling and weather','textarea'),('decision','What further current weather information is needed?','textarea')],
 'fuel-planning': [('aircraft','Aircraft/configuration and source publication','text'),('planned_hours','Estimated airborne time (hours)','number'),('fuel_rate','Verified planned fuel burn (units/hour)','number'),('usable','Verified available usable fuel (same units)','number'),('reserve','Applicable required reserve duration (minutes; independently verify)','number'),('contingency','Additional contingency fuel (same units)','number')],
 'radio-missions': [('airport','Airport and tower status verified from current source','text'),('phase','Flight phase','select',['Departure','Traffic pattern','En route','Arrival','CTAF self-announce','Emergency']),('transmission','Compose actual intended transmission using airport-specific information','textarea'),('response','State whether a controller reply/clearance is expected and why','textarea')],
 'airspace': [('chart','Official FAA chart and effective date','text'),('location','Location and chart features','text'),('floor_ceiling','Applicable airspace floor/ceiling based on chart','text'),('communications','Required communications/equipment/permissions, source reference','textarea')],
 'solo-eligibility': [('rating','Current certificate/category/class','text'),('r22_hours','Instructor-verified R22 flight training hours (not app time)','number'),('endorsement','Instructor endorsement record and date (do not reproduce private numbers)','text'),('prerequisites','Other regulatory and aircraft-specific requirements requiring instructor verification','textarea'),('verdict','Outstanding items for instructor review (app cannot authorize solo)','textarea')],
 'instructor-debrief': [('flight_date','Flight date (YYYY-MM-DD)','text'),('objectives','Briefed objectives','textarea'),('observed','Observed performance and challenges','textarea'),('remediation','Next lesson and practice priorities','textarea'),('instructor','Instructor name (student entry, not digital signoff)','text')],
 'night-preparation': [('conditions','Visibility, terrain, landing-area lighting, illusion risks','textarea'),('equipment','Installed equipment and applicable regulatory/POH checks','textarea'),('alternate','Diversion or delayed departure decision','textarea')],
 'aircraft-profiles': [('registration','Aircraft identification (do not enter personal information)','text'),('variant','Model/variant and serial range if necessary','text'),('equipment','Installed avionics, equipment and limitations to verify','textarea'),('supplements','Applicable current POH supplements and revision dates','textarea'),('source','Aircraft documentation/records confirmed with instructor','textarea')],
}

def fuel_example(time_hours, rate, usable, reserve_min, contingency):
 """Simple arithmetic exercise; NO implicit aircraft values or go/no-go judgment."""
 vals=(time_hours,rate,usable,reserve_min,contingency)
 if any(not isinstance(v,(int,float)) or not (0<=v<=100000) for v in vals):
  raise ValueError('All fuel inputs must be nonnegative finite numeric values within a reasonable range')
 planned=time_hours*rate
 reserve=reserve_min/60*rate
 required=planned+reserve+contingency
 return dict(planned=round(planned,2),reserve=round(reserve,2),required=round(required,2),surplus=round(usable-required,2),sufficient_for_entered_assumptions=usable>=required)
