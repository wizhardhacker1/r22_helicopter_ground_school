# R22 Flight School v125 - Implementation and verification

Baseline: original v124 application, preserving existing modules and installation files.

## New usable interfaces
- `/sfar73-awareness-course`: an eight-item, graded and persisted Robinson SFAR 73 awareness knowledge assessment; includes citations to the specific regulatory paragraphs and shows answer explanations after submission. This is NOT instructor-conducted awareness training or a logbook endorsement.
- `/hover-coordination-lab`: a self-contained offline interactive conceptual motion trainer with arrow key cyclic reference movement, collective demand, pedal-balance and drift sliders, reset/pause, and visible reference-state feedback. This is NOT an R22 flight-dynamics model, rated flight training device or POH procedure.
- Both pages are linked from student pathways and main navigation.

## Verification in container
- 372 Python tests passed (including HTTP page loads, CSRF, scoring and persisted evidence).
- JavaScript syntax check (`node --check`) passed.
- Python compileall and 61 Jinja template parses passed.
- Build ZIP integrity checked before sharing.

## Aviation-source verification
- SFAR 73 knowledge items are source-linked to 14 CFR Part 61, SFAR 73 §2(a)(3), §2(b)(3) and instructor requirements. Source text checked against current online SFAR 73 regulation.
- Hover trainer draws conceptual coordination behavior, intentionally without claiming actual R22 rotor RPM, response rates, limitations or accuracy. General background: FAA Helicopter Flying Handbook Chapters 3 and 9.
- Other legacy aviation content remains outside this narrowly scoped verification. Entire 18-module request, offline FAA chart package, and line-by-line independent aviation verification are NOT demonstrated complete by this release. It must not be represented as FAA- or Robinson-approved.
