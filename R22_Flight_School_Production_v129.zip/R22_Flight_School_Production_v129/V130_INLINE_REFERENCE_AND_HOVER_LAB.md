# R22 embedded POH reference and interactive hover practice

Starting point: prior Windows installer dependency fix (v129 codebase).

## Instrument Panel Academy
- Students can read the POH Section 7-19 **37-item numbered key on the same screen** as the actual bundled POH diagram. No separate PDF click is necessary.
- Learn shows key; Quiz hides key; existing graphical selection, server-side scoring and saved practice result remain intact.
- The source identifies the diagram as an **earlier typical panel**, not the equipment in every R22.
- Source checked against the bundled R22 POH Section 7 page 7-19, PDF text page index 110, revised 26 Oct 2016.

## Hover Coordination Lab
- Four guided conceptual scenarios: hold station, compensate for drift, maintain heading with collective changes, and combined control.
- On-screen cyclic controls work with pointer input, including touch; arrow-key control retained.
- 45-second practice with actual time-in-zone and heading error tracking, reset, pause and status readouts.
- Motion model remains **qualitative** and is NOT a calibrated R22 flight model or FAA-approved simulator. Practice scores are not endorsements or demonstrated flight proficiency.
- Control explanations are embedded on the page rather than consisting of PDF links.

## Testing
- Full application regression suite, template parse tests, new targeted tests, and JavaScript syntax checks.
- Does not claim Windows native installation, physical helicopter fidelity, or completed audit of all aviation course content.
