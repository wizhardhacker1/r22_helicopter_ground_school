R22 Student Pilot Pathways — Layout Repair

Issue: production screenshot displayed unstyled inline links because the browser used a stale CSS asset URL.

Fixes: standalone scoped responsive tile styles in student_pathways.html; refreshed stylesheet query and service-worker cache; 18 accessible destination cards grouped in four sections; compact progress/header/shortcut toolbar; original routes and records preserved.

Evidence: full pytest suite 398 passed, Jinja template rendered with 18 pathway cards. Visual browser screenshot not validated in this runtime.
