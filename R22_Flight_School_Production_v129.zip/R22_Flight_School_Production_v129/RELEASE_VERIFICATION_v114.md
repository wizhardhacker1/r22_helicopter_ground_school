# R22 Flight School v114 — Answer, POH, ATC, Link, and UI Audit

## ATC Radio Lab corrections
- Rebuilt ATC scoring from raw substring matching to element-based phraseology evaluation.
- Spoken equivalents such as `Two Two Bravo Hotel`, `22BH`, `Runway Three Zero`, `Runway 30`, and common speech-recognition forms are accepted where appropriate.
- Non-towered CTAF calls are now classified and scored as **self-announcements**, not ATC readbacks.
- Non-towered scenarios no longer generate a fake controller readback response.
- The inbound non-towered exercise now gives the student all information needed for a complete call: Bishop Airport, 10 miles west, 3,500 feet, landing Runway 30.
- The CTAF model call includes the airport name at both the beginning and end, aircraft identification, position, altitude, and landing/runway intention.
- All 10 primary ATC model examples were run through the same evaluator students use and each scores 100%.
- ATC result feedback now lists each required communication element with a pass/fail mark.
- The CTAF page says `CTAF / SITUATION` and `AUDIO Hear Situation` instead of pretending there is a controller.
- The offline CTAF listening lesson now presents a situation prompt followed by a model pilot self-announcement rather than labeling a pilot broadcast as controller audio.
- FAA grounding used for this audit: AIM 4-1-9 CTAF/self-announce practices, AIM 4-2/4-3 communications, current Pilot/Controller Glossary, and JO 7110.65 helicopter/terminal phraseology.

## R22 POH / answer audit
- Audited the 36 authored R22-specific question-bank items against the bundled R22 POH/RFM and included Robinson Safety Notices.
- Confirmed key POH anchors used by the question bank and POH Mastery: 1370 lb Beta/Beta II max gross, 920 lb minimum gross, 240 lb seat-plus-baggage limit, 50 lb baggage-compartment limit, 14,000 ft maximum operating density altitude, 102 KIAS VNE up to 3000 ft DA, 101–104% normal power-on rotor RPM, 90–110% power-off rotor RPM, 55 psi minimum flight oil pressure, 16.9/9.4/26.3 gal usable bladder fuel capacities, 108.6/103.8 in fuel arms, 106.9 in combined longitudinal fuel arm, 60 KIAS takeoff/climb, 53 KIAS VY, 83 KIAS maximum range, 75 KIAS maximum-glide speed, 97% minimum rotor RPM below 500 ft in maximum-glide autorotation, 25 kt wind and 15 kt gust-spread AD thresholds, and the Section 6 forward-CG shift with fuel burn.
- Rechecked all 50 POH Mastery section questions and all 10 final-assessment answer indexes for valid answer/explanation structure.
- Corrected one Safety Notice mismatch: the SN-17 question now teaches the actual SN-17 passenger-loading guidance to firmly grip cyclic and throttle while loading/unloading with the engine running, rather than attributing a generic rotor-awareness statement to SN-17.
- Reworded the oral tail-rotor-thrust-loss question so the question and answer match the POH's immediate-action wording.

## General test-bank integrity
- Built-in authored bank checked: 92 PPL study questions, 36 R22-specific questions, 10 IFR study questions.
- Every authored item has a valid A/B/C answer key, non-empty explanation, and source/reference field.
- No duplicate prompt exists inside an individual built-in bank.
- These are clearly retained as authored study questions and are not represented as live FAA test questions.
- FAA-S-ACS-15 remains the current Private Pilot Rotorcraft—Helicopter ACS baseline for the course.

## UI / application audit
- Actual ATC page rendered in Chromium at 1440 px and 390 px widths with no horizontal overflow.
- The corrected CTAF model transmission was entered through the rendered UI and displayed 100% with all six communication elements checked.
- Jinja templates parsed successfully.
- No duplicate literal DOM IDs found.
- No missing literal static assets found.
- No known baked-in hexadecimal entity, old Unicode-escape, or replacement-character UI artifacts found.
- Python compileall passed.
- All JavaScript files passed `node --check`.
- Linux installer/trust/start shell scripts passed `bash -n`.
- Student Pilot Training Roadmap links continue to resolve with no failures in the audit crawl.

## Regression suite
- 327/327 automated tests passed after the corrections.
- New v114 regression tests verify question-bank structure, POH Mastery answer indexes, audited R22 numeric/source anchors, every ATC model example against the evaluator, self-announce semantics, and spoken call-sign/runway forms.

## Important training limitation
R22 Flight School is a training aid. For actual aircraft operation, the current approved aircraft-specific R22 POH/RFM, applicable supplements, aircraft records, current Robinson publications, FAA regulations/publications, and qualified instructor guidance control.
