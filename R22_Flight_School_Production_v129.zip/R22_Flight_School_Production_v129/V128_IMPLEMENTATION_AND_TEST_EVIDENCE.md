# R22 Flight School — v128 implementation and evidence

**Starting baseline:** v127 source archive, preserved as an existing application (not rebuilt).

## Implemented in this update
- Corrected the offline METAR decoder to recognize FAA-style U.S. visibility `P6SM` (more than six statute miles), `M1/4SM` (less than one-quarter statute mile), and separated mixed visibility (`1 1/2SM`).
- Corrected the TAF decoder to recognize `M1/4SM` and two-token mixed fractional statute-mile visibility in forecast groups.
- Preserved nonrecognized groups in the unparsed fields, instead of inventing interpretations.
- Added six focused regressions and updated the superseded visibility expectation in an earlier test.

## Executed tests in this container
- `PYTHONPATH=. pytest -q`: **383 passed**.
- `python -m compileall -q app`: passed.
- `node --check` on **36** bundled JavaScript files: passed (0 failures).
- ZIP integrity: tested separately when the archive was created.

## Source basis
- FAA Aeronautical Information Manual, Chapter 7, Safety of Flight: https://www.faa.gov/air_traffic/publications/atpubs/aim_html/chap7_section_1.html
- FAA Aviation Weather Handbook FAA-H-8083-28B: https://www.faa.gov/sites/faa.gov/files/FAA-H-8083-28B.pdf

## Release scope and material limits
These tests demonstrate software execution and the explicitly tested weather decoding cases, **not** full functionality of all 18 requested training systems, nor item-level verification of every aviation question or emergency procedure. The app does **not** become FAA-approved or Robinson-approved as a result of these tests. This archive is a working source update; it is not a certified flight training device and it is not verified for actual aircraft dispatch decisions. Native Windows and Debian installer execution was not performed in this environment.
