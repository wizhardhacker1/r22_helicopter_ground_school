# R22 v123 – verified change scope

This revision is based on the existing v122 application and preserves its other source modules.

## Implemented
- Offline practical tools route `/student-practical-tools`, linked from student pathways.
- Live rotorcraft VFR fuel arithmetic with a minimum 20-minute reserve input threshold and explicit data-entry validation; references 14 CFR 91.151(b). This is an arithmetic learning comparison, not dispatch clearance, and does not infer aircraft-specific burn/usable fuel or forecast winds.
- Conservative R22 SFAR 73 solo-prerequisite screening, which flags missing/expired records and never authorizes solo. References SFAR 73 and 14 CFR 61.87.
- Unit tests for numeric validation, reserve arithmetic, no-solo-authorization behavior.

## Verification
- `python -m pytest -q`: 365 tests passed.
- `node --check app/static/js/r22_practical_tools.js`: passed.
- ZIP CRC verification must be performed after packaging.

## Not established by this update
- All 18 requested features are **not** full independent interactive simulators.
- An item-by-item factual FAA/Robinson/POH audit of legacy curriculum remains outstanding.
- Independent qualified R22 instructor review, certification/FAA or Robinson approval, native installer testing and full browser interaction tests were not performed.
- Do not use the app as sole authority for aircraft operations, endorsements, or regulatory compliance.
