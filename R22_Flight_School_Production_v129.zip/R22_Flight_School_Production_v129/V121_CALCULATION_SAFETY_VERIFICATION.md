# v121 Calculation safety verification

Baseline: v120. This release contains executable fixes and tests, **not** a completed factual validation of all R22/FAA educational material.

## Verified by executable tests
- Reject NaN/Infinity in altitude, density-altitude, wind-triangle, E6B and fuel-plan numeric inputs.
- Reject invalid altimeter settings and physically invalid E6B temperature.
- Require explicit planning reserve on the `/api/fuel` route. Do not imply that the default 20-minute reserve meets a regulatory minimum.
- Fuel planning results explicitly identify selected-reserve-only scope; `regulatory_compliance_verified` is false.
- Existing regression suite: 359 tests passed.

## Referenced source context
- FAA Helicopter Flying Handbook: https://www.faa.gov/regulations_policies/handbooks_manuals/aviation/helicopter_flying_handbook
- Robinson R22 POH and revision log: https://www.robinsonheli.com/publications

## Boundaries
The application still contains source references that are too broad to constitute question-level factual verification. FAA/Robinson source alignment and instructor signoff cannot be inferred from automated test passes. The existing package aviation content ledger is retained for independent review. A qualified reviewer must validate aircraft-model-specific calculations against the actual aircraft's POH, installed supplements, and weight-and-balance records before flight use. Chart tiles are not bundled in the existing FAA chart folder.
